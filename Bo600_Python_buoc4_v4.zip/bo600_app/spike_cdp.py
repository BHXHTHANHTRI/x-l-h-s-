"""LÀM THỬ KẾT NỐI (bước 0): Bộ 600 có điều khiển được Chrome trên TST/TNHS không, hai site có chặn không?

CHỈ ĐỌC: không bấm, không điền, không gửi gì lên trang. Chạy:

    python spike_cdp.py                      # mở Chrome riêng, bạn đăng nhập, rồi kiểm tra
    python spike_cdp.py --no-launch          # Chrome đã mở sẵn bằng cổng gỡ lỗi (--port)
    python spike_cdp.py --seconds 20         # thời gian nghe mạng (bạn bấm qua lại các trang trong lúc đó)

Kết quả in ra màn hình và lưu vào spike_report.txt (không chứa họ tên, mã số, nội dung phản hồi - chỉ đường dẫn API,
mã trạng thái, tên trường). Gửi file đó lại cho người hỗ trợ nếu có mục FAIL/WARN.
"""
import argparse
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))

from bo600.browser import BrowserSession, cdp_up, find_chrome, launch_chrome
from bo600.browser.portals import PORTALS
from bo600.config import Paths

OUT = []


def say(level, msg):
    line = f"[{level}] {msg}"
    print(line)
    OUT.append(line)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9222)
    ap.add_argument("--profile", help="thư mục hồ sơ Chrome riêng (mặc định: <Bo600>\\_chrome_profile)")
    ap.add_argument("--chrome", help="đường dẫn chrome.exe nếu không tự tìm được")
    ap.add_argument("--no-launch", action="store_true")
    ap.add_argument("--auto", action="store_true", help="không hỏi Enter")
    ap.add_argument("--seconds", type=int, default=15)
    ap.add_argument("--portal", action="append", default=[], metavar="vai=host", help="đổi host một cổng (dùng khi thử nghiệm)")
    a = ap.parse_args()
    portals = {k: list(v) for k, v in PORTALS.items()}
    for kv in a.portal:
        k, v = kv.split("=", 1)
        portals[k] = [v, f"http://{v}/"]

    say("INFO", f"Python {sys.version.split()[0]} · cổng gỡ lỗi {a.port}")
    if not a.no_launch:
        prof = a.profile or str(Paths().ensure().base / "_chrome_profile")
        exe = a.chrome or find_chrome()
        say("INFO", f"Chrome: {exe or 'KHÔNG TÌM THẤY'} · hồ sơ riêng: {prof}")
        try:
            p = launch_chrome(prof, a.port, urls=[v[1] for k, v in portals.items() if k in ("tst", "tnhs")], chrome_path=exe)
            say("PASS", "Đã mở Chrome với cổng gỡ lỗi" if p else "Chrome đã mở sẵn cổng gỡ lỗi")
        except Exception as e:                                   # noqa: BLE001
            say("FAIL", f"Không mở được Chrome: {e}")
            return finish()
        if not a.auto:
            input("\n>> Đăng nhập TST và TNHS trong cửa sổ Chrome vừa mở, mở một trang danh sách bất kỳ, rồi nhấn Enter ở đây... ")
    elif not cdp_up(a.port):
        say("FAIL", f"Chưa có Chrome nào mở cổng gỡ lỗi {a.port}")
        return finish()

    try:
        br = BrowserSession(a.port).__enter__()
    except Exception as e:                                       # noqa: BLE001
        say("FAIL", f"Không nối được Chrome: {e}")
        return finish()
    try:
        say("PASS", f"Đã nối Chrome {br.browser.version}, {len(br.pages())} tab")
        tabs = {}
        for role, (host, _u) in portals.items():
            pg = br.find_page(host)
            if pg is None:
                say("WARN" if role == "hgd" else "FAIL", f"Chưa thấy tab {host} (mở và đăng nhập trước)")
                continue
            tabs[role] = br.tab(role, host)
            say("PASS", f"Thấy tab {role}: {urlparse(pg.url).path or '/'}")
        for role, t in tabs.items():
            kiem_tra(role, t, a.seconds)
    finally:
        br.close()
    say("INFO", f"Chrome vẫn mở: {'có' if cdp_up(a.port) else 'KHÔNG'}")
    finish()


def kiem_tra(role, t, seconds):
    url0 = t.page.url
    wd = t.page.evaluate("navigator.webdriver")
    say("PASS" if not wd else "WARN", f"[{role}] navigator.webdriver = {wd}"
        + ("" if not wd else " (trang có thể nhận ra điều khiển tự động)"))
    ok = t.page.evaluate("typeof window.__bo600rt === 'object'")
    say("PASS" if ok else "FAIL", f"[{role}] cài được mã cổng ổn định vào trang: {ok}")
    st = t.page_state()
    say("INFO", f"[{role}] trạng thái trang: đang tải={st['tai'] or 'không'}, giao diện lặng {st['domAge']} ms")
    dt = t.page.evaluate("(() => { const t = performance.now(); for (let i = 0; i < 3; i++) { debugger; } return performance.now() - t; })()")
    say("PASS" if dt < 150 else "FAIL", f"[{role}] lệnh debugger trong trang mất {dt:.0f} ms"
        + ("" if dt < 150 else " - trình gỡ lỗi đang tạm dừng trang (trang có bẫy chống DevTools?)"))
    if t.page.url != url0:
        say("WARN", f"[{role}] trang tự chuyển địa chỉ khi nối: {urlparse(url0).path} -> {urlparse(t.page.url).path}")
    since = time.monotonic()
    say("INFO", f"[{role}] nghe mạng {seconds} giây - hãy bấm sang một trang/danh sách khác trên {role.upper()} ngay bây giờ...")
    t.sleep(seconds * 1000)
    hits = [h for h in t.net.log if h.ts >= since]
    xhr = [h for h in hits if re.search(r"/api/|\.json|/rest/", h.url)] or hits
    say("PASS" if hits else "WARN", f"[{role}] nghe được {len(hits)} phản hồi mạng ({len(xhr)} dạng API)")
    seen = {}
    for h in xhr:
        key = f"{h.method} {urlparse(h.url).path} -> {h.status}"
        seen[key] = seen.get(key, 0) + 1
    for k, n in list(seen.items())[:10]:
        say("INFO", f"    {k}" + (f"  x{n}" if n > 1 else ""))
    for h in xhr:
        if h.status == 200 and "json" in (getattr(h.resp, "headers", {}) or {}).get("content-type", ""):
            j = h.json()
            kind = type(j).__name__ if j is not None else "KHÔNG ĐỌC ĐƯỢC"
            keys = sorted(j.keys())[:12] if isinstance(j, dict) else ""
            say("PASS" if j is not None else "WARN", f"[{role}] đọc được nội dung JSON của {urlparse(h.url).path}: {kind} {keys}")
            break
    t.net.log.clear()


def finish():
    n_fail = sum(l.startswith("[FAIL]") for l in OUT)
    n_warn = sum(l.startswith("[WARN]") for l in OUT)
    say("KẾT LUẬN", "ĐẠT - có thể làm tiếp các bước thao tác" if not n_fail and not n_warn else
        f"{n_fail} FAIL, {n_warn} WARN - gửi spike_report.txt để xem phương án")
    Path(__file__).with_name("spike_report.txt").write_text("\n".join(OUT) + "\n", encoding="utf-8")
    print("\nĐã lưu spike_report.txt")


if __name__ == "__main__":
    main()
