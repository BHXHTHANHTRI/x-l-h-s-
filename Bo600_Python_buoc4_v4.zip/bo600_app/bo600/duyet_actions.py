"""Thao tác của màn Duyệt và các thao tác hồ sơ khác, TÁCH khỏi giao diện để test được.

Port từ m7_duyet.js (guiHangCho, datTuChoi, rutHangCho, khoa, mở/nạp file sửa tay, người xác nhận, truy thu)
và m1..m4 (đánh dấu "Người đã làm bước này", "Làm tay"). Mọi hàm ném ValueError(thông báo tiếng Việt) khi không làm được.
"""
from __future__ import annotations

import re
import shutil
import time
from collections import Counter
from pathlib import Path
from typing import Optional

from .config import COT_KHOA, DUYET_COT_CO_DINH
from .d02_io import build_import, read_d02, validate_edited
from .exports import export_duyet_xlsx
from .rules import da_tick, dat_o, ep_tinh_lai, rules_ver, sig, tinh_dx, tl_cam, TL_LYDO
from .store import Store, dx_key, imp_key
from .util import now_vn, thang_idx

PV_COT = ["STT", "HOTEN", "SOCMND", "NGAYSINH", "NAMSINH", "SOBHXH", "MACV", "MA_TINH", "MA_BV", "TINHLAI", "GHICHU"]


def _ms() -> int:
    return int(time.time() * 1000)


def file_base(it: dict) -> str:
    return Path(str(it.get("file") or "")).name


# ---------- trạng thái ----------
def khoa(it: dict, dx: dict) -> bool:
    """Hồ sơ bị khóa (không sửa, không tích): trong hàng chờ, đang sửa ngoài bằng Excel, hoặc còn lỗi sau import chưa xử lý."""
    ex = dx.get("excel") or {}
    return bool(it.get("q") or ex.get("state") == "dangsua" or (it.get("imp") or {}).get("kq") in ("loi", "chua_ro"))


def load_dx(store: Store, socai, rules: dict, lot: dict, it: dict, force: bool = False,
            giu_tay: bool = True) -> dict:
    """Lấy dx đã lưu; tính lại (giữ ô người đã sửa) nếu dữ liệu đầu vào/quy tắc đổi hoặc force."""
    key = dx_key(lot["id"], it["id"])
    old = store.kv_get(key)
    if old and not force and old.get("sig") == sig(it) and old.get("rv") == rules_ver(rules):
        return old
    dx = tinh_dx(store, rules, socai, lot, it, old=old if giu_tay else None)
    if old and old.get("excel") and giu_tay:
        dx["excel"] = old["excel"]
    store.kv_set(key, dx)
    return dx


def save_dx(store: Store, lot: dict, it: dict, dx: dict) -> None:
    store.kv_set(dx_key(lot["id"], it["id"]), dx)


# ---------- sửa ô, tích ----------
def set_cell(store: Store, lot: dict, it: dict, dx: dict, i: int, col: str, value: str) -> Optional[str]:
    """Người sửa một ô. Trả về thông báo (lý do không nhận / điều chỉnh) hoặc None nếu nhận nguyên giá trị."""
    if khoa(it, dx):
        return "Hồ sơ đang bị khóa (hàng chờ / sửa ngoài / còn lỗi sau import)."
    if (dx.get("excel") or {}).get("state") == "sansang":
        return "Hồ sơ đang dùng file người sửa bằng Excel: sửa trong Excel (Thôi sửa ngoài để quay lại)."
    r = dx["rows"][i]
    if r["tick"]:
        return "Dòng đã tích duyệt bị khóa sửa - bỏ tích trước."
    if col in COT_KHOA or col not in dx["head"]:
        return f"Không sửa được cột {col}."
    v = str(value).strip()
    msg = None
    if col == "TINHLAI" and tl_cam(r["chot"].get("TUTHANG")) and v:
        v, msg = "", TL_LYDO
    dat_o(r, col, v, "nguoi")
    if col == "TUTHANG" and ep_tinh_lai(r, dx["head"]):
        msg = TL_LYDO
    save_dx(store, lot, it, dx)
    return msg


def set_tick(store: Store, lot: dict, it: dict, dx: dict, i: Optional[int], on: bool) -> None:
    """i=None: tích/bỏ tích cả hồ sơ. Hồ sơ khóa thì không đổi."""
    if khoa(it, dx):
        raise ValueError("Hồ sơ đang bị khóa.")
    ex = dx.get("excel") or {}
    if ex.get("state") == "sansang":
        t = ex.setdefault("tick", [False] * ex.get("nRows", 0))
        if i is None:
            ex["tick"] = [on] * len(t)
        else:
            t[i] = on
    elif i is None:
        for r in dx["rows"]:
            r["tick"] = on
    else:
        dx["rows"][i]["tick"] = on
    save_dx(store, lot, it, dx)


# ---------- gửi hàng chờ / từ chối ----------
def gui_hang_cho(store: Store, lot: dict, it: dict, dx: dict) -> str:
    """Dựng file import từ các giá trị đã chốt và đưa hồ sơ vào hàng chờ (KHÔNG tự chạy import). Trả về mô tả nguồn."""
    if khoa(it, dx):
        raise ValueError("Hồ sơ đang bị khóa.")
    if not da_tick(dx)["all"]:
        raise ValueError("Hồ sơ chưa tích đủ dòng - Bộ 600 không import hồ sơ thiếu dòng.")
    name = file_base(it)
    out = store.paths.lot_dir(lot["id"]) / "_import" / name
    ex = dx.get("excel") or {}
    if ex.get("state") == "sansang":
        if not Path(ex["path"]).is_file():
            raise ValueError("Không còn file người sửa bằng Excel đã nạp - nạp lại.")
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ex["path"], out)
        n_rows, src = ex["nRows"], "Excel (người sửa)"
    else:
        src_file = store.paths.item_path(lot["id"], it["file"])
        if not src_file.is_file():
            raise ValueError(f"Không còn file D02 của hồ sơ {it.get('sohoso')}.")
        build_import(src_file, out, dx["rows"], with_goc=False)
        n_rows, src = len(dx["rows"]), "Sửa trong app"
    store.kv_set(imp_key(lot["id"], it["id"]), {"path": str(out), "name": name, "nRows": n_rows, "src": src, "at": now_vn()})

    def mark(i2, _l):
        ts = _ms()
        i2["q"] = {"kind": "import", "ts": ts, "at": now_vn(), "src": src}
        i2["imp"] = None
        i2["duyet"] = {"kq": f"Import ({src}, {n_rows} dòng)", "at": now_vn(), "ts": ts}

    store.edit_item(lot["id"], it["id"], mark)
    save_dx(store, lot, it, dx)
    export_duyet_xlsx(store, lot["id"])
    return f"{n_rows} dòng, {src}"


def dat_tu_choi(store: Store, lot: dict, it: dict, dx: dict, on: bool, cho_giay: int) -> None:
    tc = dx["tuChoi"]
    if on:
        if not (str(tc.get("lyDo") or "").strip() and str(tc.get("deNghi") or "").strip()):
            raise ValueError("Điền đủ lý do và đề nghị trước khi duyệt từ chối.")
        if (it.get("q") or {}).get("kind") == "import":
            raise ValueError("Hồ sơ đang trong hàng chờ import - rút ra trước.")
    save_dx(store, lot, it, dx)

    def mark(i2, _l):
        if on:
            ts = _ms()
            i2["q"] = {"kind": "tuchoi", "ts": ts, "at": now_vn(), "notBefore": ts + cho_giay * 1000,
                       "lyDo": tc["lyDo"], "deNghi": tc["deNghi"]}
            i2["duyet"] = {"kq": "Từ chối", "at": now_vn(), "ts": ts}
        else:
            i2["q"] = None
            i2["duyet"] = None

    store.edit_item(lot["id"], it["id"], mark)
    export_duyet_xlsx(store, lot["id"])


def rut_hang_cho(store: Store, lot: dict, it: dict) -> bool:
    def mark(i2, _l):
        if not i2.get("q"):
            return False
        i2["q"] = None
        i2["duyet"] = None

    ok = store.edit_item(lot["id"], it["id"], mark)
    if ok:
        export_duyet_xlsx(store, lot["id"])
    return ok


# ---------- truy thu ----------
def mau_truy_thu(dx: dict, mau: str) -> str:
    r = next((x for x in dx["rows"] if any(i["k"] == "truyThu" for i in x["issues"])), dx["rows"][0] if dx["rows"] else None)
    bao_tang = (r["chot"].get("TUTHANG") if r else "") or ""
    goc = (r["goc"].get("TUTHANG") if r else "") or ""
    return mau.replace("{THANG_BAO_TANG}", bao_tang).replace("{TU_THANG_GOC}", goc)


def set_truy_thu(store: Store, lot: dict, it: dict, dx: dict, on: bool, noi_dung: Optional[str], mau: str) -> None:
    tt = dx.get("truyThu") or {"on": False, "noiDung": ""}
    tt["on"] = bool(on)
    if noi_dung is not None:
        tt["noiDung"] = noi_dung
    if on and not str(tt.get("noiDung") or "").strip():
        tt["noiDung"] = mau_truy_thu(dx, mau)
    dx["truyThu"] = tt
    save_dx(store, lot, it, dx)


# ---------- sửa bằng Excel ----------
def _sua_dir(store: Store, lot: dict) -> Path:
    return store.paths.lot_dir(lot["id"]) / "_sua"


def mo_file_de_sua(store: Store, lot: dict, it: dict, dx: dict, tu_goc: bool = False) -> Path:
    """Trả về file để mở bằng Excel (BẢN MỚI NHẤT). Bản đã nạp và còn trên đĩa thì mở đúng bản đó, không ghi đè."""
    if it.get("q"):
        raise ValueError("Hồ sơ đang trong hàng chờ - rút ra trước khi sửa.")
    d = _sua_dir(store, lot)
    d.mkdir(parents=True, exist_ok=True)
    path = d / file_base(it)
    ex = dx.get("excel") or {}
    prev = ex if ex.get("state") == "sansang" else ex.get("banTruoc")
    if tu_goc and path.exists():                       # giữ bản sửa cũ thành <tên>_cu.xlsx
        cu = path.with_name(path.stem + "_cu" + path.suffix)
        n = 1
        while cu.exists():
            n += 1
            cu = path.with_name(f"{path.stem}_cu{n}{path.suffix}")
        path.rename(cu)
    if not tu_goc and prev and Path(prev.get("path", "")).is_file():
        use = Path(prev["path"])                       # mở đúng bản đã nạp, không ghi đè
    else:
        src = store.paths.item_path(lot["id"], it["file"])
        if not src.is_file():
            raise ValueError("Không còn file D02 gốc của hồ sơ.")
        build_import(src, path, dx["rows"], with_goc=True)
        use, prev = path, (None if tu_goc else prev)
    dx["excel"] = {"state": "dangsua", "path": str(use), "name": use.name, "banTruoc": prev, "at": now_vn()}
    save_dx(store, lot, it, dx)
    return use


def nap_file_sua(store: Store, lot: dict, it: dict, dx: dict, path: str | Path) -> list[str]:
    """Nạp file đã sửa bằng Excel. Trả về danh sách lỗi (rỗng = đã nhận)."""
    out = _sua_dir(store, lot) / "da_nap" / file_base(it)
    res = validate_edited(path, it, dx["rows"], out_path=out)
    if res.errors:
        return res.errors
    pv = [{c: r.o[c] for c in dict.fromkeys([*PV_COT, *DUYET_COT_CO_DINH]) if c in r.o} for r in res.d02.rows]
    dx["excel"] = {"state": "sansang", "banTruoc": None, "docLuc": now_vn(), "name": Path(path).name, "path": str(out),
                   "nRows": res.n_rows, "rows": pv, "tick": [False] * res.n_rows}
    save_dx(store, lot, it, dx)
    return []


def thoi_sua_ngoai(store: Store, lot: dict, it: dict, dx: dict) -> None:
    """Quay lại bản sửa tay đã nạp trước đó (nếu có), không thì về bản sửa trong app."""
    ex = dx.get("excel") or {}
    dx["excel"] = ex.get("banTruoc") if ex.get("state") == "dangsua" else None
    save_dx(store, lot, it, dx)


# ---------- người xác nhận / đánh dấu ----------
def nguoi_import_thu_cong(store: Store, socai, lot: dict, it: dict, da_xu_ly_tnhs: bool) -> None:
    socai.xac_nhan(it, "luu")
    if da_xu_ly_tnhs:
        socai.xac_nhan(it, "xlThu", "1")

    def mark(i2, _l):
        i2["q"] = None
        i2["imp"] = {"kq": "xong", "at": now_vn(), "nguon": "nguoi"}
        i2["duyet"] = {"kq": "Người dùng đã import thủ công", "at": now_vn(), "ts": _ms()}

    store.edit_item(lot["id"], it["id"], mark)


def danh_dau_nguoi_lam(store: Store, lot_id: str, item_id: str, key: str, on: bool) -> None:
    """'Người đã làm bước này' - ghi nhận bước làm ở máy khác."""
    def mark(i2, _l):
        nl = i2.setdefault("nguoiLam", {})
        if on:
            nl[key] = {"at": now_vn(), "ts": _ms()}
        else:
            nl.pop(key, None)

    store.edit_item(lot_id, item_id, mark)


def dat_lam_tay(store: Store, lot_id: str, item_id: str, on: bool) -> None:
    store.edit_item(lot_id, item_id, lambda i2, _l: i2.__setitem__("lamTay", bool(on)))


def mo_lai(store: Store, lot_id: str, item_id: str) -> None:
    """'Mở lại': bỏ qua các sự kiện/lượt cũ trước thời điểm này (sổ cái vẫn giữ nguyên)."""
    store.edit_item(lot_id, item_id, lambda i2, _l: i2.__setitem__("reopenTs", _ms()))


# ---------- nạp D02 thủ công (để thử/duyệt tay khi chưa có bước Tải D02 tự động) ----------
def doan_so_ho_so(d02) -> str:
    c: Counter = Counter()
    for r in d02.rows:
        c.update(re.findall(r"\d[\w.-]*/[\w./-]+", str(r.o.get("GHICHU", ""))))
    return c.most_common(1)[0][0] if c else ""


def nap_d02_thu_cong(store: Store, src: str | Path, sohoso: str, madonvi: str, kykekhai: str = "",
                     lot_id: Optional[str] = None) -> dict:
    sohoso = sohoso.strip()
    if not sohoso:
        raise ValueError("Cần số hồ sơ.")
    if any(i.get("sohoso") == sohoso for _l, i in store.all_items()):
        raise ValueError(f"Số hồ sơ {sohoso} đã có trong danh sách.")
    S = read_d02(src)
    lot = store.ensure_lot(lot_id)
    dest = store.paths.lot_dir(lot["id"]) / Path(src).name
    n = 1
    while dest.exists():
        n += 1
        dest = dest.with_name(f"{Path(src).stem}_{n}{Path(src).suffix}")
    shutil.copyfile(str(src), str(dest))
    return store.add_item(lot["id"], sohoso=sohoso, madonvi=madonvi.strip().upper(), kykekhai=kykekhai.strip(),
                          file=dest.name, rows=len(S.rows), atTs=_ms(), nguon="thucong")


def xoa_ket_qua_buoc(store: Store, lot_id: str, item_id: str, key: str) -> None:
    """'Chạy lại bước này': xóa kết quả của bước để máy làm lại (sổ cái KHÔNG bị xóa)."""
    def mark(i2, _l):
        if key == "ktn":
            i2["ktn"] = None; i2["ktnTs"] = 0
        elif key in ("f2", "the"):
            i2[key] = None; i2[key + "Ts"] = 0
            i2["tc"] = None
        (i2.get("nguoiLam") or {}).pop(key, None)

    store.edit_item(lot_id, item_id, mark)
