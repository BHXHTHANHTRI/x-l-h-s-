"""A1 - Kho dữ liệu SQLite: lô/hồ sơ, kv (kết quả từng bước), sổ cái, sự kiện.

Thay cho chrome.storage.local. Mọi thao tác đi qua một khóa RLock nên dùng được từ luồng nền lẫn luồng giao diện.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from typing import Callable, Optional

from .config import Paths
from .model import lot_open, new_id
from .util import date_str

SCHEMA = """
CREATE TABLE IF NOT EXISTS lots  (id TEXT PRIMARY KEY, doc TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS kv    (key TEXT PRIMARY KEY, doc TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS socai (id TEXT PRIMARY KEY, ts INTEGER NOT NULL, doc TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sukien(id TEXT PRIMARY KEY, seq INTEGER NOT NULL, doc TEXT NOT NULL);
"""
SUKIEN_TOI_DA = 4000


def file_key(lot_id, item_id): return f"d02:{lot_id}:{item_id}"
def ktn_key(lot_id, item_id): return f"ktn:{lot_id}:{item_id}"
def tc_key(lot_id, item_id): return f"tc:{lot_id}:{item_id}"
def dx_key(lot_id, item_id): return f"dx:{lot_id}:{item_id}"
def imp_key(lot_id, item_id): return f"imp:{lot_id}:{item_id}"


def item_keys(lot_id, item_id):
    return [f(lot_id, item_id) for f in (file_key, ktn_key, tc_key, dx_key, imp_key)]


class Store:
    def __init__(self, paths: Paths):
        paths.ensure()
        self.paths = paths
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(paths.db_path), check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self.db.commit()

    def close(self) -> None:
        with self.lock:
            self.db.close()

    # ---------- kv ----------
    def kv_get(self, key: str, default=None):
        with self.lock:
            r = self.db.execute("SELECT doc FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(r[0]) if r else default

    def kv_set(self, key: str, value) -> None:
        with self.lock, self.db:
            self.db.execute("INSERT INTO kv(key,doc) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET doc=excluded.doc",
                            (key, json.dumps(value, ensure_ascii=False)))

    def kv_delete(self, *keys: str) -> None:
        with self.lock, self.db:
            self.db.executemany("DELETE FROM kv WHERE key=?", [(k,) for k in keys])

    # ---------- lô / hồ sơ ----------
    def get_lots(self) -> dict:
        with self.lock:
            rows = self.db.execute("SELECT id, doc FROM lots").fetchall()
        return {i: json.loads(d) for i, d in rows}

    def get_lot(self, lot_id: str) -> Optional[dict]:
        with self.lock:
            r = self.db.execute("SELECT doc FROM lots WHERE id=?", (lot_id,)).fetchone()
        return json.loads(r[0]) if r else None

    def save_lot(self, lot: dict) -> None:
        with self.lock, self.db:
            self.db.execute("INSERT INTO lots(id,doc) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET doc=excluded.doc",
                            (lot["id"], json.dumps(lot, ensure_ascii=False)))

    def ensure_lot(self, lot_id: Optional[str] = None) -> dict:
        """Lô = ngày tải. Chưa có thì tạo (và tạo thư mục)."""
        lot_id = lot_id or date_str()
        with self.lock:
            lot = self.get_lot(lot_id)
            if lot is None:
                lot = {"id": lot_id, "status": "open", "items": []}
                self.save_lot(lot)
                self.paths.lot_dir(lot_id).mkdir(parents=True, exist_ok=True)
                self.paths.res_dir(lot_id).mkdir(parents=True, exist_ok=True)
        return lot

    def lots_open(self) -> list[dict]:
        return sorted((l for l in self.get_lots().values() if lot_open(l)), key=lambda l: l["id"])

    def all_items(self) -> list[tuple[dict, dict]]:
        """[(lot, item)] của mọi lô còn mở (core.js: allItems)."""
        return [(lot, it) for lot in self.lots_open() for it in lot.get("items", [])]

    def find_item(self, lot_id: str, item_id: str) -> Optional[tuple[dict, dict]]:
        lot = self.get_lot(lot_id)
        if not lot:
            return None
        for it in lot.get("items", []):
            if it.get("id") == item_id:
                return lot, it
        return None

    def add_item(self, lot_id: str, **fields) -> dict:
        with self.lock:
            lot = self.ensure_lot(lot_id)
            it = {"id": new_id(), **fields}
            lot["items"].append(it)
            self.save_lot(lot)
        return it

    def edit_item(self, lot_id: str, item_id: str, fn: Callable[[dict, dict], Optional[bool]]) -> bool:
        """Đọc - sửa - ghi trong một khóa. fn(it, lot) trả False thì hủy (không ghi). Port editIt()."""
        with self.lock:
            f = self.find_item(lot_id, item_id)
            if not f:
                return False
            lot, it = f
            if fn(it, lot) is False:
                return False
            self.save_lot(lot)   # `it` là phần tử của `lot` nên đã được sửa tại chỗ
            return True

    def purge_item_data(self, lot_id: str, item_id: str) -> None:
        self.kv_delete(*item_keys(lot_id, item_id))

    # ---------- sổ cái (chỉ thêm) ----------
    def socai_all(self) -> list[dict]:
        with self.lock:
            rows = self.db.execute("SELECT doc FROM socai ORDER BY ts, rowid").fetchall()
        return [json.loads(r[0]) for r in rows]

    def socai_insert(self, entry: dict) -> bool:
        """True nếu thêm mới, False nếu đã có (trùng id)."""
        with self.lock, self.db:
            cur = self.db.execute("INSERT OR IGNORE INTO socai(id,ts,doc) VALUES(?,?,?)",
                                  (entry["id"], int(entry.get("ts") or 0), json.dumps(entry, ensure_ascii=False)))
            return cur.rowcount == 1

    # ---------- sự kiện (TST, HGĐ) ----------
    def sukien_all(self) -> list[dict]:
        with self.lock:
            rows = self.db.execute("SELECT doc FROM sukien ORDER BY seq").fetchall()
        return [json.loads(r[0]) for r in rows]

    def sukien_insert(self, ev: dict) -> int:
        with self.lock, self.db:
            seq = (self.db.execute("SELECT COALESCE(MAX(seq),0) FROM sukien").fetchone()[0]) + 1
            self.db.execute("INSERT OR IGNORE INTO sukien(id,seq,doc) VALUES(?,?,?)",
                            (ev["id"], seq, json.dumps(ev, ensure_ascii=False)))
            self.db.execute("DELETE FROM sukien WHERE seq <= (SELECT MAX(seq) FROM sukien) - ?", (SUKIEN_TOI_DA,))
            return self.db.execute("SELECT COUNT(*) FROM sukien").fetchone()[0]
