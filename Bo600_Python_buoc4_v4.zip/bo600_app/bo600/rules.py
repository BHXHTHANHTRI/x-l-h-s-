"""A4 - Bộ quy tắc duyệt (module 7): tự sửa cơ học, đề xuất theo tra cứu, vấn đề -> 6 nhóm, lý do/đề nghị soạn sẵn.

Port từ m7_duyet.js (computeDx, daGiai, nhomTinh, mauTuChoi, tabOf, datO, epTinhLai). Thuần dữ liệu, không đụng trình duyệt:
test được hoàn toàn bằng file D02 mẫu.

Cấu trúc dx (JSON được, lưu ở kv 'dx:<lô>:<hồ sơ>'):
  {v, sig, rv, at, head, rows:[row], hsIssues, tuChoiMo, boTuChoi, excel, nhom, tuChoi{lyDo,deNghi}, truyThu?}
  row = {i, sr, stt, goc{}, chot{}, dx{cột: 'co'|'tc'}, tra{}, tay{cột: True}, tick, issues[{k,txt}], mau, loi}
    - dx[cột] = 'co': máy tự sửa cơ học; 'tc': máy sửa theo tra cứu; tay[cột]: người sửa.
"""
from __future__ import annotations

import json
import re
import unicodedata
from datetime import datetime
from typing import Optional

from .config import NHOM_TEN
from .d02_io import D02, read_d02
from .store import Store, ktn_key, tc_key
from .util import norm_name, now_vn, nop_idx, num, thang_idx, thang_nay

TL_LYDO = "TUTHANG bằng tháng hiện tại: không tính lãi - ô TINHLAI phải để trống"
_DON_GIAN = set(".,;:()/-+&'")


def _ky_tu_la(s: str) -> bool:
    """Có ký tự ngoài chữ/số/khoảng trắng/dấu câu cho phép (JS: [^\\p{L}\\p{N}\\s.,;:()/\\-+&'])."""
    for ch in s:
        if ch.isspace() or ch in _DON_GIAN:
            continue
        if unicodedata.category(ch)[0] in ("L", "N"):
            continue
        return True
    return False


def rules_ver(rules: dict) -> str:
    return json.dumps(rules, ensure_ascii=False, sort_keys=True)


def sig(it: dict) -> str:
    return "|".join(str(it.get(k) or 0) for k in ("atTs", "ktnTs", "f2Ts", "theTs", "reopenTs"))


# ---------- ô dữ liệu ----------
def dat_o(r: dict, c: str, v: str, ai: str) -> None:
    """Đặt giá trị chốt của một ô. ai: 'nguoi' (người sửa -> tay) | 'may' (máy -> dx='co'). Về đúng gốc thì bỏ dấu vết."""
    g = "" if r["goc"].get(c) is None else str(r["goc"][c])
    r["chot"][c] = v
    if v == g:
        r["tay"].pop(c, None)
        r["dx"].pop(c, None)
    elif ai == "nguoi":
        r["tay"][c] = True
    else:
        r["tay"].pop(c, None)
        r["dx"][c] = "co"


def tl_cam(tuthang, today: Optional[datetime] = None) -> bool:
    return thang_idx(tuthang) == thang_nay(today)


def ep_tinh_lai(r: dict, head: list, today: Optional[datetime] = None) -> bool:
    """TUTHANG bằng tháng hiện tại thì TINHLAI luôn trống (máy tự xóa 'x', không nhận 'x' người gõ)."""
    if "TINHLAI" not in (head or []) or not tl_cam(r["chot"].get("TUTHANG"), today) or not str(r["chot"].get("TINHLAI") or ""):
        return False
    dat_o(r, "TINHLAI", "", "may")
    return True


# ---------- lỗi đỏ đã có cách sửa ----------
def da_giai(loi: str, t: dict, dx: dict) -> bool:
    parts = [p.strip() for p in re.split(r"[;\n|]+", str(loi or "")) if p.strip()]
    if not parts:
        return False

    def ok(p: str) -> bool:
        if re.search(r"HGĐ|HGD|định\s*danh", p, re.I):
            return bool(t.get("De_xuat_SOBHXH") or t.get("Can_tra_dinh_danh"))
        if re.search(r"vùng\s*lương", p, re.I):
            return dx.get("MAVUNG") == "co"
        if re.search(r"điện\s*thoại\s*trùng", p, re.I):
            return dx.get("SDT") == "co"
        if re.search(r"CCCD|CMND", p, re.I):
            return bool(t.get("De_xuat_CCCD") or t.get("De_xuat_SOBHXH"))
        return False

    return all(ok(p) for p in parts)


def _vn_int(x: float) -> str:
    return f"{int(x):,}".replace(",", ".")


# ---------- tính đề xuất ----------
def compute_dx(d02: D02, it: dict, rules: dict, socai=None, ktn_rows: Optional[list] = None,
               tc_rows: Optional[list] = None, old: Optional[dict] = None, today: Optional[datetime] = None) -> dict:
    """Tính đề xuất và nhóm của một hồ sơ.

    ktn_rows[i]: kết quả kiểm tra nháp dòng i {mau:'Đỏ'|..., loi, fp}; tc_rows[i]: kết quả tra cứu F2/thẻ
    {De_xuat_SOBHXH, De_xuat_CCCD, De_xuat_MA_BV, A_ho_ten, Can_tra_dinh_danh, Ket_luan_ma}.
    socai: đối tượng có has_fingerprint(fp) (hoặc None). old: dx cũ để giữ ô người đã sửa.
    """
    kr, tc = ktn_rows or [], tc_rows or []
    head = d02.head
    has = lambda c: c in head
    khoi = str(((it.get("ktn") or {}).get("donVi") or {}).get("khoi") or "")
    khoi_cd = bool(re.match(r"^CD\b", khoi, re.I)) or bool(re.match(r"^\d{10,14}CD[A-Z]\d{2}$", str(it.get("madonvi") or ""), re.I))
    macv_bad = [re.sub(r"[.,;:]+$", "", norm_name(x)) for x in rules.get("macvTuChoi", [])]
    tn = thang_nay(today)
    rows = []
    for i, x in enumerate(d02.rows):
        g = x.o
        k = kr[i] if i < len(kr) and kr[i] else {}
        t = tc[i] if i < len(tc) and tc[i] else {}
        chot, dx, tra, issues = dict(g), {}, {}, []

        def set_(c, v, why):
            if not has(c) or str(chot.get(c) or "") == v:
                return
            chot[c] = v
            dx[c] = why

        # --- tự sửa cơ học ---
        set_("DENTHANG", "", "co")
        set_("MAVUNG", "01", "co")
        if re.search(r"\bK[123]\b", g.get("MAVUNGSS", ""), re.I):
            v = re.sub(r"\bK[123]\b", "", str(g["MAVUNGSS"]), flags=re.I)
            set_("MAVUNGSS", re.sub(r"^[\s,;.-]+|[\s,;.-]+$", "", v).strip(), "co")
        set_("DIACHI", ".", "co")
        set_("MAPB", "", "co")
        pa = str(g.get("PA", "")).upper().strip()
        tang = pa in rules.get("paTang", [])
        tu, nop = thang_idx(g.get("TUTHANG")), nop_idx(g.get("NGAY_NOP_HS"))
        if tang and tu and nop and tu < nop and tu != tn and str(g.get("TINHLAI", "")).lower() != "x":
            set_("TINHLAI", "x", "co")
        if tu and tu == tn and str(g.get("TINHLAI", "")).strip():   # TUTHANG = tháng hiện tại: không tính lãi
            set_("TINHLAI", "", "co")
        if re.search(r"điện\s*thoại\s*trùng", k.get("loi", "") or "", re.I):
            set_("SDT", "", "co")

        # --- đề xuất theo tra cứu ---
        if t.get("De_xuat_SOBHXH"):
            tra["SOBHXH"] = t["De_xuat_SOBHXH"]
            set_("SOBHXH", str(t["De_xuat_SOBHXH"]), "tc")
        if t.get("De_xuat_CCCD"):
            tra["SOCMND"] = t["De_xuat_CCCD"]
            set_("SOCMND", str(t["De_xuat_CCCD"]), "tc")
        if t.get("De_xuat_MA_BV"):
            p = str(t["De_xuat_MA_BV"]).split("-")
            tra["MA_BV"] = t["De_xuat_MA_BV"]
            if p[0]:
                set_("MA_TINH", p[0], "tc")
            set_("MA_BV", "-".join(p[1:]), "tc")
        hai_ng = bool(re.search(r"2 người|người xem|người quyết", t.get("Ket_luan_ma", "") or "", re.I))
        if t.get("A_ho_ten") and not t.get("Can_tra_dinh_danh") and not hai_ng \
                and norm_name(t["A_ho_ten"]) != norm_name(g.get("HOTEN")):
            tra["HOTEN_F2"] = t["A_ho_ten"]
            set_("HOTEN", str(t["A_ho_ten"]), "tc")

        # --- vấn đề -> nhóm theo bảng quy tắc ---
        add = lambda key, txt: issues.append({"k": key, "txt": txt})
        if has("MACV"):
            mv = str(chot.get("MACV") or "").strip()
            m = re.sub(r"[.,;:]+$", "", norm_name(mv))
            if not m:
                add("macv", "MACV trống")
            elif m in macv_bad:
                add("macv", f'MACV "{mv}" chung chung')
            elif _ky_tu_la(mv):
                add("macv", f'MACV "{mv}" có ký tự lạ')
        sbx, cmx = re.sub(r"\s+", "", str(chot.get("SOBHXH") or "")), re.sub(r"\s+", "", str(chot.get("SOCMND") or ""))
        if has("SOBHXH") and has("SOCMND") and not sbx and not cmx:
            add("khongMa", "Trống cả mã số BHXH và CCCD")
        elif not sbx and re.fullmatch(r"\d{9}", cmx):
            add("cmnd9KhongMa", f"Không có mã số BHXH, chỉ có CMND 9 số ({cmx})")
        elif re.fullmatch(r"\d{9}", cmx):
            add("cmnd9", "CMND 9 số, không tra được CCCD")
        if khoi_cd and tang and num(chot.get("TYLE")) == 32:
            add("cdChuHo", "Đơn vị khối CD báo tăng TYLE 32")
        ml = num(chot.get("ML"))
        if ml is not None and 20 <= ml < rules["mlToiThieu"]:
            add("ml", f'ML {chot.get("ML")} dưới {_vn_int(rules["mlToiThieu"])}')
        ty = num(chot.get("TYLE"))
        if ty is not None and ty < rules["tyleChuan"]:
            add("tyle", f'TYLE {chot.get("TYLE")} dưới {rules["tyleChuan"]}')
        if tang and tu and nop and nop - tu >= 2:
            add("truyThu", f'Truy thu {nop - tu} tháng (TUTHANG {g.get("TUTHANG")}, nộp {g.get("NGAY_NOP_HS")})')
        if k.get("fp") and socai is not None and socai.has_fingerprint(k["fp"]):
            add("soCai", "Trùng dòng đã Lưu trong sổ cái")
        if t.get("Can_tra_dinh_danh"):
            add("dinhDanh", t["Can_tra_dinh_danh"])
        elif hai_ng:
            add("haiNguoi", t.get("Ket_luan_ma"))
        if k.get("mau") == "Đỏ" and not da_giai(k.get("loi"), t, dx):
            add("loiDo", f'Lỗi đỏ TST: {k.get("loi")}')
        rows.append({"i": i, "sr": x.sr, "stt": g.get("STT") or str(i + 1), "goc": g, "chot": chot, "dx": dx,
                     "tra": tra, "tay": {}, "tick": False, "issues": issues, "mau": k.get("mau", "") or "",
                     "loi": k.get("loi", "") or ""})

    hs_issues = []
    if (it.get("ktn") or {}).get("status", "").startswith("Đã lưu"):
        hs_issues.append({"k": "soCai", "txt": it["ktn"].get("note") or "Kiểm tra nháp: trùng dòng đã lưu trong sổ cái"})
    if it.get("rows") not in (None, "") and int(it["rows"]) != len(rows):
        hs_issues.append({"k": "loiDo", "txt": f'Số dòng đọc được ({len(rows)}) khác số dòng lúc tải ({it["rows"]})'})

    # Giữ các ô người đã sửa ở lần tính trước (cùng STT, cùng họ tên gốc)
    for o in (old or {}).get("rows", []):
        r = next((x for x in rows if x["stt"] == o["stt"] and x["goc"].get("HOTEN") == o["goc"].get("HOTEN")), None)
        if r:
            for c in o.get("tay", {}):
                r["chot"][c] = o["chot"][c]
                r["tay"][c] = True
    for r in rows:                      # luật TINHLAI áp cả sau khi giữ ô người đã sửa
        ep_tinh_lai(r, head, today)

    dxo = {"v": 1, "sig": sig(it), "rv": rules_ver(rules), "at": now_vn(), "head": head, "rows": rows,
           "hsIssues": hs_issues, "tuChoiMo": False, "boTuChoi": False, "excel": None}
    if old and old.get("truyThu"):      # giữ ô tích Truy thu + nội dung phiếu người đã soạn
        dxo["truyThu"] = old["truyThu"]
    dxo["nhom"] = nhom_tinh(dxo, rules, False)
    dxo["tuChoi"] = mau_tu_choi(dxo, rules)
    return dxo


def issues_all(dx: dict) -> list:
    return [i for r in dx["rows"] for i in r["issues"]] + list(dx.get("hsIssues") or [])


def nhom_tinh(dx: dict, rules: dict, bo_tu_choi: bool = False) -> str:
    ns = {rules["nhom"].get(x["k"], "nguoi") for x in issues_all(dx)}
    if bo_tu_choi and "tuchoi" in ns:
        ns.discard("tuchoi")
        ns.add("nguoi")
    for n in ("tuchoi", "dinhdanh", "nguoi"):
        if n in ns:
            return n
    return "tracuu" if any("tc" in r["dx"].values() for r in dx["rows"]) else "sach"


def mau_tu_choi(dx: dict, rules: dict) -> dict:
    """Lý do, đề nghị soạn sẵn: gom theo các quy tắc có mẫu (không ghi STT dòng)."""
    ks = list(dict.fromkeys(x["k"] for x in issues_all(dx)))
    ks = [k for k in ks if rules["mau"].get(k)]
    ks.sort(key=lambda k: 0 if rules["nhom"].get(k) == "tuchoi" else 1)      # sort ổn định như JS
    uniq = lambda f: "\n".join(dict.fromkeys(v for v in (rules["mau"][k].get(f) for k in ks) if v))
    return {"lyDo": uniq("lyDo"), "deNghi": uniq("deNghi")}


def tab_of(it: dict, dx: dict) -> str:
    imp = it.get("imp") or {}
    if imp.get("kq") in ("loi", "chua_ro") and not ((it.get("q") or {}).get("kind") == "import"):
        return "loisau"
    if (it.get("q") or {}).get("kind") == "tuchoi":
        return "tuchoi"
    return "nguoi" if dx.get("boTuChoi") and dx["nhom"] == "tuchoi" else dx["nhom"]


def da_tick(dx: dict) -> dict:
    ex = dx.get("excel")
    if ex and ex.get("state") == "sansang":
        t = ex.get("tick") or []
        return {"all": bool(t) and all(t), "any": any(t)}
    return {"all": bool(dx["rows"]) and all(r["tick"] for r in dx["rows"]), "any": any(r["tick"] for r in dx["rows"])}


def nhom_ten(nhom: str) -> str:
    return NHOM_TEN.get(nhom, nhom)


# ---------- tiện ích gắn với kho ----------
def tinh_dx(store: Store, rules: dict, socai, lot: dict, it: dict, old: Optional[dict] = None,
            today: Optional[datetime] = None) -> dict:
    """Đọc file D02 + kết quả kiểm tra nháp/tra cứu của hồ sơ rồi tính dx (caller tự lưu bằng kv_set)."""
    f = store.paths.item_path(lot["id"], it.get("file"))
    if not f.is_file():
        raise FileNotFoundError('Không còn file D02 của hồ sơ - bấm "Chạy lại bước này" ở bước Tải D02')
    d02 = read_d02(f)
    return compute_dx(d02, it, rules, socai, store.kv_get(ktn_key(lot["id"], it["id"]), []),
                      store.kv_get(tc_key(lot["id"], it["id"]), []), old, today)
