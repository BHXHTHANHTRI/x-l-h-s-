"""Tầng C: các bước thao tác trên TST/TNHS. Mỗi bước là một hàm handler(ctx, items) đăng ký vào Runner.

Đã cài: bước 1 (dv), bước 2 (tn). Các bước còn lại chưa có - nút "Chạy bước này" ghi "chưa được cài đặt" vào nhật ký.
Khung dùng chung: open_session (phiên trình duyệt), mo_cong (mở tab TST/TNHS đã đăng nhập)."""
from __future__ import annotations

from ..browser import BrowserSession, Tab
from ..browser.portals import PORTALS


def open_session(ctx) -> BrowserSession:
    """Phiên trình duyệt cho một lượt chạy, cấu hình từ Cài đặt; bấm Dừng sẽ làm mọi chỗ chờ ném StopRequested."""
    s = ctx.cfg.settings()
    return BrowserSession(int(s["chrome_port"]), od=s["on_dinh"], stop_check=ctx.check_stop)


class ChuaDangNhap(RuntimeError):
    """Tab đang ở trang đăng nhập."""


def chua_dang_nhap(tab: Tab) -> bool:
    """Như lệnh ping của extension: URL có 'login' hoặc có ô mật khẩu đang hiện (bỏ ô 'Key kích hoạt' của TIC)."""
    if "login" in (tab.page.url or "").lower():
        return True
    return bool(tab.page.evaluate("""() => [...document.querySelectorAll('input[type="password"]')].some(
        (x) => __bo600rt.vis(x) && !(x.closest && x.closest('#__ks_toast__')) && x.id !== '__ks_toast_code__')"""))


def mo_cong(br: BrowserSession, vai: str, hash_: str | None = None) -> Tab:
    """Tab của cổng `vai` (tst | tnhs | hgd): dùng tab đã mở, chưa có thì mở mới. Kiểm tra đã đăng nhập, rồi (nếu có) đi tới #hash."""
    host, url = PORTALS[vai]
    tab = br.tab(vai, host, url)
    tab.ho_tai()
    if chua_dang_nhap(tab):
        raise ChuaDangNhap(f"Chưa đăng nhập {vai.upper()} ({host}) trong Chrome điều khiển được - đăng nhập rồi chạy lại.")
    if hash_:
        tab.goto_hash(hash_)
    return tab


def register_all(runner) -> None:
    """Đăng ký mọi bước đã cài vào Runner (gọi một lần khi mở app)."""
    from .donvi import chay_don_vi
    from .tiepnhan import chay_tiep_nhan
    from .tai_d02 import chay_tai_d02
    from .kiemtra_nhap import chay_kiem_tra_nhap
    runner.register("dv", chay_don_vi)
    runner.register("tn", chay_tiep_nhan)
    runner.register("tai", chay_tai_d02)
    runner.register("ktn", chay_kiem_tra_nhap)
