"""Bước 1 - Cập nhật danh sách đơn vị quản lý.

Port từ m1_tiepnhan.js (runDonVi) và content.js (tst_export_dsdv, tnhs_load_dsdv, openExt5Panel):
  1. (tùy chọn) TST > Danh mục đơn vị > Xuất File > "Danh sách đơn vị" + Excel -> lưu vào _danhmuc\\DsDonVi_<ngày>.<đuôi>
     Không bật "tự tải" thì dùng file người dùng đã chọn ở trang bước 1.
  2. TNHS: mở khung "Đơn vị quản lý" của TIC (tiện ích ngoài, phần "e5"), nạp file, chọn đúng tên chuyên quản
     trong khung gợi ý như người làm, bấm "Lấy mã theo chuyên quản".
  3. Đối chiếu: mã thừa (TIC đang giữ, không thuộc chuyên quản trong file) chỉ báo, không tự xóa;
     mã thiếu (có trong file, TIC chưa giữ) báo CẢNH BÁO.
Kết quả lưu ở store.kv["donvi"] (file, cq, codes, tic{...}) để trang bước 1 hiển thị.
"""
from __future__ import annotations

import re
import shutil
import time
from pathlib import Path

from ..browser import GateTimeout, NotReady, Target
from ..d02_io import codes_of_cq
from ..util import date_str, now_vn
from . import mo_cong

TST_DM_DON_VI = "#/dmDonVis"
TNHS_HASH = "#/ho-so-cho-thu-ly"

# ---- mã chạy trong trang (port nguyên từ content.js) ----
JS_CHON_RADIO = r"""(a) => {
  const modal = [...document.querySelectorAll('.modal')].find((m) => __bo600rt.vis(m) && /Xuất Báo cáo/i.test(m.textContent));
  if (!modal) return { err: 'modal' };
  // Ô chọn không có thuộc tính value trong HTML (Angular gán bằng ng-value): chọn theo chữ đứng sau ô chọn;
  // dự phòng: value = "2", rồi ô thứ 2.
  const textAfter = (el) => { let t = '', n = el.nextSibling; while (n && !(n.nodeType === 1 && n.tagName === 'INPUT')) { t += n.textContent || ''; n = n.nextSibling; } return t; };
  const rs = [...modal.querySelectorAll('input[type="radio"][name="' + a.name + '"]')];
  const re = new RegExp(a.rx, 'i');
  const r = rs.find((x) => re.test(textAfter(x))) || rs.find((x) => x.value === '2') || rs[1];
  if (!r) return { err: 'radio' };
  r.click();
  return { ok: true };
}"""
JS_RADIO_DA_CHON = r"""(a) => {
  const modal = [...document.querySelectorAll('.modal')].find((m) => __bo600rt.vis(m) && /Xuất Báo cáo/i.test(m.textContent));
  if (!modal) return false;
  const rs = [...modal.querySelectorAll('input[type="radio"][name="' + a.name + '"]')];
  return rs.some((x) => x.checked);
}"""
# Gõ tên làm TIC mở khung gợi ý ĐÈ lên nút "Lấy mã theo chuyên quản" -> chọn đúng tên trong khung gợi ý như người làm
JS_CHON_CHUYEN_QUAN = r"""(a) => {
  const byId = (i) => document.getElementById(i);
  const cqInp = byId('__bhxh_cq_input'), sug = byId('__bhxh_cq_suggestions');
  const key = (s) => String(s || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
  const items = () => (sug ? [...sug.querySelectorAll('.__bhxh_sug_item')] : []);
  const an = () => { if (sug) sug.style.display = 'none'; };
  __bo600rt.setValue(cqInp, '');
  const tatCa = items().map((x) => x.getAttribute('data-val')).filter(Boolean);   // khung gợi ý khi ô trống = mọi tên chuyên quản trong file
  const ten = (a.cq || localStorage.getItem('bhxh_last_cq_name') || '').trim();
  if (!ten) { an(); return { err: 'trong', tatCa }; }
  const want = key(ten);
  const khop = tatCa.includes(ten) ? [ten] : tatCa.filter((v) => key(v) === want);
  if (khop.length !== 1) {
    __bo600rt.setValue(cqInp, ten); an();
    const wW = want.split(' ').filter((w) => w.length > 1);
    const goiY = tatCa.map((v) => ({ v, n: key(v).split(' ').filter((w) => wW.includes(w)).length }))
      .filter((x) => x.n > 0).sort((p, q) => q.n - p.n).slice(0, 5).map((x) => x.v);
    return { err: khop.length > 1 ? 'nhieu' : 'khong_co', ten, goiY, tatCa };
  }
  __bo600rt.setValue(cqInp, khop[0]);
  const pick = items().find((x) => x.getAttribute('data-val') === khop[0]);
  if (pick) pick.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window, button: 0 }));
  an();
  const cqUsed = (cqInp.value || '').trim();
  if (cqUsed !== khop[0]) return { err: 'khong_dien', ten: khop[0] };
  const hint = byId('__bhxh_cq_count_hint');
  if (hint && /Không tìm thấy chuyên quản/i.test(hint.textContent || '')) return { err: 'khong_ma', ten: cqUsed };
  return { ok: true, cqUsed };
}"""
JS_DOC_TEXT = "(s) => { const e = document.querySelector(s); return e ? (e.textContent || '').trim() : ''; }"
JS_XOA_TEXT = "(s) => { const e = document.querySelector(s); if (e) e.textContent = ''; }"
JS_MANAGED = "() => { try { return JSON.parse(localStorage.getItem('bhxh_managed_units') || '[]'); } catch (e) { return []; } }"
JS_TIC_HIEN = "() => !!(document.getElementById('__chkGreen') || document.getElementById('__bhxh_toolbar_bar'))"
JS_KHUNG_HIEN = "() => { const p = document.getElementById('__bhxh_panel'); return !!p && __bo600rt.vis(p); }"


class DonViError(RuntimeError):
    """Lỗi nghiệp vụ của bước 1 (thông báo thẳng cho người dùng)."""


class KhongCoTic(DonViError):
    """Không thấy tiện ích TIC (TienIchChung) trên TNHS. Bước 2 trong chuỗi thì bỏ qua thay vì dừng."""


# =============== phần thuần (test được không cần trình duyệt) ===============
def dam_bao_xlsx(path: str | Path) -> Path:
    """File đọc được bằng openpyxl. TST hay lưu file .xlsx thật nhưng đặt đuôi .xls: openpyxl từ chối theo ĐUÔI file, nên chép sang
    .xlsx cạnh file gốc. .xls cũ thật (OLE) đổi sang .xlsx bằng xlrd (nếu đã cài). File gốc giữ nguyên."""
    p = Path(path)
    head = p.read_bytes()[:8]
    if head[:2] == b"PK":                                   # định dạng xlsx (zip), bất kể đuôi
        if p.suffix.lower() in (".xlsx", ".xlsm"):
            return p
        out = p.with_suffix(".xlsx")
        shutil.copyfile(p, out)
        return out
    if head == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        try:
            import xlrd
            from openpyxl import Workbook
        except ImportError:
            raise DonViError(f"{p.name} là file .xls cũ; cài thêm thư viện xlrd (pip install xlrd) hoặc mở file bằng Excel, "
                             "Lưu thành .xlsx rồi chọn lại.") from None
        out = p.with_suffix(".xlsx")
        book = xlrd.open_workbook(str(p))
        sh = book.sheet_by_index(0)
        wb = Workbook()
        ws = wb.active
        for r in range(sh.nrows):
            ws.append([("" if v is None else v) for v in sh.row_values(r)])
        wb.save(str(out))
        return out
    raise DonViError(f"{p.name} không phải file Excel (.xlsx/.xls).")


def chuan_ma(x) -> str:
    return str(x or "").replace("'", "").strip().upper()


def doi_chieu(codes, managed) -> tuple[list, list]:
    """(thừa, thiếu): thừa = TIC đang giữ mà không thuộc chuyên quản trong file; thiếu = có trong file mà TIC chưa giữ."""
    c = {chuan_ma(x) for x in codes if chuan_ma(x)}
    m = {chuan_ma(x) for x in managed if chuan_ma(x)}
    return sorted(m - c), sorted(c - m)


def loi_chuyen_quan(r: dict) -> str:
    """Đổi kết quả JS_CHON_CHUYEN_QUAN (có khóa err) thành câu báo lỗi cho người dùng."""
    e = r.get("err")
    if e == "trong":
        return "Chưa có tên chuyên quản. Nhập tên ở ô “Chuyên quản” của trang bước 1."
    if e in ("nhieu", "khong_co"):
        gy = r.get("goiY") or []
        return (f'TIC: tên chuyên quản "{r.get("ten")}" ' + ("khớp nhiều tên trong file" if e == "nhieu" else "không có trong file danh sách đơn vị")
                + (" - tên gần giống: " + "; ".join(gy) if gy else "") + ". Sửa tên ở ô “Chuyên quản” rồi chạy lại.")
    if e == "khong_dien":
        return f'TIC: không điền được tên chuyên quản "{r.get("ten")}" vào ô của TIC.'
    if e == "khong_ma":
        return f'TIC: tên chuyên quản "{r.get("ten")}" không có mã nào trong file danh sách đơn vị vừa nạp. Sửa tên ở ô “Chuyên quản” rồi chạy lại.'
    return f"TIC: lỗi chọn chuyên quản ({e})."


# =============== phần trình duyệt ===============
def cho_chu(tab, css: str, rx: str, toi_da: float, mo_ta: str) -> str:
    """Chờ nội dung chữ của phần tử khớp biểu thức (TIC báo kết quả bằng chữ). Bấm Dừng thoát ngay; quá hạn ném GateTimeout."""
    re_ = re.compile(rx)
    t0 = time.monotonic()
    while True:
        t = tab.page.evaluate(JS_DOC_TEXT, css)
        if re_.search(t):
            return t
        if time.monotonic() - t0 > toi_da:
            raise GateTimeout(f"[HT] TIC không báo {mo_ta} sau {round(toi_da)} giây - máy dừng lượt (chạy lại ở lượt sau)")
        tab.sleep(200)


def xuat_tu_tst(ctx, tst, thu_muc: Path) -> Path:
    """TST > Danh mục đơn vị > Xuất File (Danh sách đơn vị, Excel). Trả đường dẫn file đã lưu."""
    ctx.status("Đang xuất danh sách đơn vị trên TST...")
    btn = Target(css='button[ui-sref^="dmDonVi.export"]', ten='nút "Xuất File" ở Danh mục đơn vị')
    tst.cho_on_dinh(btn, toi_da=30, viec="mở Danh mục đơn vị")
    tst.bam_n(btn, viec="Xuất File danh mục đơn vị")
    tst.san_sang(Target(css=".modal", rx="Xuất Báo cáo", ten='hộp thoại "Xuất Báo cáo"'), toi_da=15, viec="mở hộp thoại xuất")
    for name, rx, ten in (("typeReport", r"Danh\s*sách\s*đơn\s*vị", "Danh sách đơn vị"), ("typeFile", r"Excel", "Excel")):
        r = tst.page.evaluate(JS_CHON_RADIO, {"name": name, "rx": rx})
        if not r.get("ok"):
            raise DonViError(f'Không thấy lựa chọn "{ten}" trong hộp thoại xuất báo cáo của TST.')
        tst.sleep(300)                                    # để Angular nhận lựa chọn trước khi bấm tiếp
        if not tst.page.evaluate(JS_RADIO_DA_CHON, {"name": name}):
            raise DonViError(f'Không chọn được "{ten}" trong hộp thoại xuất báo cáo của TST.')
    ex = Target(css='.modal button[ng-click="export()"]', ten='nút "Xuất File" trong hộp thoại')
    ctx.log("Đã chọn Danh sách đơn vị + Excel, bấm Xuất File. Chờ máy chủ tạo file...")
    path = tst.tai_ve_cho(lambda: tst.bam_n(ex, goc=True, viec="Xuất File"), Path(thu_muc) / f"DsDonVi_{date_str()}", toi_da=150, duoi_mac_dinh=".xls")
    ctx.log(f"Đã nhận file danh sách đơn vị: {round(path.stat().st_size / 1024)} KB. Lưu tại: {path}")
    return path


def mo_khung_tic(tnhs) -> None:
    """Mở khung "Đơn vị quản lý" của TIC (thanh xanh -> menu Đơn vị quản lý)."""
    if tnhs.page.evaluate(JS_KHUNG_HIEN):
        return
    try:
        tnhs.bam_n(Target(css="#__chkGreen", ten="thanh công cụ TienIchChung (TIC)"), viec="mở thanh TIC", toi_da=10)
        tnhs.bam_n(Target(css="#__chkDV", ten="menu Đơn vị quản lý của TIC"), viec="mở Đơn vị quản lý (TIC)", toi_da=5)
        tnhs.san_sang(Target(css="#__bhxh_panel", ten='khung "Đơn vị quản lý" của TIC'), viec="mở khung Đơn vị quản lý", toi_da=5)
    except NotReady as e:
        raise DonViError(str(e)) from None


def nap_vao_tic(ctx, tnhs, file: str | Path, cq: str) -> dict:
    """Nạp file vào TIC, chọn chuyên quản, bấm "Lấy mã theo chuyên quản". Trả {read_msg, imp_msg, cq_used, managed}."""
    ctx.status("Đang nạp danh sách đơn vị vào TIC...")
    if not tnhs.page.evaluate(JS_TIC_HIEN):
        try:
            tnhs.san_sang(Target(css="#__chkGreen, #__bhxh_toolbar_bar", ten="thanh công cụ TIC", an=True), toi_da=10)
        except NotReady:
            raise KhongCoTic("Không thấy tiện ích TIC (TienIchChung) trên TNHS. Cài TIC trong Chrome điều khiển được "
                             "(hồ sơ riêng - Chrome 136+ không dùng chung hồ sơ mặc định) rồi tải lại trang TNHS.") from None
    mo_khung_tic(tnhs)
    status = "#__bhxh_import_status"
    tnhs.page.evaluate(JS_XOA_TEXT, status)
    tnhs.tai_len(Target(css="#__bhxh_file_input", an=True, ten="ô chọn file của TIC"), file, toi_da=10)
    read_msg = cho_chu(tnhs, status, r"Đọc xong|Không tìm thấy|Lỗi|chưa sẵn sàng", 60, "kết quả đọc file")
    if "Đọc xong" not in read_msg:
        raise DonViError("TIC: " + read_msg)
    ctx.log("TIC đọc file: " + read_msg)
    tnhs.san_sang(Target(css="#__bhxh_cq_input", ten='ô "Nhập tên chuyên quản" của TIC'), toi_da=5, viec="nhập chuyên quản")
    r = tnhs.page.evaluate(JS_CHON_CHUYEN_QUAN, {"cq": cq})
    if not r.get("ok"):
        raise DonViError(loi_chuyen_quan(r))
    tnhs.sleep(300)
    tnhs.page.evaluate(JS_XOA_TEXT, status)
    tnhs.bam_n(Target(css="#__bhxh_cq_import_btn", ten='nút "Lấy mã theo chuyên quản"'), viec="Lấy mã theo chuyên quản", toi_da=10)
    imp_msg = cho_chu(tnhs, status, r"Thêm|Không tìm thấy", 15, 'kết quả "Lấy mã theo chuyên quản"')
    if "Thêm" not in imp_msg:                             # chỉ khớp "Không tìm thấy"
        raise DonViError("TIC: " + imp_msg)
    managed = tnhs.page.evaluate(JS_MANAGED) or []
    return {"read_msg": read_msg, "imp_msg": imp_msg, "cq_used": r["cqUsed"], "managed": managed}


# =============== bước ===============
def chay_don_vi(ctx, items=None) -> None:
    """Handler đăng ký cho khóa "dv". Không dùng `items` (bước này không theo hồ sơ)."""
    from . import open_session
    s = ctx.cfg.settings()
    saved = ctx.store.kv_get("donvi") or {}
    cq = (s.get("cq") or saved.get("cq") or "").strip()
    tu_xuat = bool(s.get("dv_tu_xuat"))
    file = saved.get("file") or ""
    ctx.log("Tên chuyên quản: " + (cq or "(dùng tên TIC đang lưu)") + " · Nguồn file: " + ("tự xuất từ TST" if tu_xuat else file or "(chưa chọn)"))
    if not tu_xuat and not (file and Path(file).is_file()):
        raise DonViError("Chưa chọn file danh mục đơn vị (hoặc file không còn). Chọn file ở trang bước 1, hoặc tick “Tự tải file từ TST”.")

    with open_session(ctx) as br:
        if tu_xuat:
            tst = mo_cong(br, "tst", TST_DM_DON_VI)
            file = str(xuat_tu_tst(ctx, tst, ctx.store.paths.danhmuc))
        ctx.check_stop()
        tnhs = mo_cong(br, "tnhs", TNHS_HASH)
        r = nap_vao_tic(ctx, tnhs, file, cq)

    cq_used, managed = r["cq_used"], r["managed"]
    ctx.log(f'TIC "Lấy mã theo chuyên quản" "{cq_used}": {r["imp_msg"]}')

    codes = None
    try:
        codes = sorted(codes_of_cq(dam_bao_xlsx(file), cq_used))
    except Exception as e:                                    # noqa: BLE001 - không đối chiếu được thì chỉ báo, không làm hỏng bước
        ctx.log(f"Không đối chiếu được mã thừa/thiếu: {e}")
    thua = thieu = []
    if codes is not None:
        thua, thieu = doi_chieu(codes, managed)
        ctx.log(f"Mã đơn vị của chuyên quản trong file: {len(codes)}; TIC đang giữ: {len(managed)}; mã thừa: {len(thua)}; mã thiếu: {len(thieu)}")
        if thua:
            ctx.log("Mã thừa (có trong TIC, không thuộc chuyên quản trong file mới; máy không tự xóa): " + ", ".join(thua))
        if thieu:
            ctx.log("CẢNH BÁO: mã có trong file nhưng TIC chưa giữ: " + ", ".join(thieu[:30]) + (" ..." if len(thieu) > 30 else ""))

    saved = ctx.store.kv_get("donvi") or {}
    saved.update(file=file, cq=cq_used, at=now_vn())
    if codes is not None:
        saved["codes"] = codes
    saved["tic"] = {"at": now_vn(), "cq": cq_used, "n_giu": len(managed), "thua": thua, "thieu": thieu,
                    "doc": r["read_msg"], "lay_ma": r["imp_msg"], "tu_xuat": tu_xuat}
    ctx.store.kv_set("donvi", saved)
    if not s.get("cq"):
        ctx.cfg.save_settings({"cq": cq_used})
    ctx.status("Đã cập nhật danh sách đơn vị quản lý")
