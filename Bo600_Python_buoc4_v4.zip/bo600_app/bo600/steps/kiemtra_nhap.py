"""Bước 4 - kiểm tra nháp hồ sơ D02 trên TST; tuyệt đối không Lưu/import.

Bản v3: viết lại bám sát tiện ích Chrome (m2_ktn.js + content.js: tst_import_run).
 - Trang import được dùng lại giữa các hồ sơ: XÓA mã ĐV cũ trước khi nạp file mới,
   và chỉ nhận tên ĐV / bảng dòng khi đã có phản hồi MỚI của TST (findByMaAndDmBHXH, import/uploadV2).
 - Chờ hoàn tất Kiểm tra bằng: phản hồi /import/check + ô tích mở khóa + bảng yên (MutationObserver trong trang).
 - Mọi thao tác đọc trạng thái trang gom vào 1 lệnh page.evaluate (không gọi từng ô như bản cũ) nên nhanh hơn nhiều.
 - Kết quả lưu đủ cho bước 7 (rules.py): rows[i] = {maso, tu, den, mucmoi, pa, tich, mau, loi, fp, maSrv, tinhLaiTst, trung},
   donVi {khoi, tyle, ngayTang, loaiDn}; đối chiếu sổ cái -> KTN_DUP.
Tùy chọn trong Cài đặt (không bắt buộc): ktn_quiet_ms (mặc định 2500) = thời gian bảng phải yên sau Kiểm tra.
"""
from __future__ import annotations
import hashlib, re, time
from datetime import datetime
from ..browser import Target
from ..d02_io import read_d02, inspect_luong
from ..model import KTN_OK, KTN_RED, KTN_ERR, KTN_DUP
from ..util import now_vn
from . import mo_cong

IMPORT_ML = '#/psTbbImportV2s/ML'
IMPORT_HS = '#/psTbbImportV2s/HS'
SAVE_API = r'/api/importTbb/import/?$'
DV_RX = r'findByMaAndDmBHXH/?(\?|$)'
KHOI_RX = r'find-by-ky-and-khoi-ql/?(\?|$)'
UPLOAD_RX = r'/import/uploadV2/?(\?|$)'
CHECK_RX = r'/import/check/?(\?|$)'
SYS_WAIT = 300

GUARD_JS = r"""() => {
 const H=document.documentElement; H.setAttribute('data-bo600-nosave','1');
 let s=document.getElementById('__bo600_py_nosave_css');
 if(!s){s=document.createElement('style');s.id='__bo600_py_nosave_css';s.textContent='html[data-bo600-nosave="1"] button[ng-click="save()"]{pointer-events:none!important;opacity:.35!important}';(document.head||H).appendChild(s)}
 let b=document.getElementById('__bo600_py_nosave_banner');if(!b){b=document.createElement('div');b.id='__bo600_py_nosave_banner';b.textContent='BỘ 600: ĐANG KIỂM TRA NHÁP — NÚT LƯU ĐÃ KHÓA';b.style.cssText='position:fixed;z-index:2147483647;top:5px;left:50%;transform:translateX(-50%);background:#b42318;color:white;padding:7px 14px;font: bold 13px Arial;border-radius:5px';document.body.appendChild(b)}
 if(!window.__bo600PySaveGuard){window.__bo600PySaveGuard=true;['click','mousedown','mouseup','keydown'].forEach(t=>document.addEventListener(t,e=>{if(H.getAttribute('data-bo600-nosave')==='1'&&e.target.closest&&e.target.closest('button[ng-click="save()"]')){e.preventDefault();e.stopImmediatePropagation()}},true))}
 return true;
}"""
CLEAR_GUARD_JS = r"""() => {document.documentElement.removeAttribute('data-bo600-nosave');const b=document.getElementById('__bo600_py_nosave_banner');if(b)b.remove();}"""

# Bộ đọc trạng thái chạy TRONG trang (cài một lần, idempotent). Mỗi lần gọi = 1 vòng gọi trình duyệt.
KTN_JS = r"""() => {
 if (window.__ktn && window.__ktn.v === 3) return true;
 const K = window.__ktn = { v: 3, lastMut: Date.now(), sawLock: false, obs: null };
 const txt = (el) => (el ? (el.textContent || '').replace(/\s+/g, ' ').trim() : '');
 const vis = (el) => { if (!el) return false; const s = getComputedStyle(el); if (s.display === 'none' || s.visibility === 'hidden') return false; return el.offsetParent !== null || s.position === 'fixed'; };
 const boxes = () => [...document.querySelectorAll('tbody tr input[ng-model="mucLuong.checkBox"]')];
 K.btn = (sel) => { const b = document.querySelector(sel); return !!b && vis(b) && !b.disabled; };
 K.dv = () => { const a = document.getElementById('field_dmDonVi'), t = document.getElementById('field_tenDvi'); return { has: !!a, ma: a ? a.value.trim() : '', ten: t ? t.value.trim() : '' }; };
 K.sheet = () => {
   const s = document.getElementById('field_sheet'); if (!s) return null;
   const o = [...s.options]; const i = o.findIndex((x) => /^\s*D02\s*$/i.test(x.textContent));
   return { n: o.length, has: i >= 0, value: i >= 0 ? o[i].value : null, cur: i >= 0 && s.selectedIndex === i, anyD02: o.some((x) => /D02/i.test(x.textContent)) };
 };
 K.state = () => {
   const b = boxes(); let locked = 0, unticked = 0;
   for (const x of b) { if (x.disabled) locked++; if (!x.checked) unticked++; }
   if (locked) K.sawLock = true;
   return { n: b.length, locked, unticked, mutAge: Date.now() - K.lastMut, sawLock: K.sawLock };
 };
 K.modal = () => {
   const ms = [...document.querySelectorAll('.modal')].filter((m) => vis(m) && m.querySelector('button'));
   if (!ms.length) return null;
   const m = ms[ms.length - 1]; return { text: txt(m.querySelector('.modal-body')) || txt(m), n: ms.length };
 };
 K.anyModal = () => [...document.querySelectorAll('.modal')].filter(vis).length;
 K.watch = (all) => {
   if (K.obs) K.obs.disconnect();
   const b0 = boxes()[0]; const t = (b0 && b0.closest('table')) || document.body;
   K.lastMut = Date.now(); K.sawLock = false;
   K.obs = new MutationObserver(() => { K.lastMut = Date.now(); if (boxes().some((b) => b.disabled)) K.sawLock = true; });
   const o = { subtree: true, childList: true, characterData: true, attributes: true };
   if (!all) o.attributeFilter = ['disabled', 'class'];
   K.obs.observe(t, o);
 };
 K.unwatch = () => { if (K.obs) { K.obs.disconnect(); K.obs = null; } };
 K.table = () => {
   const tables = [...document.querySelectorAll('table')];
   const data = tables.find((t) => t.querySelector('tbody tr input[ng-model="mucLuong.checkBox"]'));
   if (!data) return null;
   const hc = (t) => { const th = t.querySelectorAll('thead tr'); if (th.length) return [...th[th.length - 1].querySelectorAll('th,td')].map(txt); const tr = t.querySelector('tr'); return tr ? [...tr.querySelectorAll('th,td')].map(txt) : []; };
   let head = hc(data);
   if (!head.some((h) => /Phát\s*hiện\s*lỗi/i.test(h))) { const ht = tables.find((t) => hc(t).some((h) => /Phát\s*hiện\s*lỗi/i.test(h))); if (ht) head = hc(ht); }
   const col = (re) => head.findIndex((h) => re.test(h));
   const ci = { maso: col(/^Mã\s*số/i), hoten: col(/^Họ\s*tên/i), tu: col(/^Từ\s*tháng/i), den: col(/^Đến\s*tháng/i),
     mucmoi: col(/^Mức\s*mới/i) >= 0 ? col(/^Mức\s*mới/i) : col(/^Hệ\s*số\s*lương$/i), pa: col(/^PA$/i), loi: col(/Phát\s*hiện\s*lỗi/i) };
   const rows = [...data.querySelectorAll('tbody tr')].filter((tr) => tr.querySelector('td'));
   const out = rows.map((tr, i) => {
     const c = [...tr.querySelectorAll('td')].map(txt);
     const off = c.length - head.length;
     const g = (k) => (ci[k] >= 0 ? (c[ci[k] + (off > 0 ? off : 0)] || '') : '');
     const cls = tr.className || ''; const cb = tr.querySelector('input[ng-model="mucLuong.checkBox"]');
     return { stt: i + 1, tich: cb ? (cb.checked ? 'Có' : 'Không') : '', maso: g('maso'), hoten: g('hoten'), tu: g('tu'), den: g('den'),
       mucmoi: g('mucmoi'), pa: g('pa'), loi: ci.loi >= 0 ? g('loi') : (off >= 0 ? c[c.length - 1] : ''),
       mau: /\bdanger\b/.test(cls) ? 'Đỏ' : (/\bwarning\b/.test(cls) ? 'Vàng' : ''), cells: c };
   });
   return { head, colLoi: ci.loi, rows: out };
 };
 return true;
}"""


# ---------------------------------------------------------------- tiện ích nhỏ
def _norm_thang(s) -> str:
    """Như normThang của tiện ích: về dạng yyyymm."""
    s = str(s if s is not None else '').strip()
    m = re.match(r'^(\d{4})(\d{2})$', s)
    if m: return m.group(1) + m.group(2)
    m = re.match(r'^(\d{1,2})/(\d{4})$', s)
    if m: return m.group(2) + m.group(1).zfill(2)
    m = re.match(r'^(\d{4})-(\d{2})', s)
    if m: return m.group(1) + m.group(2)
    return s

def row_fp(maso, tu, den) -> str:
    """Vân tay dòng - giống rowFp của tiện ích (SHA-256 của bo600|MASO|tu|den, lấy 10 byte đầu)."""
    t = 'bo600|' + str(maso or '').strip().upper() + '|' + _norm_thang(tu) + '|' + _norm_thang(den)
    return hashlib.sha256(t.encode('utf-8')).digest()[:10].hex()

def _num(v) -> float:
    try: return float(v)
    except (TypeError, ValueError): return 0.0

def _json(hit):
    try: return hit.json() if hit is not None else None
    except Exception: return None

def _wait(ctx, tab, predicate, timeout=SYS_WAIT, label='chờ trang', step_ms=120):
    end = time.monotonic() + timeout
    while True:
        ctx.check_stop()
        try:
            val = predicate()
            if val: return val
        except Exception:
            pass
        if time.monotonic() >= end: break
        tab.sleep(step_ms)
    raise RuntimeError(f'[HT] Hết thời gian {timeout}s khi {label}.')

def _toast_txt(tab, mark) -> str:
    try: return ' | '.join(tab.toasts_since(mark)) or 'không có'
    except Exception: return 'không có'

def _xu_ly_hop_thoai(ctx, tab, R) -> bool:
    """Hộp thoại đã có quy tắc: Cv2745 -> Bỏ qua; không khớp định danh -> Không; còn lại dừng. True nếu đã xử lý 1 hộp thoại."""
    m = tab.page.evaluate('__ktn.modal()')
    if not m: return False
    mt = m['text']
    if re.search(r'Cv\s*2745', mt, re.I): choice = 'Bỏ qua'
    elif re.search(r'không\s*khớp\s*thông\s*tin\s*định\s*danh', mt, re.I): choice = 'Không'
    else: raise RuntimeError('Gặp hộp thoại lạ, dừng để người xem: "' + mt[:200] + '"')
    btn = tab.page.locator('.modal:visible').last.get_by_role('button', name=re.compile(r'^\s*' + re.escape(choice) + r'\s*$', re.I)).first
    if not btn.count(): raise RuntimeError(f'Hộp thoại yêu cầu chọn “{choice}” nhưng không thấy nút tương ứng: ' + mt[:150])
    btn.click(); tab._touch()
    R['popups'].append('"' + re.sub(r'^Thông báo\s*', '', mt)[:70] + '" → ' + choice)
    tab.sleep(500)
    return True


def _luong_cua(ctx, lot, it) -> str:
    """Loại lương của hồ sơ: 'HS' -> trang import HS (hệ số lương), còn lại -> trang ML (mức lương), như importHash của tiện ích.
    Hồ sơ tải từ trước khi có phân loại (chưa có it['luong']) thì đọc lại file D02 trên máy để phân loại."""
    lg = str(it.get('luong') or '')
    if not lg:
        try: lg = inspect_luong(read_d02(ctx.store.paths.item_path(lot['id'], it.get('file', ''))))
        except Exception: lg = '?'
        it['luong'] = lg
    return lg

def _trang_cua(lg: str) -> str:
    return 'HS' if lg == 'HS' else 'ML'

# ---------------------------------------------------------------- một hồ sơ
def _run_one(ctx, tab, lot, it, R):
    """Chạy kiểm tra nháp một hồ sơ. R là dict kết quả dở dang do nơi gọi giữ để còn ghi lại khi lỗi."""
    path = ctx.store.paths.item_path(lot['id'], it.get('file', ''))
    if not path.is_file(): raise RuntimeError(f'Không tìm thấy file D02: {path}. Chạy lại bước 3 để tải file.')
    if path.suffix.lower() not in ('.xlsx', '.xls'): raise RuntimeError(f'File D02 không phải Excel: {path.name}')
    luong = _trang_cua(_luong_cua(ctx, lot, it)); hash_ = IMPORT_HS if luong == 'HS' else IMPORT_ML
    madv = str(it.get('madonvi') or '').strip()
    quiet = max(800, int(ctx.cfg.settings().get('ktn_quiet_ms', 2500))) / 1000
    page = tab.page
    started = time.monotonic(); blk0 = len(tab.net.blocked); tmark = tab.toast_mark()
    R.update({'page': 'HS' if luong == 'HS' else 'ML', 'stage': 'mở màn import'})

    tab.goto_hash(hash_)
    tab.cho_on_dinh(Target(css='input[type="file"][ng-model="file"]', ten='ô chọn file D02', an=True), toi_da=30, viec='mở màn Import TST')
    page.evaluate(KTN_JS)
    page.evaluate(GUARD_JS)
    # Chặn cả nút Lưu lẫn endpoint POST import thật; luôn gỡ trong finally.
    tab.net.block(SAVE_API, methods=('POST',), label='Bước 4 kiểm tra nháp - cấm Lưu')
    try:
        if page.evaluate('__ktn.anyModal()'): raise RuntimeError('Màn Import đang có hộp thoại mở sẵn; xử lý hộp thoại rồi chạy lại.')

        # ---- nạp file. Trang dùng lại: xóa mã ĐV của hồ sơ trước để không đọc nhầm mã cũ ----
        R['stage'] = 'nạp file'
        dv_cu = page.evaluate('__ktn.dv()')
        reuse = bool(getattr(tab, '_bo600_ktn_used', False)) or bool(dv_cu['ma'])
        dv = page.locator('#field_dmDonVi')
        if dv_cu['ma']:
            dv.fill('')
            for ev in ('input', 'change', 'blur'): dv.dispatch_event(ev)
            tab._touch(); tab.sleep(250)
        t0 = time.monotonic()
        page.locator('input[type="file"][ng-model="file"]').set_input_files(str(path))
        tab._bo600_ktn_used = True; tab._touch()
        _wait(ctx, tab, lambda: (page.evaluate('__ktn.sheet()') or {}).get('anyD02'), SYS_WAIT,
              'trang đọc danh sách sheet của file (không thấy sheet D02)')

        # ---- mã đơn vị ----
        R['stage'] = 'mã đơn vị'
        _wait(ctx, tab, lambda: page.evaluate('__ktn.dv()')['has'], 20, 'tìm ô mã đơn vị (#field_dmDonVi)')
        cho_ms = 800 if getattr(tab, '_bo600_noauto', 0) >= 2 else 3000   # TST không tự điền thì khỏi chờ lâu
        try: _wait(ctx, tab, lambda: page.evaluate('__ktn.dv()')['ma'], cho_ms / 1000, 'chờ TST tự điền mã đơn vị')
        except RuntimeError: pass
        cur = page.evaluate('__ktn.dv()')['ma']
        t_dv = t0
        # TST đôi khi tự điền mã kèm "_" (ví dụ TN5159N_): chỉ sửa khi bỏ "_" cuối thì khớp đúng hồ sơ.
        if not cur or (cur.upper() != madv.upper() and cur.rstrip('_').upper() == madv.upper()):
            if not cur:
                tab._bo600_noauto = getattr(tab, '_bo600_noauto', 0) + 1
                R['steps'].append('Bộ 600 tự điền mã ĐV')
            dv.fill(madv)
            for ev in ('input', 'change', 'blur'): dv.dispatch_event(ev)
            tab._touch(); t_dv = time.monotonic()
            cur = page.evaluate('__ktn.dv()')['ma']
        else:
            tab._bo600_noauto = 0
        R['madvPage'] = cur
        if cur.upper() != madv.upper():
            raise RuntimeError(f'Mã ĐV trên trang ({cur}) khác mã ĐV của hồ sơ trong lô ({madv}); dừng hồ sơ này để tránh nhầm đơn vị.')
        # Có tên = TST nhận mã; TST đã trả lời mà không có tên = không nhận mã; trang dùng lại: bắt buộc có phản hồi MỚI.
        end = time.monotonic() + SYS_WAIT; ten = ''
        while True:
            ctx.check_stop()
            ten = page.evaluate('__ktn.dv()')['ten']; hit = tab.net.find(DV_RX, since=t_dv)
            if ten and (not reuse or hit): break
            if hit and not ten and time.monotonic() - hit.ts > 3:
                raise RuntimeError(f'Trang không nhận mã đơn vị {cur} (không hiện tên đơn vị). Thông báo: {_toast_txt(tab, tmark)}')
            if time.monotonic() > end: raise RuntimeError(f'[HT] Sau {SYS_WAIT} giây trang chưa trả lời tên đơn vị cho mã {cur}.')
            tab.sleep(120)
        R['tenDvi'] = ten

        # ---- chọn sheet D02 ----
        R['stage'] = 'chọn sheet D02'
        sh = page.evaluate('__ktn.sheet()')
        if not sh or not sh['has']: raise RuntimeError('Không có sheet tên D02 trong file.')
        if not sh['cur']:
            sel = page.locator('#field_sheet'); sel.select_option(sh['value']); sel.dispatch_event('change'); tab._touch()

        # ---- Đọc ----
        R['stage'] = 'Đọc'
        try:
            _wait(ctx, tab, lambda: page.evaluate('(s) => __ktn.btn(s)', 'button[ng-click="getMaQt()"]'), 15, 'nút Đọc sẵn sàng')
        except RuntimeError:
            raise RuntimeError('Nút Đọc vẫn bị khóa (thiếu đơn vị/tháng/năm/sheet hoặc tỷ lệ thu không hợp lệ). Thông báo: ' + _toast_txt(tab, tmark))
        page.evaluate('__ktn.watch(false)')
        t_read = time.monotonic()
        page.locator('button[ng-click="getMaQt()"]').click(); tab._touch()
        # Xong = bảng có dòng; trang dùng lại: bắt buộc có tín hiệu uploadV2 HTTP 200 SAU lúc bấm (không nhận bảng cũ).
        end = time.monotonic() + SYS_WAIT; n_rows = 0
        while True:
            ctx.check_stop()
            up = tab.net.find(UPLOAD_RX, since=t_read)
            if up is not None and up.status != 200:
                raise RuntimeError(f'[HT] Đọc file lỗi (mã {up.status}). Thông báo: {_toast_txt(tab, tmark)}')
            n_rows = page.evaluate('__ktn.state()')['n']
            if n_rows and (not reuse or up is not None): break
            if time.monotonic() > end:
                raise RuntimeError(f'[HT] Bấm Đọc nhưng sau {SYS_WAIT} giây bảng chưa có dòng nào. Thông báo: {_toast_txt(tab, tmark)}')
            tab.sleep(120)
        if up is None: R['steps'].append('không bắt được tín hiệu Đọc, xác nhận bằng bảng có dòng')
        R['rowsRead'] = n_rows
        # Chờ bảng yên sau khi đọc (thay cho sleep cố định)
        _wait(ctx, tab, lambda: page.evaluate('__ktn.state()')['mutAge'] >= 600, 20, 'bảng yên sau khi Đọc')

        # ---- Kiểm tra ----
        R['stage'] = 'Kiểm tra'
        KT = 'button[ng-click="kiemTra()"]'
        def _kt_ready(): return page.evaluate('(s) => __ktn.btn(s)', KT)
        try: _wait(ctx, tab, _kt_ready, 8, 'nút Kiểm tra sẵn sàng')
        except RuntimeError:
            allbox = page.locator('input[ng-model="checkBox"]:visible').first
            if allbox.count() and not allbox.is_checked(): allbox.click(force=True); tab._touch(); tab.sleep(400)
            try: _wait(ctx, tab, _kt_ready, 5, 'nút Kiểm tra sẵn sàng (sau khi tích tất cả)')
            except RuntimeError: raise RuntimeError('Nút Kiểm tra vẫn bị khóa. Thông báo: ' + _toast_txt(tab, tmark))
        page.evaluate('__ktn.watch(false)')
        t_check = time.monotonic(); last_act = t_check
        page.locator(KT).click(); tab._touch()
        # Kết luận "đã kiểm tra xong": có phản hồi /import/check sau lúc bấm, ô tích dòng đã mở khóa,
        # không còn hộp thoại, bảng yên >= quiet. Không dựa vào nút Lưu, không dựa vào cột lỗi.
        chk = None; saw_lock = False
        end = t_check + SYS_WAIT
        while time.monotonic() < end:
            ctx.check_stop(); tab.sleep(150)
            if _xu_ly_hop_thoai(ctx, tab, R): last_act = time.monotonic(); continue
            if chk is None:
                chk = tab.net.find(CHECK_RX, since=t_check)
                if chk is not None: last_act = time.monotonic()
            if chk is None: continue
            if chk.status != 200: raise RuntimeError(f'[HT] Kiểm tra lỗi (mã {chk.status}). Thông báo: {_toast_txt(tab, tmark)}')
            s = page.evaluate('__ktn.state()'); saw_lock = s['sawLock']
            if s['n'] > 0 and s['locked'] == 0 and time.monotonic() - last_act >= quiet and s['mutAge'] / 1000 >= quiet: break
        if chk is None: raise RuntimeError(f'[HT] Không xác nhận được kết quả Kiểm tra: sau {SYS_WAIT} giây không thấy phản hồi /import/check.')
        s = page.evaluate('__ktn.state()')
        if s['locked']: raise RuntimeError(f'[HT] Không xác nhận được kết quả Kiểm tra: sau {SYS_WAIT} giây các dòng vẫn bị khóa (trang còn đang kiểm tra).')
        R['signals'] = f'POST /import/check HTTP {chk.status}' + (', thấy khóa/mở ô tích' if saw_lock else ', không thấy pha khóa ô tích')

        # ---- tích đủ dòng (sau "Bỏ qua" Cv2745 trang bỏ tích dòng trùng) ----
        R['stage'] = 'tích đủ dòng'
        R['rowsTotal'] = s['n']; R['rowsUnticked'] = s['unticked']; R['tickAll'] = 0
        for _ in range(3):
            s = page.evaluate('__ktn.state()')
            if not s['unticked']: break
            head = page.locator('thead input[ng-model="checkBox"],input[ng-model="checkBox"][ng-change^="selectAll"]')
            if not head.count(): raise RuntimeError('Không thấy ô tích tất cả ở dòng tiêu đề bảng.')
            if head.first.is_disabled(): raise RuntimeError('Ô tích tất cả đang bị khóa.')
            page.evaluate('__ktn.watch(true)')
            head.first.click(force=True); tab._touch(); R['tickAll'] += 1
            t_tick = time.monotonic(); last_act = t_tick
            while time.monotonic() - t_tick < 15:
                ctx.check_stop(); tab.sleep(150)
                if _xu_ly_hop_thoai(ctx, tab, R): last_act = time.monotonic(); continue
                s = page.evaluate('__ktn.state()')
                if s['locked'] == 0 and s['mutAge'] >= 1500 and time.monotonic() - last_act >= 1.0: break
        s = page.evaluate('__ktn.state()')
        if s['unticked']:
            raise RuntimeError(f"Đã bấm ô tích tất cả {R['tickAll']} lần nhưng vẫn còn {s['unticked']}/{s['n']} dòng chưa tích.")
        R['rowsTicked'] = s['n'] - s['unticked']

        # ---- đọc kết quả (1 lệnh) ----
        R['stage'] = 'đọc kết quả'
        tb = page.evaluate('__ktn.table()')
        if not tb: raise RuntimeError('Không đọc được bảng kết quả Kiểm tra.')
        rows = tb['rows']
        for r in rows: r['fp'] = row_fp(r['maso'], r['tu'], r['den'])
        # Dữ liệu trang đã tải: mã máy chủ từng dòng, TINHLAI do TST tính, quá trình/thẻ trùng 2745, đơn vị, khối, tỷ lệ
        try:
            cj = _json(chk); cj = cj if isinstance(cj, dict) else {}
            uj = _json(tab.net.find(UPLOAD_RX, since=t_read))
            dtl = cj['psTbbDtls'] if isinstance(cj.get('psTbbDtls'), list) else (uj if isinstance(uj, list) else [])
            trung = {}
            for x in (cj.get('dsTrung2745DTOS') or []):
                k = str(x.get('soSoBhxh') or '')
                tn = (x.get('tuNgay') or ''); dn = (x.get('denNgay') or '')
                trung.setdefault(k, []).append(f"{x.get('maDmBhxh') or ''}/{x.get('maDonVi') or ''}" + (f' ({tn}-{dn})' if tn or dn else ''))
            for i, r in enumerate(rows):
                d = dtl[i] if i < len(dtl) and isinstance(dtl[i], dict) else {}
                r['maSrv'] = '' if d.get('soSoBhxh') is None else str(d.get('soSoBhxh'))
                r['tinhLaiTst'] = '' if d.get('tinhLai') is None else str(d.get('tinhLai'))
                r['trung'] = '; '.join(trung.get(r['maSrv'], []))
            dvj = _json(tab.net.find(DV_RX, since=t0)); dvj = dvj if isinstance(dvj, dict) else {}
            khj = _json(tab.net.find(KHOI_RX, since=t0)); khj = khj if isinstance(khj, dict) else {}
            kq = khj.get('dmKhoiQl') if isinstance(khj.get('dmKhoiQl'), dict) else None
            tyle = round((_num(khj.get('tyle_bhxh')) + _num(khj.get('tyle_bhyt')) + _num(khj.get('tyle_bhtn')) + _num(khj.get('tyle_tnld'))) * 100) / 100
            R['donVi'] = {'ngayTang': dvj.get('ngayTang') or '', 'loaiDn': dvj.get('loaiDn') or '',
                          'khoi': ((kq.get('ma') or '') + ' - ' + (kq.get('ten') or '')) if kq else '',
                          'tyle': (('%g' % tyle) if (kq or khj.get('tyle_bhxh') is not None) else '')}
        except Exception as e:
            R['steps'].append('không đọc được dữ liệu kiểm tra của trang: ' + str(e))
        if tb['colLoi'] < 0: R['steps'].append('không thấy cột "Phát hiện lỗi" theo tiêu đề, lấy ô cuối dòng')
        R['rows'] = rows
        R['red'] = sum(1 for r in rows if r['mau'] == 'Đỏ'); R['yellow'] = sum(1 for r in rows if r['mau'] == 'Vàng')
        R['blocked'] = len(tab.net.blocked) - blk0
        R['toasts'] = ' | '.join(tab.toasts_since(tmark))
        R['secs'] = round(time.monotonic() - started)
        return R
    finally:
        try: page.evaluate('__ktn.unwatch()')
        except Exception: pass
        tab.net.unblock(SAVE_API)
        try: page.evaluate(CLEAR_GUARD_JS)
        except Exception: pass


def _ket_luan(ctx, it, R) -> dict:
    """Từ R dở dang -> dict kết quả cuối (trạng thái, ghi chú, đối chiếu sổ cái) như ktnItem của tiện ích."""
    red, vang = R['red'], R['yellow']
    res = {'at': now_vn(), 'page': R['page'], 'secs': R.get('secs', ''), 'madvPage': R['madvPage'], 'tenDvi': R['tenDvi'],
           'rowsRead': R['rowsRead'], 'rowsD02': it.get('rows', ''), 'rowsTicked': R.get('rowsTicked', ''),
           'untickedAfterKt': R.get('rowsUnticked', ''), 'tickAll': R.get('tickAll', 0), 'red': red, 'yellow': vang,
           'popups': ' | '.join(R['popups']), 'toasts': R.get('toasts', ''), 'blocked': R.get('blocked', 0),
           'signals': R.get('signals', ''), 'dupRows': 0, 'dupNote': '', 'donVi': R.get('donVi'), 'rows': R['rows'], 'note': ''}
    notes = []
    res['status'] = KTN_RED if red else KTN_OK
    # Dòng trùng vân tay với dòng đã lưu trong sổ cái
    try:
        by_fp = ctx.socai.idx['byFp']
        dup = [r for r in R['rows'] if r.get('fp') and r['fp'] in by_fp]
    except Exception:
        by_fp, dup = {}, []
    if dup:
        es = []
        for r in dup:
            for e in by_fp[r['fp']]:
                if e not in es: es.append(e)
        res['dupRows'] = len(dup)
        res['dupNote'] = (f'{len(dup)} dòng trùng dòng đã lưu trong sổ cái (' + '; '.join(
            ('máy' if e.get('who') == 'may' else 'người') + ' lưu ' + str(e.get('at', '')) +
            (' hồ sơ ' + ', '.join(e['sohosos']) if e.get('sohosos') else '') for e in es) + ')')
        res['status'] = KTN_DUP + (', còn lỗi đỏ' if red else '')
        notes.append(res['dupNote'])
    if R.get('tickAll'): notes.append(f"sau Kiểm tra có {R.get('rowsUnticked')} dòng bị bỏ tích, đã bấm tích tất cả {R['tickAll']} lần")
    vl = [r for r in R['rows'] if r['mau'] == 'Vàng']
    if vl:
        notes.append(f'{len(vl)} dòng vàng: ' + ' / '.join(dict.fromkeys(r['loi'] for r in vl if r['loi']))[:300])
    notes += [x for x in R['steps'] if re.search(r'không bắt được tín hiệu', x)]
    if it.get('luong') and it.get('luong') not in ('ML', 'HS'): notes.append(f'loại lương "{it.get("luong")}", đã kiểm tra trên trang ML')
    if 'Bộ 600 tự điền mã ĐV' in R['steps']: notes.append('trang không tự điền mã ĐV (không thấy ext4), Bộ 600 đã điền ' + str(it.get('madonvi')))
    if res['blocked']: notes.append(f"đã chặn {res['blocked']} lần bấm/gửi Lưu")
    rd, rt_ = R.get('rowsRead'), it.get('rows', '')
    if rd and rt_ not in ('', None) and str(rd) != str(rt_): notes.append(f'trang đọc {rd} dòng, file có {rt_} dòng')
    if res['rowsTicked'] != '' and rt_ not in ('', None) and str(res['rowsTicked']) != str(rt_):
        notes.append(f"LỆCH: tích {res['rowsTicked']} dòng, D02 có {rt_} dòng (import thật sẽ không lưu)")
    res['note'] = '; '.join(notes)
    return res


# ---------------------------------------------------------------- bước chạy
def chay_kiem_tra_nhap(ctx, items=None):
    store = ctx.store
    if items is None:
        candidates = store.all_items()
    else:
        ids = {str(x.get('id')) for x in items if isinstance(x, dict)}
        candidates = [(l, it) for l, it in store.all_items() if str(it.get('id')) in ids]
    todo = []; sai_trang = []
    for lot, it in candidates:
        if lot.get('status') == 'closed' or it.get('status') != 'Đã tải': continue
        if it.get('nguoiLam', {}).get('ktn'): continue
        st = (it.get('ktn') or {}).get('status', '')
        if not st or st == KTN_ERR or not re.match(r'^(Đạt|Không đạt|Đã lưu)', st): todo.append((lot, it)); continue
        # Đã có kết quả nhưng kiểm tra nhầm trang (ML/HS) do trước đây chưa phân loại lương -> kiểm tra lại đúng trang
        had = bool(it.get('luong'))
        lg = _luong_cua(ctx, lot, it)
        if not had: store.save_lot(lot)
        if (it.get('ktn') or {}).get('page') and (it['ktn'].get('page') != _trang_cua(lg)):
            sai_trang.append(it.get('sohoso', '?')); todo.append((lot, it))
    ctx.log('BƯỚC 4: KIỂM TRA NHÁP TRÊN TST — KHÔNG LƯU. Nút Lưu và API import thật bị khóa.')
    ctx.log(f'{len(todo)} hồ sơ đã tải cần kiểm tra.')
    if sai_trang: ctx.log(f'{len(sai_trang)} hồ sơ trước đây kiểm tra nhầm trang ML/HS, sẽ kiểm tra lại đúng trang: ' + ', '.join(sai_trang[:15]) + ('…' if len(sai_trang) > 15 else ''))
    if not todo:
        ctx.log('Không có hồ sơ phù hợp. Chỉ kiểm tra hồ sơ có trạng thái “Đã tải” và chưa có kết quả kiểm tra nháp.')
        return
    with __import__('bo600.steps', fromlist=['open_session']).open_session(ctx) as br:
        tab = mo_cong(br, 'tst')
        for ix, (lot, it) in enumerate(todo, 1):
            ctx.check_stop(); so = it.get('sohoso', '?')
            ctx.status(f'Kiểm tra nháp {so} ({ix}/{len(todo)})')
            ctx.log(f'[{ix}/{len(todo)}] Bắt đầu {so} — ĐV {it.get("madonvi", "")}')
            R = {'page': _trang_cua(it.get('luong')), 'stage': '', 'steps': [], 'popups': [], 'madvPage': '', 'tenDvi': '',
                 'rowsRead': '', 'red': '', 'yellow': '', 'rows': []}
            try:
                _run_one(ctx, tab, lot, it, R)
                res = _ket_luan(ctx, it, R)
                it['ktn'] = res; it['ktnTs'] = int(datetime.now().timestamp() * 1000); it['ktnN'] = int(it.get('ktnN') or 0) + 1
                store.save_lot(lot)
                store.kv_set(f"ktn:{lot['id']}:{it['id']}", res.get('rows') or [])
                ctx.log(f"Kết quả {so}: {res['status']}; trang {res['page']}; dòng {res['rowsRead']}; đỏ {res['red']}; vàng {res['yellow']}; {res['secs']}s"
                        + (f"; hộp thoại: {res['popups']}" if res['popups'] else '') + (f"; {res['note']}" if res['note'] else ''))
            except Exception as e:
                if ctx.runner.stop_flag.is_set(): raise
                it['ktn'] = {'status': KTN_ERR, 'note': (f"[{R['stage']}] " if R.get('stage') else '') + str(e), 'at': now_vn(),
                             'page': R['page'], 'madvPage': R['madvPage'], 'tenDvi': R['tenDvi'], 'popups': ' | '.join(R['popups'])}
                it['ktnTs'] = int(datetime.now().timestamp() * 1000); store.save_lot(lot)
                ctx.log(f'LỖI {so}: ' + (f"[{R['stage']}] " if R.get('stage') else '') + str(e))
            ctx.sleep(max(0.5, float(ctx.cfg.settings().get('delay_ms', 2000)) / 1000))
        try:
            tab.goto_hash(IMPORT_ML)
            tab.sleep(500)
        except Exception: pass
    all_ktn = [it.get('ktn', {}).get('status', '') for _, it in store.all_items() if it.get('ktn')]
    ctx.log('KẾT THÚC BƯỚC 4: ' + f"đạt {sum(s == KTN_OK for s in all_ktn)}, có lỗi đỏ {sum(s == KTN_RED for s in all_ktn)}, "
            f"lỗi chạy {sum(s == KTN_ERR for s in all_ktn)}; đã hoàn tất lượt kiểm tra.")
