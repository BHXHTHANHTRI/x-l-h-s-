"""Bước 2 - Tích và tiếp nhận hồ sơ.

Port từ m1_tiepnhan.js (runTiepNhan) và content.js (tnhs_set_pagesize, tnhs_tick_accept_round, tnhs_next_page, openExt5Panel).
Chỉ làm ở Bộ phận Quản lý thu (đang ở Cấp sổ-thẻ thì máy tự đổi về Thu trước). Mỗi lượt:
  1. TNHS > Hồ sơ chờ thụ lý, 100 dòng/trang. Mở khung "Đơn vị quản lý" của TIC (tiện ích ngoài, phần "e5").
  2. Bấm "Tích + Tiếp nhận" của TIC: TIC tích các dòng thuộc danh sách đơn vị quản lý (kết quả bước 1) và mở hộp "Tiếp nhận hồ sơ".
  3. Đợi hộp nạp xong danh sách, đọc các số hồ sơ trong hộp, bấm GHI NHẬN, chờ thông báo "Tiếp nhận thành công".
  4. Đợi trang lặng, kiểm tra các hồ sơ vừa tiếp nhận không còn trong bảng. Lặp đến khi không còn hồ sơ thuộc đơn vị quản lý
     (trang này hết thì sang trang sau). Tối đa 40 lượt.
Dừng (ném lỗi, không tự thử lại) khi: bấm GHI NHẬN mà không thấy "Tiếp nhận thành công" sau 15 giây; hồ sơ vừa tiếp nhận vẫn còn
trong danh sách (tránh lặp); trang không ổn định quá hạn. Mỗi lệnh GHI NHẬN máy bấm được ghi vào sổ cái (loại "tiepnhan").
Không có TIC: chạy riêng thì báo lỗi rõ; chạy trong chuỗi thì BỎ QUA (người tiếp nhận tay, các bước sau chạy với hồ sơ đã ở Đang thụ lý).
Kết quả lưu ở store.kv["tiepnhan"] cho trang bước 2.
"""
from __future__ import annotations

import re

from ..browser import NotReady, Target
from ..runner import StopRequested
from ..tnhs_socai import GhiSoCaiTnhs
from ..util import now_vn
from . import mo_cong
from .donvi import JS_TIC_HIEN, KhongCoTic, cho_chu, mo_khung_tic
from .tnhs_vai import dam_bao_thu

TNHS_CHO_THU_LY = "#/ho-so-cho-thu-ly"
TNHS_DANG_THU_LY = "#/ho-so-dang-thu-ly"
TOI_DA_LUOT = 40
CO_TRANG = 100
CHO_THONG_BAO_GIAY = 15                                      # chờ "Tiếp nhận thành công" sau GHI NHẬN
CHO_TIC_GIAY = 10                                            # chờ thanh công cụ TIC hiện
RX_SO_HO_SO = re.compile(r"^\d+[\w.]*/\d{4}/\d+$")
LUU_TOI_DA = 500                                             # số hồ sơ giữ lại trong kết quả hiển thị

JS_SO_DONG = "() => document.querySelectorAll('md-table-container table.alternate tbody tr').length"
JS_CHU_BANG = "() => (document.querySelector('md-table-container') || document.body).textContent"
JS_CO_TRANG = r"""(n) => {
  const sel = document.querySelector('md-select[ng-model="$pagination.limit"]');
  if (!sel) return 'khong_co';
  return (sel.textContent || '').replace(/\D+/g, ' ').trim().split(' ').includes(String(n)) ? 'da_dat' : 'can_doi';
}"""
JS_HOP_THOAI = r"""() => {
  const d = [...document.querySelectorAll('md-dialog')].find((x) => __bo600rt.vis(x) && /Tiếp nhận hồ sơ/.test((x.getAttribute('aria-label') || '') + ' ' + x.textContent));
  if (!d) return null;
  const ghi = d.querySelector('button[ng-click="capnhattiepnhanhosochothuly()"]');
  const hoso = [...d.querySelectorAll('tbody tr')].map((tr) => [...tr.querySelectorAll('td')].map((td) => td.textContent.trim()))
    .map((c) => c.find((x) => /^\d+[\w.]*\/\d{4}\/\d+$/.test(x)) || c[1]).filter(Boolean);
  return { dangTai: [...d.querySelectorAll('md-progress-linear')].some(__bo600rt.vis), coGhi: !!ghi, hoso };
}"""
JS_HOP_THOAI_HANDLE = r"""() => [...document.querySelectorAll('md-dialog')].find((x) => __bo600rt.vis(x) && /Tiếp nhận hồ sơ/.test((x.getAttribute('aria-label') || '') + ' ' + x.textContent)) || null"""
JS_CO_HOP_NAO = "() => [...document.querySelectorAll('md-dialog')].some(__bo600rt.vis)"
JS_TRANG_SAU = r"""() => {
  const cands = [...document.querySelectorAll('md-table-pagination button, .md-table-pagination button, button')]
    .filter((b) => __bo600rt.vis(b) && /next|sau|›|»/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('ng-click') || '') + ' ' + b.textContent));
  const btn = cands.find((b) => /next/i.test((b.getAttribute('ng-click') || '') + (b.getAttribute('aria-label') || '')));
  return btn && !btn.disabled && btn.getAttribute('disabled') === null ? btn : null;
}"""


def _handle(page, js):
    h = page.evaluate_handle(js)
    el = h.as_element()
    if el is None:
        h.dispose()
    return el


# Chỉ cần bảng ĐÃ CÓ trong trang (như waitFor của extension): bảng thật rất cao, bị thanh công cụ phủ/nằm ngoài màn hình
# nên không được kiểm tra "hiện/bị che/ngoài màn hình" (an=True). Vẫn chờ hết tải, hết yêu cầu dữ liệu, giao diện lặng.
T_BANG = Target(css="md-table-container", ten="bảng danh sách hồ sơ chờ thụ lý", an=True)
T_TICK = Target(css="#__bhxh_tick_accept_btn", ten='nút "Tích + Tiếp nhận" của TIC')
T_GHI = Target(lay=lambda page: _handle(page, r"""() => { const d = [...document.querySelectorAll('md-dialog')].find((x) => __bo600rt.vis(x) && /Tiếp nhận hồ sơ/.test((x.getAttribute('aria-label') || '') + ' ' + x.textContent));
  return d ? d.querySelector('button[ng-click="capnhattiepnhanhosochothuly()"]') : null; }"""), ten='nút "GHI NHẬN" của hộp Tiếp nhận hồ sơ')
T_TRANG_SAU = Target(lay=lambda page: _handle(page, JS_TRANG_SAU), ten='nút "trang sau"')


class TiepNhanError(RuntimeError):
    """Lỗi nghiệp vụ của bước 2 (thông báo thẳng cho người dùng; máy dừng lượt, không tự thử lại)."""


# =============== phần thuần ===============
def doc_so_tich(text: str) -> int:
    """Số hồ sơ TIC báo đã tích: "Đã tích 12 hồ sơ ..." -> 12 (không đọc được: 0)."""
    m = re.search(r"Đã tích\s+(\d+)", text or "")
    return int(m.group(1)) if m else 0


def con_trong_bang(hoso, bang_text: str) -> list:
    """Các số hồ sơ vừa tiếp nhận mà chữ trên bảng vẫn còn."""
    return [h for h in hoso if h and h in (bang_text or "")]


def tom_tat(kq: dict) -> str:
    if not kq:
        return "Chưa chạy lần nào."
    return (f'Lần chạy {kq.get("at", "")}: đã tiếp nhận {kq.get("total", 0)} hồ sơ trong {kq.get("rounds", 0)} lượt. '
            f'Kết quả: {"Hoàn thành" if kq.get("ok") else "Dừng giữa chừng"}' + (f' ({kq["note"]})' if kq.get("note") else "") + ".")


# =============== phần trình duyệt ===============
def dat_co_trang(ctx, tnhs, n: int = CO_TRANG) -> None:
    """Chọn n dòng/trang ở bảng (nếu bảng có ô chọn và chưa đúng)."""
    tnhs.cho_on_dinh(T_BANG, toi_da=20, viec="mở danh sách Hồ sơ chờ thụ lý")
    tt = tnhs.page.evaluate(JS_CO_TRANG, n)
    if tt != "can_doi":
        return
    tnhs.bam_n(Target(css='md-select[ng-model="$pagination.limit"]', ten="ô chọn số dòng/trang"), viec="chọn số dòng/trang")
    opt = Target(css="md-option", text=str(n), exact=True, ten=f"mục {n} dòng/trang")
    tnhs.bam_n(opt, viec=f"chọn {n} dòng/trang", toi_da=8)
    tnhs.sleep(3000)


def mo_khung_tic_neu_can(tnhs) -> None:
    try:
        mo_khung_tic(tnhs)                                     # đã mở thì không làm gì
    except Exception as e:                                     # noqa: BLE001
        raise TiepNhanError(str(e)) from None


def mot_luot(ctx, tnhs) -> dict:
    """Một lượt "Tích + Tiếp nhận". Trả {status: empty|nomatch|done, ...}. Ném TiepNhanError/GateTimeout khi phải dừng."""
    tnhs.cho_on_dinh(T_BANG, toi_da=20, viec="mở danh sách Hồ sơ chờ thụ lý")
    tnhs.sleep(1000)
    truoc = tnhs.page.evaluate(JS_SO_DONG)
    if truoc == 0:
        return {"status": "empty"}
    mo_khung_tic_neu_can(tnhs)
    status = "#__bhxh_tick_result"
    tnhs.page.evaluate("(s) => { const e = document.querySelector(s); if (e) e.textContent = ''; }", status)
    tnhs.ho_tai()
    tnhs.bam_n(T_TICK, viec="Tích + Tiếp nhận (TIC)", toi_da=10)
    t = cho_chu(tnhs, status, r"Đã tích|Không khớp|Chưa có danh sách", 15, 'kết quả "Tích + Tiếp nhận" (TIC không phản hồi)')
    if re.search("Chưa có danh sách", t):
        raise TiepNhanError("TIC: " + t + " - chạy bước 1 (Đơn vị quản lý) trước.")
    if re.search("Không khớp", t):
        return {"status": "nomatch", "rows_before": truoc, "msg": t}
    ticked = doc_so_tich(t)

    # hộp "Tiếp nhận hồ sơ": chờ hiện, chờ nạp xong danh sách rồi mới đọc và bấm GHI NHẬN
    tnhs.cho_on_dinh(Target(lay=lambda page: _handle(page, JS_HOP_THOAI_HANDLE), ten='hộp thoại "Tiếp nhận hồ sơ"'),
                     toi_da=20, viec="mở hộp Tiếp nhận hồ sơ", khong_nghi=True)
    for _ in range(150):                                       # tối đa ~15 giây
        d = tnhs.page.evaluate(JS_HOP_THOAI)
        if d and not d["dangTai"]:
            break
        tnhs.sleep(100)
    tnhs.sleep(500)
    d = tnhs.page.evaluate(JS_HOP_THOAI)
    if not d or not d["coGhi"]:
        raise TiepNhanError('Không thấy nút "GHI NHẬN" trong hộp thoại Tiếp nhận hồ sơ')
    hoso = d["hoso"]
    mark = tnhs.toast_mark()
    tnhs.ho_tai()
    tnhs.bam_n(T_GHI, viec="GHI NHẬN tiếp nhận", toi_da=15)
    if tnhs.cho_toast(r"Tiếp nhận thành công", mark, CHO_THONG_BAO_GIAY) is None:
        return {"status": "noconfirm", "ticked": ticked, "hoso": hoso, "toasts": tnhs.toasts_since(mark), "rows_before": truoc}
    toasts = tnhs.cho_het_toast(mark, 2000, 30)
    for _ in range(100):                                       # hộp đóng (tối đa ~10 giây)
        if not tnhs.page.evaluate(JS_CO_HOP_NAO):
            break
        tnhs.sleep(100)
    tnhs.sleep(2500)
    con = con_trong_bang(hoso, tnhs.page.evaluate(JS_CHU_BANG))
    return {"status": "done", "ticked": ticked, "hoso": hoso, "toasts": toasts, "rows_before": truoc,
            "rows_after": tnhs.page.evaluate(JS_SO_DONG), "still": con}


def sang_trang_sau(tnhs) -> bool:
    el = T_TRANG_SAU.resolve(tnhs.page)
    if el is None:
        return False
    tnhs.bam_n(T_TRANG_SAU, viec="trang sau", toi_da=5)
    tnhs.sleep(3000)
    return True


# =============== bước ===============
def chay_tiep_nhan(ctx, items=None) -> None:
    """Handler đăng ký cho khóa "tn". Không dùng `items` (bước này không theo hồ sơ)."""
    from . import open_session
    s = ctx.cfg.settings()
    delay = int(s.get("delay_ms") or 2000)
    ctx.log("BƯỚC 2: TÍCH VÀ TIẾP NHẬN HỒ SƠ (TIC \"Tích + Tiếp nhận\", GHI NHẬN, lặp đến khi hết hồ sơ thuộc đơn vị quản lý)")
    total, rounds, tat_ca, ok, note = 0, 0, [], False, ""
    ghi = None
    try:
        with open_session(ctx) as br:
            tnhs = mo_cong(br, "tnhs", TNHS_CHO_THU_LY)
            tnhs.tu_oke(True)
            try:
                dam_bao_thu(ctx, tnhs, "tiếp nhận")
                tnhs.goto_hash(TNHS_CHO_THU_LY)
                tnhs.ho_tai()
                tnhs.tu_oke(True)
                if not tnhs.page.evaluate(JS_TIC_HIEN):
                    try:
                        tnhs.san_sang(Target(css="#__chkGreen, #__bhxh_toolbar_bar", ten="thanh công cụ TIC", an=True), toi_da=CHO_TIC_GIAY)
                    except NotReady:
                        raise KhongCoTic("Không thấy tiện ích TIC (TienIchChung) trên TNHS. Cài TIC trong Chrome điều khiển được "
                                         "(hồ sơ riêng - Chrome 136+ không dùng chung hồ sơ mặc định) rồi tải lại trang TNHS.") from None
                ghi = GhiSoCaiTnhs(tnhs, ctx.socai, who="may", run="tn")
                ctx.check_stop()
                ctx.status("Đang tích và tiếp nhận hồ sơ...")
                dat_co_trang(ctx, tnhs)
                while rounds < TOI_DA_LUOT:
                    ctx.check_stop()
                    tnhs.tu_oke(True)
                    r = mot_luot(ctx, tnhs)
                    if r["status"] == "empty":
                        ctx.log("Danh sách Chờ thụ lý trống.")
                        break
                    if r["status"] == "nomatch":
                        if sang_trang_sau(tnhs):
                            ctx.log("Trang này không còn hồ sơ thuộc đơn vị quản lý, chuyển sang trang sau.")
                            continue
                        ctx.log(f'Không còn hồ sơ thuộc danh sách đơn vị quản lý ({r["msg"]}).')
                        break
                    rounds += 1
                    if r["status"] == "noconfirm":
                        ctx.log(f'DỪNG: đã bấm GHI NHẬN nhưng không thấy thông báo "Tiếp nhận thành công" sau {CHO_THONG_BAO_GIAY} giây. Thông báo nhận được: '
                                + (" | ".join(r["toasts"]) or "không có"))
                        raise TiepNhanError("Không xác nhận được kết quả tiếp nhận")
                    total += r["ticked"]
                    tat_ca.extend(r["hoso"])
                    ctx.log(f'Lượt {rounds}: tích {r["ticked"]} hồ sơ. Số hồ sơ: ' + (", ".join(r["hoso"]) or "(không đọc được)"))
                    for x in r["toasts"]:
                        ctx.log("   Thông báo: " + x)
                    if r["still"]:
                        raise TiepNhanError(f'Sau khi tiếp nhận vẫn còn {len(r["still"])} hồ sơ trong danh sách Chờ thụ lý '
                                            f'({", ".join(r["still"][:5])}) - dừng để tránh lặp')
                    tnhs.sleep(delay)
                if rounds >= TOI_DA_LUOT:
                    ctx.log(f"Đã đạt giới hạn {TOI_DA_LUOT} lượt, dừng.")
                ctx.status("Chuyển sang Hồ sơ đang thụ lý...")
                tnhs.goto_hash(TNHS_DANG_THU_LY)
                ok = True
            finally:
                tnhs.tu_oke(False)
                tnhs.net.process()
                tnhs.net.clear_listeners()
    except KhongCoTic as e:
        if getattr(ctx, "chain", False):
            ctx.log("Không thấy TIC (TienIchChung) trên TNHS - BỎ QUA bước Tiếp nhận (hồ sơ mới cần người tiếp nhận tay), "
                    "chạy tiếp các bước sau.")
            note = "bỏ qua: không có TIC"
            ok = True
            return
        note = "không có TIC"
        raise TiepNhanError(str(e)) from None
    except BaseException as e:                                 # noqa: BLE001 - ghi lại rồi ném tiếp (kể cả bấm Dừng)
        note = "bấm Dừng" if isinstance(e, StopRequested) else str(e)[:160]
        raise
    finally:
        ghi_ok = len(ghi.so_ho_so()) if ghi else 0
        ctx.log(f'KẾT THÚC TIẾP NHẬN. Đã tiếp nhận {total} hồ sơ trong {rounds} lượt (sổ cái ghi {ghi_ok} lệnh tiếp nhận). '
                f'Kết quả: {"Hoàn thành" if ok else "Dừng giữa chừng"}')
        ctx.store.kv_set("tiepnhan", {"at": now_vn(), "total": total, "rounds": rounds, "ok": ok, "note": note,
                                      "hoso": tat_ca[-LUU_TOI_DA:]})
    ctx.status(f"Đã tiếp nhận {total} hồ sơ")
