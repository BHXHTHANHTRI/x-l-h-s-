"""Bước 3 - đọc hồ sơ 600 điện tử đang thụ lý và tải mẫu D02 từ TNHS.

Thiết kế an toàn: chỉ tự thêm hồ sơ khi đọc được object dữ liệu Angular đầy đủ; nếu chỉ đọc được chữ trên bảng,
không suy đoán loại hồ sơ/bước xử lý. Không tự lặp lại một lần tải đã báo lỗi trong cùng lượt.
"""
from __future__ import annotations

import re
from pathlib import Path
from datetime import datetime

from urllib.parse import quote

from ..browser import Target, GateTimeout
from ..d02_io import read_d02, inspect_luong
from ..model import new_id
from ..util import date_str, safe_name, now_vn, parse_vn_date, ten_file_d02
from . import mo_cong
from .tnhs_vai import dam_bao_thu

HASH_DANG_THU_LY = "#/ho-so-dang-thu-ly"
HASH_CHI_TIET = "#/chi-tiet-ho-so-dang-thu-ly?id="
KV_DETAIL_KEY = "tnhs_detail_key"

# Đọc object hàng từ scope AngularJS, không chỉ dựa vào chữ hiển thị.
JS_ROWS = r"""() => {
 const rows=[...document.querySelectorAll('md-table-container table.alternate tbody tr')];
 const norm=o=>o&&typeof o==='object'&&!Array.isArray(o);
 const pick=(o,keys)=>{if(!norm(o))return null; const ks=Object.keys(o); for(const k of ks){if(keys.includes(k.toLowerCase()) && o[k]!=null && typeof o[k]!=='function') return o[k];} return null;};
 const objFor=(row)=>{
  let candidates=[]; try { const a=window.angular; if(a){let e=a.element(row),s=e.scope&&e.scope(); for(let i=0;s&&i<5;i++,s=s.$parent){ for(const k of Object.keys(s)){const v=s[k]; if(norm(v)){const keys=Object.keys(v).map(x=>x.toLowerCase()); if(keys.some(x=>['sohoso','mathutuc','loaihosoid','madonvi','hosoxulyid'].includes(x))) candidates.push(v);}}}} }catch(e){}
  return candidates.sort((a,b)=>Object.keys(b).length-Object.keys(a).length)[0]||null;
 };
 const out=rows.map((tr)=>{const o=objFor(tr); return {text:(tr.innerText||tr.textContent||'').trim(),raw:o};});
 const total=(document.querySelector('md-table-pagination')||document.body).innerText||'';
 const inputs=[...document.querySelectorAll('input')].filter(x=>x.offsetParent!==null).map(x=>({name:x.name||x.id||'',value:(x.value||'').trim()})).filter(x=>x.value);
 const pb=(()=>{try{const s=window.angular&&window.angular.element(document.body).scope();return null;}catch(e){return null;}})();
 return {rows:out,inputs,totalText:total,hash:location.hash};
}"""

JS_PAGE_SIZE = r"""(n)=>{const s=document.querySelector('md-select[ng-model="$pagination.limit"]');if(!s)return 'missing';if((s.innerText||'').includes(String(n)))return 'ok';return 'change';}"""
JS_FIND_NEXT = r"""()=>{const a=[...document.querySelectorAll('md-table-pagination button,.md-table-pagination button,button')].filter(b=>b.offsetParent!==null&&!b.disabled&&b.getAttribute('disabled')===null);return a.find(b=>/next/i.test((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('ng-click')||'')))||null;}"""
JS_DETAIL_NO = r"""()=>{const t=document.body.innerText||'';const m=t.match(/Số\s*hồ\s*sơ\s*:\s*(\S+)/i);return m?m[1]:'';}"""


def _get(raw, *names, default=""):
    if not isinstance(raw, dict): return default
    by={str(k).lower():v for k,v in raw.items()}
    for name in names:
        v=by.get(name.lower())
        if v is not None: return v
    return default


def _as_item(raw, lot, stt):
    so=str(_get(raw,'sohoso','soHoSo')).strip()
    if not so: return None
    return {
      'id':str(_get(raw,'id','hosoxulyid','hoSoXuLyId',default=so)),
      'hosoxulyid':str(_get(raw,'hosoxulyid','hoSoXuLyId','id',default='')),
      'stt':stt,'sohoso':so,'short':so.split('/')[0],
      'madonvi':str(_get(raw,'madonvi','maDonVi')).strip(),
      'tendonvi':str(_get(raw,'tendonvi','tenDonVi')).strip(),
      'kykekhai':str(_get(raw,'kykekhai','kyKeKhai')).strip(),
      'songuoi':_get(raw,'songuoi','soNguoi',default=''),
      'ngaynhan':str(_get(raw,'ngaynhan','ngayNhan')).strip(),
      'ngaytra':str(_get(raw,'ngaytra','ngayTra')).strip(),
      'mathutuc':str(_get(raw,'mathutuc','maThuTuc')).strip(),
      'loaihosoid':_get(raw,'loaihosoid','loaiHoSoId',default=None),
      'status':'Chưa tải','file':'','rows':'','luong':'','khop':'','note':'','raw':raw,'lot':lot
    }


def _filter_reason(it, tracked_ids):
    if str(it.get('mathutuc','')).strip() != '600': return 'không phải thủ tục 600'
    try:
        if int(it.get('loaihosoid')) != 0: return 'không phải hồ sơ điện tử'
    except (TypeError, ValueError): return 'không xác định được loại hồ sơ'
    if str(it.get('id')) in tracked_ids: return 'đã có trong sổ theo dõi'
    if re.search(r'\.(G|BD)\b', it.get('sohoso',''), re.I): return 'hồ sơ dạng .G/.BD'
    return ''


def _read_rows(tab):
    return tab.page.evaluate(JS_ROWS)


def _click_search(tab, ctx):
    btn=Target(css='button[ng-click="Search()"]', text='TRA CỨU', exact=False, ten='nút TRA CỨU')
    tab.bam_n(btn, viec='bấm TRA CỨU để nạp lại danh sách Đang thụ lý', toi_da=15)
    tab.cho_on_dinh(Target(css='md-table-container', ten='bảng Đang thụ lý', an=True), toi_da=30, viec='đợi danh sách Đang thụ lý sau TRA CỨU')
    tab.sleep(1200)


def _set_100(tab):
    state=tab.page.evaluate(JS_PAGE_SIZE,100)
    if state=='change':
        tab.bam_n(Target(css='md-select[ng-model="$pagination.limit"]',ten='chọn số dòng/trang'),viec='mở số dòng/trang')
        tab.bam_n(Target(css='md-option',text='100',exact=True,ten='100 dòng/trang'),viec='chọn 100 dòng/trang',toi_da=10)
        tab.sleep(1000)


def _page_next(tab):
    h=tab.page.evaluate_handle(JS_FIND_NEXT); el=h.as_element()
    if el is None: h.dispose(); return False
    try: el.click()
    finally: el.dispose()
    tab._touch(); tab.sleep(1200)
    return True


JS_WAIT_DETAIL = r"""()=>{
 const h=location.hash||'';
 const btn=document.querySelector('button[aria-label="Mẫu TST"]');
 const t=document.body.innerText||'';const m=t.match(/Số\s*hồ\s*sơ\s*:\s*(\S+)/i);
 const idm=h.match(/[?&]id=([^&]+)/);
 return {ok:h.indexOf('chi-tiet-ho-so')!==-1&&!!btn,no:m?m[1]:'',hashId:idm?decodeURIComponent(idm[1]):'',hash:h};
}"""
JS_HAS_ROW = r"""(so)=>[...document.querySelectorAll('md-table-container table.alternate tbody tr')].some(tr=>(tr.innerText||'').includes(so))"""
JS_DBLCLICK = r"""(so)=>{const tr=[...document.querySelectorAll('md-table-container table.alternate tbody tr')].find(x=>(x.innerText||'').includes(so));if(!tr)throw new Error('Không thấy hồ sơ '+so+' trên trang hiện tại');const c=tr.querySelectorAll('td')[3]||tr;['mousedown','mouseup','click','mousedown','mouseup','click','dblclick'].forEach(t=>c.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,button:0,detail:t==='dblclick'?2:1})));}"""


def _cho_chi_tiet(tab, so, toi_da=25.0):
    """Chờ trang chi tiết đúng hồ sơ (số hồ sơ ngắn khớp). Trả dict {matched, hashId, no, hash}."""
    import time
    ngan=so.split('/')[0]; end=time.monotonic()+toi_da; last={}
    while time.monotonic()<end:
        last=tab.page.evaluate(JS_WAIT_DETAIL)
        if last.get('ok') and str(last.get('no','')).split('/')[0]==ngan:
            return {'matched':True,**last}
        tab.sleep(150)
    return {'matched':False,**last}


def _ve_danh_sach(tab, ctx, page_no):
    tab.goto_hash(HASH_DANG_THU_LY); _set_100(tab); _click_search(tab,ctx)
    for p in range(1,int(page_no or 1)):
        if not _page_next(tab): raise RuntimeError(f'Không chuyển được đến trang {p+1}')


def _open_detail(tab, ctx, it, key):
    """Như tiện ích (m1_tiepnhan.js downloadItem): có trường id của trang chi tiết thì mở thẳng bằng #hash;
    chưa có/không ra đúng hồ sơ thì bấm đúp từ danh sách rồi học trường id cho các hồ sơ sau. Trả về trường id (hoặc None)."""
    so=it['sohoso']; raw=it.get('raw') or {}
    if key and raw.get(key) is not None:
        try:
            tab.goto_hash(HASH_CHI_TIET+quote(str(raw[key]),safe=''))
            det=_cho_chi_tiet(tab,so,25)
            if det['matched']: return key
        except GateTimeout: pass
        ctx.log(f'   Mở trực tiếp không ra đúng hồ sơ {so}, thử bấm đúp từ danh sách.')
    h=tab.page.evaluate('location.hash') or ''
    if not h.startswith(HASH_DANG_THU_LY) or not tab.page.evaluate(JS_HAS_ROW,so):
        _ve_danh_sach(tab,ctx,it.get('page'))
    tab.cho_on_dinh(Target(css='md-table-container',ten='bảng Đang thụ lý',an=True),toi_da=20,viec='đợi bảng trước khi mở chi tiết')
    tab.page.evaluate(JS_DBLCLICK,so)
    det=_cho_chi_tiet(tab,so,40)
    if not det['matched']:
        raise RuntimeError(f"Không mở được đúng chi tiết hồ sơ {so} (trang đang hiện: {det.get('no') or det.get('hash')}); dừng để tránh tải nhầm.")
    hid=det.get('hashId')
    if hid:
        k=next((x for x,v in raw.items() if v is not None and str(v)==hid),None)
        if k:
            ctx.log(f'   Đã nhận ra: địa chỉ trang chi tiết dùng trường "{k}". Các hồ sơ sau mở trực tiếp.')
            return k
        ctx.log(f'   Địa chỉ trang chi tiết id={hid} không trùng trường nào của danh sách, tiếp tục mở bằng bấm đúp.')
    return key


def _ten_d02(base, it):
    """Đặt tên như tiện ích (background.js decideName): giữ tên gốc TNHS, thiếu dạng NN_YYYY thì dùng fallbackBase, thêm __<số hồ sơ>."""
    def f(suggested):
        stem,ext=ten_file_d02(suggested,it)
        return base/stem, ext
    return f


def _download_d02(tab, dest_stem):
    def click_export():
        tab.bam_n(Target(css='button[aria-label="Mẫu TST"]',ten='Mẫu TST'),viec='mở menu Mẫu TST')
        tab.bam_n(Target(css='button[ng-click="ExportTST()"]',text='Xuất mẫu TST',exact=False,ten='Xuất mẫu TST'),viec='chọn Xuất mẫu TST',toi_da=10)
    return tab.tai_ve_cho(click_export,dest_stem,toi_da=180,duoi_mac_dinh='.xlsx')


def chay_tai_d02(ctx, items=None):
    store=ctx.store
    lot_id=date_str()
    lot=store.ensure_lot(lot_id)
    base=store.paths.lot_dir(lot_id); base.mkdir(parents=True,exist_ok=True)
    ctx.log('BƯỚC 3: đọc Đang thụ lý, chỉ nạp hồ sơ 600 điện tử mới khi dữ liệu đủ tin cậy, rồi tải mẫu TST.')
    with __import__('contextlib').nullcontext():
        with __import__('bo600.steps',fromlist=['open_session']).open_session(ctx) as br:
            tab=mo_cong(br,'tnhs',HASH_DANG_THU_LY)
            dam_bao_thu(ctx, tab, "tải D02")
            tab.goto_hash(HASH_DANG_THU_LY)
            _set_100(tab)
            _click_search(tab,ctx)  # luôn TRA CỨU trước khi đọc, tránh dùng snapshot cũ
            # Chỉ bỏ qua hồ sơ đã tải thành công; hồ sơ Chưa tải/Lỗi phải được thử lại.
            tracked={str(it.get('id')) for _,it in store.all_items() if str(it.get('status','')).strip().lower() in {'đã tải','da tai'}}
            all_raw=[]; page=1; total=None; reliable=True
            while page<=30:
                ctx.check_stop(); tab.cho_on_dinh(Target(css='md-table-container',ten='bảng Đang thụ lý',an=True),toi_da=30,viec=f'đọc trang {page}')
                snap=_read_rows(tab)
                # Bộ lọc ngày nhận (từ ngày/đến ngày) là điều kiện tra cứu hợp lệ của
                # màn hình TNHS; không coi chúng là ô tìm kiếm tự do. Các ô lọc khác
                # vẫn phải để trống để tránh đọc một danh sách bị thu hẹp ngoài ý muốn.
                inputs = snap.get('inputs') or []
                date_keys = {'tungay', 'denngay', 'tu_ngay', 'den_ngay',
                             'ngaybatdau', 'ngayketthuc', 'fromdate', 'todate',
                             'from_date', 'to_date'}
                # Đây là các trường cấu hình/tải tệp của tiện ích BO600, không phải
                # bộ lọc trên danh sách hồ sơ TNHS nên không được chặn bước tải D02.
                non_filter_keys = {'__bhxh_file_input', '__bhxh_cq_input',
                                   'bhxh_file_input', 'bhxh_cq_input'}
                active_filters = []
                for x in inputs:
                    name = re.sub(r'[^a-z0-9_]', '', str(x.get('name', '')).lower())
                    if name in date_keys or name in non_filter_keys:
                        continue
                    active_filters.append(x)
                if active_filters:
                    vals=', '.join(f"{x['name']}={x['value'][:30]}" for x in active_filters[:5])
                    raise RuntimeError('Danh sách TNHS đang có ô tìm kiếm/lọc khác đang có giá trị ('+vals+'). Hãy xóa các ô lọc này rồi chạy lại; bộ lọc ngày từ/đến được phép.')
                rows=snap.get('rows') or []
                if any(not r.get('raw') for r in rows if r.get('text')):
                    reliable=False
                for r in rows:
                    raw=r.get('raw')
                    if isinstance(raw,dict): all_raw.append((raw,page))
                m=__import__('re').search(r'(?:of|/|trên)\s*(\d+)\s*(?:items|hồ sơ|dòng)?',snap.get('totalText',''),__import__('re').I)
                if m: total=int(m.group(1))
                if not rows or len(rows)<100: break
                if not _page_next(tab): break
                page+=1
            if not reliable:
                raise RuntimeError('Không đọc được object dữ liệu của một số dòng TNHS. Để tránh nạp sai thủ tục, bước 3 dừng và không tạo hồ sơ mới.')
            if not all_raw:
                ctx.log('Danh sách Đang thụ lý không có hồ sơ đọc được.'); store.kv_set('tai_d02',{'at':now_vn(),'ok':True,'total':0,'downloaded':0,'errors':[]}); return
            # Đảm bảo không làm ở bộ phận Cấp sổ-thẻ; đọc trường phòng ban nếu object phản hồi có cung cấp.
            picked=[]; skipped={}
            for idx,(raw,pno) in enumerate(all_raw,1):
                it=_as_item(raw,lot_id,idx)
                if not it: continue
                it['page']=pno
                reason=_filter_reason(it,tracked)
                if reason: skipped[reason]=skipped.get(reason,0)+1; continue
                picked.append(it)
            ctx.log(f'Đã đọc {len(all_raw)} hồ sơ từ {page} trang; đủ object dữ liệu: có.')
            # Kiểm tra thứ tự ngày nhận tăng dần trên các dòng thủ tục 600; chỉ cảnh báo, không tự sắp xếp.
            dated=[]
            for raw,_p in all_raw:
                if str(_get(raw,'mathutuc','maThuTuc')).strip() == '600':
                    dt=parse_vn_date(_get(raw,'ngaynhan','ngayNhan'))
                    if dt: dated.append((dt,str(_get(raw,'ngaynhan','ngayNhan'))))
            if any(dated[i][0] < dated[i-1][0] for i in range(1,len(dated))):
                ctx.log('CẢNH BÁO: hồ sơ 600 chưa được sắp xếp ngày nhận tăng dần. Máy vẫn tiếp tục; lần sau hãy sắp xếp trên TNHS trước khi chạy.')
            for reason,n in skipped.items(): ctx.log(f'Bỏ qua {n} hồ sơ: {reason}.')
            if not picked: ctx.log('Không có hồ sơ 600 điện tử mới cần nạp.'); store.kv_set('tai_d02',{'at':now_vn(),'ok':True,'total':0,'downloaded':0,'errors':[]}); return
            # Thêm bản ghi chỉ với hồ sơ mới; hồ sơ đã có nhưng chưa tải/Lỗi vẫn được thử lại.
            all_existing=store.all_items()
            existing={str(it.get('id')) for _,it in all_existing}
            new_items=[x for x in picked if str(x['id']) not in existing]
            for it in new_items:
                clean={k:v for k,v in it.items() if k!='lot'}
                clean.setdefault('status','Chưa tải')
                lot=store.ensure_lot(lot_id)
                lot['items'].append(clean); store.save_lot(lot); existing.add(str(clean['id']))
            ctx.log(f'Có {len(new_items)} hồ sơ mới; thử tải {len(picked)} hồ sơ mới/chưa tải/lỗi trong lô {lot_id}.')
            errors=[]; downloaded=0
            key=store.kv_get(KV_DETAIL_KEY)
            for idx,it in enumerate(picked,1):
                ctx.check_stop(); so=it['sohoso']
                ctx.status(f'Tải D02 {so} ({idx}/{len(picked)})')
                try:
                    key=_open_detail(tab,ctx,it,key)
                    if key and key!=store.kv_get(KV_DETAIL_KEY): store.kv_set(KV_DETAIL_KEY,key)
                    stem=_ten_d02(base,it)
                    path=_download_d02(tab,stem)
                    d02=read_d02(path)
                    rows=len(d02.rows); luong=inspect_luong(d02); match=any(so.split('/')[0] in str(c.value or '') for row in d02.ws.iter_rows() for c in row) if so else False
                    def upd(cur, _lot):
                        cur.update({'status':'Đã tải','file':str(path.relative_to(base)),'rows':rows,'luong':luong,'khop':'Có' if match else 'Không thấy','at':now_vn(),'atTs':int(datetime.now().timestamp()*1000),'note':'' if match else 'Không thấy số hồ sơ trong file; cần kiểm tra thủ công.'})
                    store.edit_item(lot_id,it['id'],upd)
                    downloaded+=1; ctx.log(f'Đã tải {so}: {path.name} ({rows} dòng, lương {luong})'+('' if match else ' - CẢNH BÁO: chưa thấy số hồ sơ trong file'))
                except Exception as e:
                    if type(e).__name__=='StopRequested': raise
                    msg=str(e); errors.append({'sohoso':so,'error':msg})
                    store.edit_item(lot_id,it['id'],lambda cur,_lot: cur.update({'status':'Lỗi','note':msg,'at':now_vn()}))
                    ctx.log(f'LỖI tải {so}: {msg}')
                    # Không tự thử lại hồ sơ lỗi; tiếp tục hồ sơ kế tiếp.
            result={'at':now_vn(),'ok':not errors,'total':len(picked),'downloaded':downloaded,'errors':errors}
            store.kv_set('tai_d02',result)
            ctx.log(f'KẾT THÚC BƯỚC 3: đã tải {downloaded}/{len(picked)}; lỗi {len(errors)}.')
