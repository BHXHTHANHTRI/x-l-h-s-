"""Bộ phận (vai) trên TNHS - dùng chung cho bước 2, 3 và 9.

Port từ core.js (vaiHienTai, doiVai, damBaoThu) và cs_m9.js (tnhs9_role_get, tnhs9_role_switch).
Bước 1, 2, 3, cập nhật tiến độ và bước 9 đều làm ở Bộ phận Quản lý thu (trừ phần Cấp sổ-thẻ của bước 9).
Tab TNHS có thể bị kẹt ở Cấp sổ-thẻ (lượt bước 9 bị cắt ngang, người đổi tay rồi quên) -> máy tự đổi về Thu trước khi làm.
Đổi bộ phận là đổi cho cả phiên đăng nhập, nên trong lúc chạy người dùng không được thao tác trên tab TNHS.
"""
from __future__ import annotations

import time

from playwright.sync_api import Error as PWError

from ..browser import GateTimeout, NotReady, Target

TEN_VAI = {"thu": "Bộ phận Quản lý thu", "cst": "Bộ phận Cấp sổ-thẻ"}
CHO_DOI_VAI_GIAY = 300                       # SYS_WAIT của extension

SEL_MENU = 'a[ng-click^="ctrl.openMenu"], button[ng-click^="ctrl.openMenu"]'
SEL_MUC = 'a[ng-click^="clickDefaultPhongban"], button[ng-click^="clickDefaultPhongban"]'
RX_MENU = r"^\s*Bộ phận"
RX_MUC = {"thu": r"Quản\s*lý\s*thu", "cst": r"Cấp\s*sổ"}

JS_VAI = r"""() => {
  const a = [...document.querySelectorAll('a[ng-click^="ctrl.openMenu"], button[ng-click^="ctrl.openMenu"]')]
    .find((x) => __bo600rt.vis(x) && /^\s*Bộ phận/i.test((x.textContent || '').trim()));
  const label = a ? (a.textContent || '').replace(/\s+/g, ' ').trim() : '';
  return { label, hash: location.hash };
}"""


def vai_cua(label: str) -> str:
    """'thu' | 'cst' | '' theo chữ trên menu "Bộ phận ..."."""
    import re
    if re.search(r"Cấp\s*sổ", label or "", re.I):
        return "cst"
    return "thu" if re.search(r"thu", label or "", re.I) else ""


def vai_hien_tai(tab, toi_da: float = 60) -> dict:
    """{label, role, hash}. Trang đang tải lại thì đọc lại; quá hạn ném GateTimeout."""
    t0 = time.monotonic()
    while time.monotonic() - t0 < toi_da:
        tab._check_stop()
        try:
            g = tab.page.evaluate(JS_VAI)
            g["role"] = vai_cua(g["label"])
            if g["role"]:
                return g
        except PWError:
            pass
        tab.sleep(1500)
    raise GateTimeout('[HT] Không đọc được bộ phận đang chọn trên TNHS (menu "Bộ phận ..." ở góc trên)')


def doi_vai(ctx, tab, to: str) -> None:
    """Đổi bộ phận trên TNHS bằng menu "Bộ phận ..." (như người làm), chờ đến khi menu hiện đúng bộ phận mới."""
    g = vai_hien_tai(tab, 60)
    if g["role"] == to:
        ctx.store.kv_set("vaiCst", int(time.time() * 1000) if to == "cst" else 0)
        return
    ctx.log(f'Đổi bộ phận trên TNHS: "{g["label"]}" → {TEN_VAI[to]}.')
    if to == "cst":
        ctx.store.kv_set("vaiCst", int(time.time() * 1000))
    try:
        tab.bam_th(Target(css=SEL_MENU, rx=RX_MENU, ten='menu "Bộ phận"'), viec="mở menu Bộ phận", toi_da=20)
        item = Target(css=SEL_MUC, rx=RX_MUC[to], ten=f'mục "{TEN_VAI[to]}"')
        tab.san_sang(item, viec="chọn bộ phận", toi_da=8)
        tab.cho_th(item, viec="chọn bộ phận", toi_da=30)
    except NotReady as e:
        raise GateTimeout(f'[HT] Không thấy mục "{TEN_VAI[to]}" trong menu bộ phận: {e}') from None
    try:                                                    # trang có thể tải lại ngay khi đổi bộ phận
        tab.page.evaluate("""(a) => { const e = __bo600rt.find(a); if (e) setTimeout(() => __bo600rt.clickEl(e), 80); }""",
                          {"css": SEL_MUC, "rx": RX_MUC[to]})
    except PWError:
        pass
    tab._touch()
    tab.sleep(2500)
    end = time.monotonic() + CHO_DOI_VAI_GIAY
    while time.monotonic() < end:
        tab._check_stop()
        try:
            g2 = tab.page.evaluate(JS_VAI)
            if vai_cua(g2["label"]) == to:
                if to == "thu":
                    ctx.store.kv_set("vaiCst", 0)
                tab.ensure_rt()
                tab.sleep(1500)
                return
        except PWError:
            pass                                            # trang đang tải lại
        tab.sleep(1500)
    raise GateTimeout(f"[HT] Sau {CHO_DOI_VAI_GIAY} giây chưa đổi được sang {TEN_VAI[to]}")


def dam_bao_thu(ctx, tab, why: str = "") -> None:
    """Đảm bảo tab TNHS đang ở Bộ phận Quản lý thu; không đọc được bộ phận thì ghi chú và đi tiếp (như extension)."""
    try:
        g = vai_hien_tai(tab, 20)
    except GateTimeout:
        ctx.log('Lưu ý: không đọc được bộ phận đang chọn trên TNHS (menu "Bộ phận ..." góc trên) - máy đi tiếp, dựa vào '
                "bộ phận ghi trong danh sách để kiểm tra.")
        return
    if g["role"] != "thu":
        ket = ctx.store.kv_get("vaiCst")
        ctx.log(f'Tab TNHS đang ở "{g["label"]}"' + (" (lượt Xử lý TNHS trước chưa đổi về)" if ket else "")
                + f" - máy đổi về {TEN_VAI['thu']} trước khi {why or 'làm tiếp'}.")
        doi_vai(ctx, tab, "thu")
    else:
        ctx.store.kv_set("vaiCst", 0)
