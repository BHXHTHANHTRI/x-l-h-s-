"""A2 - Sổ cái chỉ-thêm (các lượt Lưu import TST, XỬ LÝ TNHS, người xác nhận) + sao lưu/khôi phục.

Port từ core.js (refreshSocai, socaiXacNhan, restoreSocaiFile, tnhsLoai) và background.js (socai*).
Nguyên tắc: chỉ thêm, không xóa. Chưa khôi phục sổ cũ thì KHÔNG được import thật (assert_ready).
"""
from __future__ import annotations

import json
import os
import random
import re
import string
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from .store import Store
from .util import now_vn

FLUSH_DELAY_S = 45.0   # như extension: gộp các lượt ghi, hẹn 45 giây rồi mới ghi bản sao


class SocaiLocked(RuntimeError):
    pass


def tnhs_loai(e: dict) -> dict:
    """Phân loại lệnh TNHS (hanhdong 1 = tiếp nhận, 3 = XỬ LÝ, 4 = trình ký)."""
    if e.get("loai"):
        return e
    if e.get("viec") == "Phiếu hướng dẫn":
        e["loai"], e["bophan"] = "phieu", "Thu"
        return e
    m = re.match(r"^XỬ LÝ \((Thu|Cấp sổ-thẻ)\)", str(e.get("viec") or ""))
    if m:
        e["loai"], e["bophan"] = "xuly", m.group(1)
        return e
    e["loai"] = "khac"
    return e


def _new_meta(fresh: bool) -> dict:
    d = datetime.now()
    rnd = "".join(random.choices(string.ascii_lowercase + string.digits, k=4))
    return {"id": d.strftime("%Y%m%d-%H%M%S-") + rnd, "created": now_vn(d), "fresh": bool(fresh), "restoredFrom": []}


class Socai:
    def __init__(self, store: Store, auto_flush: bool = True):
        self.store = store
        self.paths = store.paths
        self._timer: Optional[threading.Timer] = None
        self._auto = auto_flush
        self.idx: dict = {}
        self.state: dict = {}
        first_run = self.store.kv_get("socaiMeta") is None
        self.meta()                       # tạo meta nếu chưa có (lần chạy đầu = sổ mới, fresh)
        if first_run:
            m = self.store.kv_get("socaiMeta"); m["fresh"] = True; self.store.kv_set("socaiMeta", m)
        self.refresh()

    # ---------- meta ----------
    def meta(self) -> dict:
        m = self.store.kv_get("socaiMeta")
        if m and m.get("id"):
            return m
        m = _new_meta(False)
        self.store.kv_set("socaiMeta", m)
        return m

    # ---------- chỉ mục ----------
    def refresh(self) -> None:
        by_so, by_fp, tnhs_by_so, luu_all = {}, {}, {}, {}
        entries = self.store.socai_all()
        for e in entries:
            if (e.get("he") or "TST") == "TST":
                for s in e.get("sohosos") or []:
                    luu_all.setdefault(s, []).append(e)    # cả lượt Lưu không thành công (để ghi "lỗi: ...")
                if not e.get("ok"):
                    continue
                for s in e.get("sohosos") or []:
                    by_so.setdefault(s, []).append(e)
                for f in e.get("fps") or []:
                    by_fp.setdefault(f, []).append(e)
            else:
                tnhs_loai(e)
                for s in e.get("sohosos") or []:
                    tnhs_by_so.setdefault(s, []).append(e)
        self.idx = {"bySo": by_so, "byFp": by_fp, "tnhsBySo": tnhs_by_so, "luuAll": luu_all,
                    "count": len(entries), "list": entries}
        meta = self.meta()
        old = self._old_unrestored(meta)
        self.state = {"meta": meta, "old": old, "locked": bool(old)}

    def _old_unrestored(self, meta: dict) -> list[str]:
        """Còn file socai_<mã khác>.json trong _socai mà chưa gộp vào sổ hiện tại."""
        ids = set()
        try:
            for f in self.paths.socai.iterdir():
                m = re.match(r"^socai_([0-9A-Za-z-]+)\.json$", f.name)
                if m:
                    ids.add(m.group(1))
        except OSError:
            pass
        done = set(meta.get("restoredFrom") or [])
        return sorted(i for i in ids if i != meta["id"] and i not in done)

    # ---------- truy vấn ----------
    def hit(self, it: dict):
        """Hồ sơ đã Lưu theo sổ cái (theo số hồ sơ)."""
        return self.idx["bySo"].get(it.get("sohoso")) or None

    def has_fingerprint(self, fp: str) -> bool:
        return fp in self.idx["byFp"]

    def tnhs_events(self, sohoso: str) -> list[dict]:
        return self.idx["tnhsBySo"].get(sohoso, [])

    def assert_ready(self) -> None:
        if self.state["locked"]:
            raise SocaiLocked("Sổ cái chưa khôi phục (" + ", ".join(f"socai_{x}.json" for x in self.state["old"])
                              + ") - không import thật cho đến khi khôi phục")

    # ---------- ghi ----------
    def add(self, entry: dict) -> dict:
        added = self.store.socai_insert(entry)
        if added:
            self.store.kv_set("socaiDirty", True)
            self._schedule_flush()
        self.refresh()
        return {"added": added, "count": self.idx["count"]}

    def _schedule_flush(self) -> None:
        if not self._auto:
            return
        if self._timer:
            self._timer.cancel()
        self._timer = threading.Timer(FLUSH_DELAY_S, self.flush)    # mỗi lượt mới hẹn lại từ đầu
        self._timer.daemon = True
        self._timer.start()

    def flush(self, force: bool = False) -> Optional[dict]:
        if self._timer:
            self._timer.cancel()
            self._timer = None
        if not force and not self.store.kv_get("socaiDirty"):
            return None
        return self.write_backup()

    def write_backup(self) -> dict:
        meta = self.meta()
        entries = self.store.socai_all()
        doc = {"updated": f"{now_vn()} {int(datetime.now().timestamp() * 1000)}", "app": "Bo600", "kind": "socai",
               "id": meta["id"], "created": meta.get("created"), "restoredFrom": meta.get("restoredFrom") or [],
               "entries": entries}
        self.paths.socai.mkdir(parents=True, exist_ok=True)
        f = self.paths.socai / f"socai_{meta['id']}.json"
        tmp = f.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, f)                       # ghi nguyên tử: mất điện giữa chừng không hỏng bản cũ
        self.store.kv_set("socaiDirty", False)
        self.store.kv_set("socaiBackup", {"at": now_vn(), "filename": str(f), "count": len(entries)})
        return {"filename": str(f), "count": len(entries)}

    # ---------- khôi phục ----------
    def restore(self, doc: dict) -> dict:
        if not isinstance(doc, dict) or doc.get("kind") != "socai" or not isinstance(doc.get("entries"), list):
            raise ValueError("File không phải sổ cái của Bộ 600")
        added = 0
        for e in doc["entries"]:
            if isinstance(e, dict) and e.get("id") and self.store.socai_insert(e):
                added += 1
        meta = self.meta()
        rest = [x for x in [*(meta.get("restoredFrom") or []), doc.get("id"), *(doc.get("restoredFrom") or [])] if x]
        meta["restoredFrom"] = list(dict.fromkeys(rest))
        meta["fresh"] = False
        self.store.kv_set("socaiMeta", meta)
        backup = self.write_backup()
        self.refresh()
        return {"added": added, "count": self.idx["count"], "backup": backup}

    def restore_file(self, path: str | os.PathLike) -> dict:
        return self.restore(json.loads(Path(path).read_text(encoding="utf-8")))

    # ---------- người xác nhận (làm tay ngoài máy) ----------
    def xac_nhan(self, it: dict, kind: str, danhgia: str = "1") -> dict:
        """kind: 'luu' (import thủ công trên TST) | 'xlThu' | 'xlSt' (XỬ LÝ trên TNHS). Ghi sổ cái lượt 'người xác nhận'."""
        ts = int(datetime.now().timestamp() * 1000)
        rnd = "".join(random.choices(string.ascii_lowercase + string.digits, k=5))
        base = {"id": f"{ts}-xn-{rnd}", "ts": ts, "at": now_vn(), "who": "nguoi", "run": "", "nguon": "xacnhan",
                "ok": True, "status": 200, "sohosos": [it["sohoso"]]}
        if kind == "luu":
            e = {**base, "he": "TST", "viec": "Lưu import (người xác nhận)", "loai": "luu",
                 "ketqua": "Người xác nhận đã import thủ công", "madv": it.get("madonvi"), "nRows": ""}
        elif kind == "xlThu":
            ko = danhgia == "3"
            e = {**base, "he": "TNHS", "viec": "XỬ LÝ (Thu)", "loai": "xuly", "bophan": "Thu", "hanhdong": "3",
                 "buoc": "2", "danhgia": "3" if ko else "1",
                 "ketqua": ("Không hợp lệ" if ko else "Hợp lệ") + " (người xác nhận)"}
        elif kind == "xlSt":
            e = {**base, "he": "TNHS", "viec": "XỬ LÝ (Cấp sổ-thẻ)", "loai": "xuly", "bophan": "Cấp sổ-thẻ",
                 "hanhdong": "3", "buoc": "3", "danhgia": "1", "ketqua": "Hợp lệ (người xác nhận)"}
        else:
            raise ValueError(f"Loại xác nhận không rõ: {kind}")
        self.add(e)
        return e

    # ---------- xuất bảng ----------
    def tsv(self) -> str:
        """Bảng sổ cái: 1 dòng / 1 thao tác. Không có họ tên, mã số người lao động."""
        cl = lambda v: re.sub(r"[\t\r\n]+", " ", str("" if v is None else v)).strip()
        head = ["Luc", "Thoi_diem_ms", "He_thong", "Viec", "So_HS", "Ket_qua", "Thanh_cong", "Ai_lam", "Buoc",
                "Ma_DV", "So_dong", "Ly_do", "De_nghi", "Ma_dong_so_cai", "Loai_lenh", "Bo_phan"]
        rows = ["\t".join(head)]
        for e in self.store.socai_all():
            he = e.get("he") or "TST"
            for so in (e.get("sohosos") or [""]):
                rows.append("\t".join(cl(x) for x in [
                    e.get("at"), e.get("ts"), he, e.get("viec") or ("Lưu import" if he == "TST" else ""), so,
                    e.get("ketqua") or ("Thành công" if e.get("ok") else "Không thành công"),
                    "Có" if e.get("ok") else "Không", "Máy" if e.get("who") == "may" else "Người", e.get("buoc") or "",
                    e.get("madv") or "", e.get("nRows") if e.get("nRows") is not None else "", e.get("lydo") or "",
                    e.get("denghi") or "", e.get("id"), e.get("loai") or ("luu" if he == "TST" else ""),
                    e.get("bophan") or ""]))
        return "\ufeff" + "\r\n".join(rows) + "\r\n"
