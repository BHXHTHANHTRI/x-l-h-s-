"""A3 - Lưu vết duyệt: <ngày>/_ketqua/duyet.xlsx (sheet HoSo, ThayDoi). Port exportDuyetXlsx (m7_duyet.js)."""
from __future__ import annotations

from pathlib import Path

from .d02_io import write_xlsx_multi
from .rules import issues_all, nhom_ten
from .store import Store, dx_key


def export_duyet_xlsx(store: Store, lot_id: str) -> Path | None:
    lot = store.get_lot(lot_id)
    if not lot:
        return None
    hs = [["So_HS", "Ma_DV", "Nhom_may_de_xuat", "Quyet_dinh", "Luc", "Ly_do", "De_nghi", "Van_de", "Phieu_truy_thu"]]
    td = [["So_HS", "STT", "Ho_ten", "Cot", "Gia_tri_goc", "Gia_tri_chot", "Nguon"]]
    for it in lot["items"]:
        dx = store.kv_get(dx_key(lot["id"], it["id"]))
        if not dx or not it.get("duyet"):
            continue
        q = it.get("q") or {}
        tc = q.get("kind") == "tuchoi"
        tt = dx.get("truyThu") or {}
        hs.append([it.get("sohoso"), it.get("madonvi"), nhom_ten(dx["nhom"]), it["duyet"].get("kq"), it["duyet"].get("at"),
                   q.get("lyDo") if tc else "", q.get("deNghi") if tc else "",
                   "; ".join(dict.fromkeys(v["txt"] for v in issues_all(dx))),
                   tt.get("noiDung", "") if tt.get("on") else ""])
        for r in dx["rows"]:
            for c in r["chot"]:
                a = "" if r["goc"].get(c) is None else str(r["goc"][c])
                b = "" if r["chot"].get(c) is None else str(r["chot"][c])
                if a == b:
                    continue
                nguon = "Người sửa" if r["tay"].get(c) else ("Máy - theo tra cứu" if r["dx"].get(c) == "tc" else "Máy - tự sửa cơ học")
                td.append([it.get("sohoso"), r["stt"], r["goc"].get("HOTEN"), c, a, b, nguon])
        ex = dx.get("excel")
        if ex and ex.get("state") == "sansang":
            td.append([it.get("sohoso"), "", "", "(cả file)", "",
                       f'Dùng file người sửa bằng Excel: {ex.get("name")} ({ex.get("nRows")} dòng, đọc {ex.get("docLuc")})', "Người sửa"])
    return write_xlsx_multi(store.paths.res_dir(lot["id"]) / "duyet.xlsx", [
        {"name": "HoSo", "aoa": hs, "widths": [22, 18, 20, 30, 20, 50, 50, 60, 60]},
        {"name": "ThayDoi", "aoa": td, "widths": [22, 6, 26, 12, 24, 24, 22]}])
