"""A2 - Nhật ký sự kiện (TST, HGĐ) và gắn sự kiện vào từng dòng hồ sơ (core.js: refreshSk, rowKeySets, eventsOf)."""
from __future__ import annotations

import re
from typing import Optional

from .store import Store


def _sp(v) -> str:
    return re.sub(r"\s+", "", str("" if v is None else v))


def row_key_sets(it: dict, weak: bool = False) -> dict:
    """{stt: {'ma:...', 'cc:...', 'ho:...'}} - khóa mạnh (từ file + tra cứu) hoặc khóa yếu (weak=True)."""
    rows: dict = {}

    def add(stt, kind, v):
        v = _sp(v)
        if v:
            rows.setdefault(stt, set()).add(f"{kind}:{v}")

    if not weak:
        for r in it.get("rk") or []:
            add(r.get("stt"), "ma", r.get("ma"))
            add(r.get("stt"), "cc", r.get("cccd"))
        for r in it.get("rkx") or []:
            for v in r.get("ma") or []: add(r.get("stt"), "ma", v)
            for v in r.get("cccd") or []: add(r.get("stt"), "cc", v)
            for v in r.get("maHo") or []: add(r.get("stt"), "ho", v)
    else:
        for r in it.get("rkx") or []:
            w = r.get("weak")
            if not w:
                continue
            for v in w.get("ma") or []: add(r.get("stt"), "ma", v)
            for v in w.get("cmnd") or []: add(r.get("stt"), "cc", v)
            for v in w.get("ho") or []: add(r.get("stt"), "ho", v)
    return rows


def _stt_key(x):
    try:
        return (0, float(x))
    except (TypeError, ValueError):
        return (1, str(x))


class SuKien:
    def __init__(self, store: Store):
        self.store = store
        self.by_key: dict = {}
        self.strong_all: set = set()
        self.refresh()

    def add(self, ev: dict) -> int:
        n = self.store.sukien_insert(ev)
        self.refresh()
        return n

    def refresh(self) -> None:
        by_key: dict = {}
        for ev in self.store.sukien_all():
            k = ev.get("keys") or {}
            ks = {*(f"ma:{x}" for x in k.get("ma") or []), *(f"cc:{x}" for x in k.get("cccd") or []),
                  *(f"ho:{x}" for x in k.get("maHo") or [])}
            for x in ks:
                by_key.setdefault(x, []).append(ev)
        self.by_key = by_key
        # Khóa mạnh của mọi hồ sơ: để khóa yếu không gắn nhầm sự kiện của người khác vào dòng này
        st: set = set()
        for lot in self.store.get_lots().values():
            for it in lot.get("items", []):
                for ks in row_key_sets(it).values():
                    st |= ks
        self.strong_all = st

    def events_of(self, it: dict) -> list[dict]:
        """Sự kiện gắn với hồ sơ: [{'ev', 'stts': [dòng...]}], theo thời gian."""
        m: dict = {}

        def take(rows: dict, weak: bool):
            for stt, ks in rows.items():
                for k in ks:
                    if weak and k in self.strong_all:
                        continue
                    for ev in self.by_key.get(k, []):
                        # Tìm theo họ tên: kết quả có thể là người khác - không gắn theo khóa của kết quả
                        if ev.get("loai") == "dd_tim" and ev.get("who") == "may" and ev.get("keysFrom") == "ketqua":
                            continue
                        m.setdefault(ev["id"], (ev, set()))[1].add(stt)

        strong = row_key_sets(it)
        derived: dict = {}
        for stt, ks in strong.items():
            for k in ks:
                for ev in self.by_key.get(k, []):
                    if ev.get("loai") != "dd_tim" or ev.get("keysFrom") != "tim":
                        continue
                    for r in ev.get("dd") or []:
                        if r.get("ma"):
                            derived.setdefault(stt, set()).add("ma:" + _sp(r["ma"]))
                        if r.get("maHo"):
                            derived.setdefault(stt, set()).add("ho:" + _sp(r["maHo"]))
        take(strong, False)
        take(row_key_sets(it, True), True)
        take(derived, True)
        cut = it.get("reopenTs") or 0
        out = [{"ev": ev, "stts": sorted(stts, key=_stt_key)} for ev, stts in m.values() if (ev.get("ts") or 0) >= cut]
        out.sort(key=lambda x: x["ev"].get("ts") or 0)
        return out
