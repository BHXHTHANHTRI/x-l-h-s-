"""Bộ 600 - bản Python (tầng A: dữ liệu, sổ cái, Excel, quy tắc duyệt)."""
VERSION = "0.1.0"
