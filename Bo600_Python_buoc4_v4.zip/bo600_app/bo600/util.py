"""Tiện ích dùng chung (port từ core.js và m7_duyet.js)."""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime
from typing import Optional


def date_str(d: Optional[datetime] = None) -> str:
    return (d or datetime.now()).strftime("%Y-%m-%d")


def stamp_str(d: Optional[datetime] = None) -> str:
    return (d or datetime.now()).strftime("%Y-%m-%d_%H%M%S")


def now_vn(d: Optional[datetime] = None) -> str:
    """Giống toLocaleString('vi-VN'): 10:13:00 23/10/2026."""
    return (d or datetime.now()).strftime("%H:%M:%S %d/%m/%Y")


def norm(s) -> str:
    """Bỏ dấu, chữ thường, chỉ giữ a-z0-9 (core.js: norm)."""
    t = unicodedata.normalize("NFD", str(s or ""))
    t = re.sub(r"[\u0300-\u036f]", "", t)
    t = re.sub(r"đ", "d", t, flags=re.I).lower()
    return re.sub(r"[^a-z0-9]", "", t)


def norm_name(s) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", str(s or "")).lower()).strip()


def safe_name(x) -> str:
    return re.sub(r'[<>:"|?*\\/\s]+', "_", str(x or ""))


def so_ho_so_ngan(x) -> str:
    return str(x or "").split("/")[0].strip()


def ma_n(v) -> str:
    return re.sub(r"[^0-9A-Za-z]", "", str(v if v is not None else "")).upper()


_NUM = re.compile(r"[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$")


def num(v) -> Optional[float]:
    """JS: Number(text) với dấu phẩy thành chấm; rỗng/không phải số -> None (NaN)."""
    t = re.sub(r"\s", "", str(v if v is not None else "").strip()).replace(",", ".", 1)
    if not t or not _NUM.match(t):
        return None
    return float(t)


def thang_idx(v) -> int:
    """'MM/YYYY' (hoặc trong 'DD/MM/YYYY') -> năm*12 + tháng; không khớp -> 0."""
    m = re.search(r"(\d{1,2})/(\d{4})", str(v or ""))
    return int(m.group(2)) * 12 + int(m.group(1)) if m else 0


def nop_idx(v) -> int:
    """'DD/MM/YYYY' -> năm*12 + tháng."""
    m = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})", str(v or ""))
    return int(m.group(3)) * 12 + int(m.group(2)) if m else 0


def thang_nay(today: Optional[datetime] = None) -> int:
    d = today or datetime.now()
    return d.year * 12 + d.month


def parse_vn_date(x) -> Optional[datetime]:
    t = str(x or "").strip()
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})(?:\D+(\d{1,2}):(\d{2})(?::(\d{2}))?)?", t)
    if m:
        try:
            return datetime(int(m[3]), int(m[2]), int(m[1]), int(m[4] or 0), int(m[5] or 0), int(m[6] or 0))
        except ValueError:
            return None
    try:
        return datetime.fromisoformat(t)
    except ValueError:
        return None


def ky_to_mmyyyy(ky) -> str:
    t = str(ky or "")
    m = re.search(r"(\d{1,2})\D+(\d{4})", t)
    if m:
        return f"{int(m[1]):02d}_{m[2]}"
    m = re.match(r"^(\d{4})(\d{2})$", t)
    if m:
        return f"{m[2]}_{m[1]}"
    m = re.search(r"(\d{4})\D+(\d{1,2})", t)
    if m:
        return f"{int(m[2]):02d}_{m[1]}"
    return ""


def fallback_base(it: dict) -> str:
    """Port core.js fallbackBase: <mã ĐV><MM>_<YYYY> (KHÔNG có dấu _ giữa mã và kỳ); không rõ kỳ -> <mã ĐV>_<kỳ gốc>."""
    k = ky_to_mmyyyy(it.get("kykekhai"))
    return safe_name(it.get("madonvi")) + (k or "_" + safe_name(it.get("kykekhai") or "ky"))


def ten_file_d02(suggested: str, it: dict) -> tuple:
    """Port background.js decideName (nhánh expect.dir). Trả (tên không đuôi, đuôi).
    Giữ tên gốc do TNHS gợi ý (bỏ đuôi .xlsx/.xls lặp, ký tự cấm -> _, bỏ ' (n)'); nếu tên gốc không chứa
    dạng NN_YYYY thì dùng fallback_base; luôn thêm hậu tố '__<số hồ sơ ngắn>'."""
    orig = re.split(r"[\\/]", str(suggested or ""))[-1]
    m = re.match(r"^(.*?)(\.[A-Za-z0-9]{2,5})$", orig)
    base = m.group(1) if m else orig
    base = re.sub(r"(\.xlsx?)+$", "", base, flags=re.I)
    base = re.sub(r'[<>:"|?*\\/]+', "_", base)
    base = re.sub(r"\s+\(\d+\)$", "", base) or "file"
    ext = m.group(2) if m else ".xlsx"
    if not re.search(r"\d{2}_\d{4}", base):
        base = fallback_base(it)
    return base + "__" + safe_name(it.get("short")), ext


def vn_ts(s) -> float:
    """'hh:mm:ss dd/mm/yyyy' -> epoch ms (0 nếu không khớp)."""
    m = re.search(r"(\d{1,2}):(\d{2}):(\d{2})\s+(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if not m:
        return 0
    return datetime(int(m[6]), int(m[5]), int(m[4]), int(m[1]), int(m[2]), int(m[3])).timestamp() * 1000
