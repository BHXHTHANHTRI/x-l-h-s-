"""A3 - Đọc/ghi Excel: D02 (giữ vị trí dòng), file import đã chốt, kiểm tra file sửa tay, xuất nhiều sheet.

Port từ m7_duyet.js (readD02Wb, buildB64, napExcel) và core.js (codesOfCq, d02SheetName).
Quy ước: giá trị đọc ra luôn là CHỮ đã trim; ô ghi ra luôn là Text (giữ số 0 đầu, ngày tháng).
KHÔNG dùng read_only=True: file xuất từ cổng chính phủ hay thiếu dimension nên read_only đọc sai dòng/cột.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Iterable, Optional

from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from .config import COT_CHU, COT_KHOA
from .util import norm

GOC_SHEET = "GOC_DONVI"


class D02Error(ValueError):
    pass


@dataclass
class Row:
    sr: int                 # số dòng trên sheet (1-based, đúng số dòng Excel) để ghi lại đúng ô
    o: dict                 # {TÊN_CỘT_HOA: giá trị chữ}


@dataclass
class D02:
    wb: object
    ws: Worksheet
    sheet_name: str
    head: list              # tiêu đề cột (HOA, trim), '' nếu cột không có tên
    c0: int                 # số cột (1-based) của phần tử head[0]
    rows: list = field(default_factory=list)

    def col(self, name: str) -> Optional[int]:
        """Số cột (1-based) của tên cột, None nếu không có."""
        try:
            return self.c0 + self.head.index(name)
        except ValueError:
            return None


def cell_text(v) -> str:
    """Giá trị ô -> chữ (giống SheetJS raw:false ở mức cần dùng)."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, datetime):
        return v.strftime("%d/%m/%Y") if (v.hour, v.minute, v.second) == (0, 0, 0) else v.strftime("%d/%m/%Y %H:%M:%S")
    if isinstance(v, date):
        return v.strftime("%d/%m/%Y")
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else repr(v)
    return str(v).strip()


def d02_sheet_name(names: Iterable[str]) -> str:
    names = list(names)
    for n in names:
        if re.match(r"^\s*D02\s*$", n, re.I):
            return n
    return names[0]


def read_d02(src, data_only: bool = True) -> D02:
    wb = src if hasattr(src, "worksheets") else load_workbook(str(src), data_only=data_only)
    sn = d02_sheet_name(wb.sheetnames)
    ws = wb[sn]
    if ws.max_row is None or (ws.max_row == 1 and ws.max_column == 1 and ws.cell(1, 1).value is None):
        raise D02Error("Sheet D02 trống")
    min_r, min_c = ws.min_row, ws.min_column
    aoa = [[cell_text(c) for c in row]
           for row in ws.iter_rows(min_row=min_r, max_row=ws.max_row, min_col=min_c, max_col=ws.max_column,
                                   values_only=True)]
    hi = next((i for i in range(min(25, len(aoa))) if any(c.strip().upper() == "HOTEN" for c in aoa[i])), -1)
    if hi < 0:
        raise D02Error("Không thấy dòng tiêu đề (HOTEN) trong sheet D02")
    head = [c.strip().upper() for c in aoa[hi]]
    hcol = head.index("HOTEN")
    rows = []
    for i in range(hi + 1, len(aoa)):
        r = aoa[i]
        v = r[hcol].strip() if hcol < len(r) else ""
        if not v or re.match(r"^\(?\d+\)?$", v):     # dòng trống / dòng đánh số
            continue
        rows.append(Row(sr=min_r + i, o={h: (r[j].strip() if j < len(r) else "") for j, h in enumerate(head) if h}))
    return D02(wb=wb, ws=ws, sheet_name=sn, head=head, c0=min_c, rows=rows)


_COT_LUONG = {"muctienluong", "mucluong", "tienluong", "luong", "ml", "heso", "hesoluong", "luongcb"}


def _so_luong(v):
    """Giá trị ô lương -> số (giống num() của inspectD02: bỏ dấu chấm nghìn, phẩy thập phân, parseFloat)."""
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = re.sub(r"\s", "", str(v).strip())
    t = re.sub(r"\.(?=\d{3}(\D|$))", "", t).replace(",", ".", 1)
    m = re.match(r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?", t)
    return float(m.group(0)) if m else None


def inspect_luong(d02: "D02") -> str:
    """Loại lương của file D02 để chọn trang import TST: 'HS' (hệ số, mọi giá trị < 20) -> #/psTbbImportV2s/HS;
    'ML' (mức lương, mọi giá trị >= 20) -> .../ML; 'Lẫn ML và HS' hoặc '?' (không xác định) -> tiện ích dùng trang ML.
    Port inspectD02 (core.js)."""
    lc = next((j for j, h in enumerate(d02.head) if norm(h) in _COT_LUONG), -1)
    if lc < 0:
        return "?"
    v = []
    for r in d02.rows:
        x = _so_luong(d02.ws.cell(r.sr, d02.c0 + lc).value)
        if x is not None and x == x and x > 0:
            v.append(x)
    if not v:
        return "?"
    if all(x < 20 for x in v):
        return "HS"
    return "ML" if all(x >= 20 for x in v) else "Lẫn ML và HS"


def _put_text(ws: Worksheet, row: int, col: int, v: str) -> None:
    cell = ws.cell(row=row, column=col)
    if v == "":
        cell.value = None
        return
    cell.value = v
    cell.data_type = "s"          # tránh openpyxl hiểu "=..." là công thức
    cell.number_format = "@"


def build_import(src: str | Path, dst: str | Path, dx_rows: list, with_goc: bool = False) -> Path:
    """Ghi các giá trị đã chốt vào BẢN SAO file gốc. Mọi ô sửa ghi dạng CHỮ; giá trị trống thì xóa ô.

    dx_rows: [{'sr': số dòng Excel, 'goc': {...}, 'chot': {...}}]. with_goc: thêm sheet GOC_DONVI = D02 gốc.
    """
    S = read_d02(src, data_only=False)
    if with_goc:                   # sao chép TRƯỚC khi sửa để sheet gốc đúng nguyên bản
        g = S.wb.copy_worksheet(S.ws)
        g.title = GOC_SHEET
    for r in dx_rows:
        for c, val in r["chot"].items():
            col = S.col(c)
            if c in COT_KHOA or col is None:
                continue
            v = "" if val is None else str(val)
            if v == ("" if r["goc"].get(c) is None else str(r["goc"].get(c))):
                continue
            _put_text(S.ws, r["sr"], col, v)
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    S.wb.save(str(dst))
    return dst


# ---------- file người sửa bằng Excel ("Import lại file đã sửa") ----------
@dataclass
class EditedResult:
    errors: list
    n_rows: int = 0
    d02: Optional[D02] = None


def validate_edited(path: str | Path, it: dict, goc_rows: list, out_path: Optional[str | Path] = None) -> EditedResult:
    """Kiểm tra file sửa tay: đúng tên, có sheet D02, GHICHU có số hồ sơ, đủ dòng/STT, ô mã/ngày còn là Text.

    Hợp lệ thì (nếu có out_path) ghi bản đã chuẩn hóa mọi ô sang Text, bỏ sheet GOC_DONVI - máy import sau không cần người.
    goc_rows: [{'goc': {...}}] của bản gốc (dx['rows']).
    """
    path = Path(path)
    want = Path(it.get("file") or "").name
    if path.name != want:
        return EditedResult([f'Chọn nhầm file "{path.name}": hồ sơ {it.get("sohoso")} cần đúng file "{want}"'])
    try:
        wb = load_workbook(str(path), data_only=True)
        if not any(re.match(r"^\s*D02\s*$", n) for n in wb.sheetnames):
            raise D02Error('File không có sheet tên đúng "D02"')
        for n in [n for n in wb.sheetnames if re.match(r"^GOC_DONVI$", n, re.I)]:
            del wb[n]
        S = read_d02(wb)
    except Exception as e:                                       # noqa: BLE001 - báo nguyên văn cho người dùng
        return EditedResult([f"Không đọc được file: {e}"])

    err: list[str] = []
    so = str(it.get("sohoso") or "")
    for i, r in enumerate(S.rows):
        if so not in str(r.o.get("GHICHU", "")):
            err.append(f'Dòng {r.o.get("STT") or i + 1} ({r.o.get("HOTEN")}): GHICHU không có "{so}"')
    n_goc = len(goc_rows)
    if len(S.rows) < n_goc:
        err.append(f"File có {len(S.rows)} dòng, ít hơn bản gốc ({n_goc} dòng)")
    stt_moi = {str(r.o.get("STT")) for r in S.rows}
    thieu = [str(g["goc"].get("STT")) for g in goc_rows if str(g["goc"].get("STT")) not in stt_moi]
    if thieu:
        err.append("Thiếu dòng STT gốc: " + ", ".join(thieu))

    for r in S.rows:                       # ô số/ngày ở cột phải là chữ (Excel đổi "0123" thành 123, "10/2026" thành ngày)
        for c in S.head:
            col = S.col(c) if c else None
            if col is None:
                continue
            cell = S.ws.cell(row=r.sr, column=col)
            if cell.value is None or isinstance(cell.value, str):
                continue
            if c in COT_CHU and (cell.data_type in ("n", "d") or isinstance(cell.value, (int, float, date, datetime))):
                err.append(f'Dòng {r.o.get("STT") or "?"} cột {c}: Excel đã đổi thành ô SỐ/NGÀY '
                           f"({cell_text(cell.value)}) - định dạng ô Text, nhập lại")
                continue
            _put_text(S.ws, r.sr, col, cell_text(cell.value))
    if err:
        return EditedResult(err, len(S.rows))
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        S.wb.save(str(out_path))
    return EditedResult([], len(S.rows), S)


# ---------- xuất nhiều sheet (duyet.xlsx, tracuu.xlsx, danh mục) ----------
def write_xlsx_multi(path: str | Path, sheets: list[dict]) -> Path:
    """sheets: [{'name', 'aoa': [[...]], 'widths': [..]}]. Mọi ô chữ ghi Text."""
    wb = Workbook()
    wb.remove(wb.active)
    for sh in sheets:
        ws = wb.create_sheet(sh["name"][:31])
        for r in sh["aoa"]:
            ws.append(["" if v is None else v for v in r])
        for r in ws.iter_rows():
            for c in r:
                if isinstance(c.value, str):
                    c.data_type = "s"
                    c.number_format = "@"
        for i, w in enumerate(sh.get("widths") or [], start=1):
            ws.column_dimensions[get_column_letter(i)].width = w
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return path


# ---------- danh sách đơn vị xuất từ TST (bước 1) ----------
def codes_of_cq(path: str | Path, cq: str) -> set:
    """Mã đơn vị thuộc chuyên quản `cq` trong file Danh mục đơn vị xuất từ TST."""
    wb = load_workbook(str(path), data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = [[cell_text(c) for c in r] for r in ws.iter_rows(values_only=True)]
    ma, cqi = 1, 8                          # vị trí mặc định như extension
    for r in rows[:15]:
        n = [norm(x) for x in r]
        a = next((i for i, x in enumerate(n) if "madv" in x or "madonvi" in x), -1)
        b = next((i for i, x in enumerate(n) if "chuyenquan" in x), -1)
        if a >= 0 or b >= 0:
            ma = a if a >= 0 else ma
            cqi = b if b >= 0 else cqi
            break
    out = set()
    for r in rows:
        if cqi < len(r) and r[cqi].strip() == cq and ma < len(r):
            c = r[ma].replace("'", "").strip().upper()
            if c:
                out.add(c)
    return out
