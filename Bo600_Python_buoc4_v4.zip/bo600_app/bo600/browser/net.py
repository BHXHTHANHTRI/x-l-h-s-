"""Theo dõi mạng của một tab (thay page_hook.js): đếm yêu cầu dữ liệu đang chờ, lưu phản hồi để đọc lại,
nghe theo mẫu URL, chặn lệnh (ví dụ POST /api/importTbb/import khi kiểm tra nháp).

Quan sát thuần: không gửi thêm yêu cầu nào. Bộ nghe chỉ GHI NHẬN; việc đọc nội dung phản hồi làm ở `process()`
(gọi từ Tab.sleep) để không gọi lệnh Playwright bên trong trình xử lý sự kiện.
"""
from __future__ import annotations

import re
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass
class Hit:
    ts: float
    url: str
    method: str
    status: int
    resp: object = field(repr=False)

    def text(self) -> Optional[str]:
        try:
            return self.resp.text()
        except Exception:                                      # noqa: BLE001 - nội dung không còn (trang đã chuyển, redirect...)
            return None

    def json(self):
        import json
        t = self.text()
        try:
            return json.loads(t) if t is not None else None
        except ValueError:
            return None

    def post_data(self) -> Optional[str]:
        try:
            return self.resp.request.post_data
        except Exception:                                      # noqa: BLE001
            return None


class NetLog:
    def __init__(self, page, keep: int = 400):
        self.page = page
        self.pending: dict[int, float] = {}
        self.log: deque[Hit] = deque(maxlen=keep)
        self.blocked: list[dict] = []
        self._listeners: list[tuple[re.Pattern, Callable]] = []
        self._todo: deque = deque()
        self._routes: dict[str, Callable] = {}
        page.on("request", self._on_req)
        page.on("requestfinished", self._on_done)
        page.on("requestfailed", self._on_done)
        page.on("response", self._on_resp)

    # ---- sự kiện ----
    def _on_req(self, req) -> None:
        try:
            if req.resource_type in ("xhr", "fetch"):
                self.pending[id(req)] = time.monotonic()
        except Exception:                                      # noqa: BLE001
            pass

    def _on_done(self, req) -> None:
        self.pending.pop(id(req), None)

    def _on_resp(self, resp) -> None:
        try:
            req = resp.request
            h = Hit(time.monotonic(), resp.url, req.method, resp.status, resp)
        except Exception:                                      # noqa: BLE001
            return
        self.log.append(h)
        for rx, cb in self._listeners:
            if rx.search(h.url):
                self._todo.append((cb, h))

    # ---- cổng ổn định ----
    def yeu_cau_cho(self, last_act: float, cu_ms: int = 15000) -> int:
        """Số yêu cầu đang chờ: phát sinh từ thao tác trước của máy, hoặc mới trong `cu_ms` (treo cũ hơn thì bỏ qua)."""
        now = time.monotonic()
        return sum(1 for t in self.pending.values() if t >= last_act - 0.1 or (now - t) * 1000 < cu_ms)

    def yeu_cau_moi(self, last_act: float) -> int:
        return sum(1 for t in self.pending.values() if t >= last_act - 0.1)

    # ---- đọc lại phản hồi ----
    def find(self, pattern: str, since: float = 0.0, method: Optional[str] = None) -> Optional[Hit]:
        rx = re.compile(pattern)
        for h in reversed(self.log):
            if h.ts < since:
                break
            if rx.search(h.url) and (method is None or h.method == method):
                return h
        return None

    def find_all(self, pattern: str, since: float = 0.0) -> list[Hit]:
        rx = re.compile(pattern)
        return [h for h in self.log if h.ts >= since and rx.search(h.url)]

    def on_response(self, pattern: str, callback: Callable[[Hit], None]) -> None:
        """Gọi callback(hit) mỗi khi có phản hồi khớp mẫu - thực thi trong process()."""
        self._listeners.append((re.compile(pattern), callback))

    def clear_listeners(self) -> None:
        self._listeners.clear()
        self._todo.clear()

    def process(self) -> int:
        n = 0
        while self._todo:
            cb, h = self._todo.popleft()
            try:
                cb(h)
            except Exception:                                  # noqa: BLE001 - lỗi của bộ nghe không được làm hỏng bước chạy
                pass
            n += 1
        return n

    # ---- chặn lệnh ----
    def block(self, pattern: str, methods: tuple = ("POST",), label: str = "") -> None:
        """Chặn (abort) yêu cầu khớp mẫu và đúng phương thức; yêu cầu khác đi qua bình thường."""
        if pattern in self._routes:
            return
        rx = re.compile(pattern)

        def handler(route, request):
            if request.method in methods:
                self.blocked.append({"ts": time.monotonic(), "url": request.url, "method": request.method, "label": label})
                route.abort()
            else:
                route.continue_()

        self._routes[pattern] = handler
        self.page.route(rx, handler)

    def unblock(self, pattern: str) -> None:
        h = self._routes.pop(pattern, None)
        if h:
            self.page.unroute(re.compile(pattern), h)

    def unblock_all(self) -> None:
        for p in list(self._routes):
            self.unblock(p)
