"""Phiên điều khiển: nối vào Chrome đang mở cổng gỡ lỗi, quản lý các tab theo vai (tst, tnhs, hgd...).

Dùng trong luồng chạy nền (Playwright bản đồng bộ phải dùng đúng luồng tạo ra nó), mỗi lượt chạy một phiên:

    with BrowserSession(port, od=settings["on_dinh"], stop_check=ctx.check_stop) as br:
        tst = br.tab("tst", "tst.bhxh.gov.vn", "https://tst.bhxh.gov.vn/")
"""
from __future__ import annotations

from typing import Callable, Optional

from playwright.sync_api import sync_playwright

from .chrome import DEFAULT_PORT
from .jsrt import RUNTIME_JS
from .tab import Tab


class BrowserSession:
    def __init__(self, port: int = DEFAULT_PORT, od: Optional[dict] = None, stop_check: Optional[Callable] = None):
        self.port, self.od, self.stop_check = port, od, stop_check
        self.pw = self.browser = self.ctx = None
        self.tabs: dict[str, Tab] = {}

    def __enter__(self) -> "BrowserSession":
        self.pw = sync_playwright().start()
        try:
            self.browser = self.pw.chromium.connect_over_cdp(f"http://127.0.0.1:{self.port}")
        except Exception as e:                                 # noqa: BLE001
            self.pw.stop()
            raise ConnectionError(f"Không nối được Chrome ở cổng {self.port}. Mở Chrome bằng nút “Mở Chrome điều khiển được” "
                                  f"(Cài đặt → Trình duyệt). Chi tiết: {e}") from None
        self.ctx = self.browser.contexts[0] if self.browser.contexts else self.browser.new_context()
        self.ctx.add_init_script(RUNTIME_JS)
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        """Ngắt kết nối. Chrome của người dùng vẫn mở."""
        for t in self.tabs.values():
            try:
                t.net.unblock_all()
            except Exception:                                  # noqa: BLE001
                pass
        try:
            if self.browser:
                self.browser.close()
        except Exception:                                      # noqa: BLE001
            pass
        try:
            if self.pw:
                self.pw.stop()
        except Exception:                                      # noqa: BLE001
            pass
        self.pw = self.browser = self.ctx = None

    # ---------- tab ----------
    def pages(self) -> list:
        return list(self.ctx.pages) if self.ctx else []

    def find_page(self, match: str):
        for p in self.pages():
            if match in (p.url or ""):
                return p
        return None

    def tab(self, role: str, match: str, url: Optional[str] = None, mo_moi: bool = True) -> Tab:
        """Tab theo vai: dùng tab đã mở có URL chứa `match`; chưa có thì mở `url` (nếu mo_moi)."""
        cached = self.tabs.get(role)
        if cached and not cached.page.is_closed():
            return cached
        page = self.find_page(match)
        if page is None:
            if not (mo_moi and url):
                raise LookupError(f"Chưa mở trang {match} trong Chrome - mở và đăng nhập trước.")
            page = self.ctx.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
        t = Tab(self, page, role)
        self.tabs[role] = t
        return t

    def info(self) -> dict:
        return {"version": self.browser.version if self.browser else "", "tabs": [{"url": p.url, "title": p.title()} for p in self.pages()]}
