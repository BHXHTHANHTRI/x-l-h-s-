"""Tầng B: điều khiển Chrome thật (đã đăng nhập) qua CDP bằng Playwright. Thay content.js/page_hook.js/background.js."""
from .chrome import cdp_up, find_chrome, launch_chrome
from .session import BrowserSession
from .tab import GateTimeout, NotReady, Tab, Target

__all__ = ["BrowserSession", "Tab", "Target", "GateTimeout", "NotReady", "find_chrome", "launch_chrome", "cdp_up"]
