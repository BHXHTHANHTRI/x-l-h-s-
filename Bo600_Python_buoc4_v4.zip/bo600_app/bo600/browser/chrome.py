"""Tìm và mở Chrome ở chế độ cho phép điều khiển (cổng gỡ lỗi), dùng hồ sơ riêng.

Chrome từ bản 136 chỉ cho bật cổng gỡ lỗi khi có --user-data-dir riêng (không dùng được hồ sơ mặc định).
Vì vậy phiên đăng nhập TST/TNHS và tiện ích TIC phải được cài/đăng nhập một lần trong hồ sơ riêng này.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Optional, Sequence

DEFAULT_PORT = 9222


def find_chrome() -> Optional[Path]:
    cand: list[str] = []
    if sys.platform.startswith("win"):
        for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            base = os.environ.get(env)
            if base:
                cand += [rf"{base}\Google\Chrome\Application\chrome.exe", rf"{base}\Microsoft\Edge\Application\msedge.exe"]
    elif sys.platform == "darwin":
        cand += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    else:
        cand += [shutil.which(n) or "" for n in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge")]
    for c in cand:
        if c and Path(c).is_file():
            return Path(c)
    return None


def cdp_up(port: int = DEFAULT_PORT, timeout: float = 1.0) -> Optional[dict]:
    """Trả về thông tin /json/version nếu Chrome đang mở cổng gỡ lỗi, không thì None."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:                                          # noqa: BLE001 - mọi lỗi kết nối nghĩa là chưa mở
        return None


def launch_chrome(profile_dir: str | os.PathLike, port: int = DEFAULT_PORT, urls: Sequence[str] = (),
                  chrome_path: Optional[str | os.PathLike] = None, extra_args: Sequence[str] = (),
                  env: Optional[dict] = None, wait_s: float = 25.0) -> Optional[subprocess.Popen]:
    """Mở Chrome với cổng gỡ lỗi. Đã mở sẵn trên cổng đó thì không mở thêm (trả về None).
    Chrome được tách khỏi app: đóng Bộ 600 không đóng Chrome."""
    if cdp_up(port):
        return None
    exe = Path(chrome_path) if chrome_path else find_chrome()
    if not exe or not Path(exe).is_file():
        raise FileNotFoundError("Không tìm thấy Chrome. Chọn đường dẫn chrome.exe trong Cài đặt → Trình duyệt.")
    Path(profile_dir).mkdir(parents=True, exist_ok=True)
    args = [str(exe), f"--remote-debugging-port={port}", f"--user-data-dir={profile_dir}", "--no-first-run",
            "--no-default-browser-check", *extra_args, *urls]
    kw: dict = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL, "stdin": subprocess.DEVNULL}
    if env:
        kw["env"] = {**os.environ, **env}
    if sys.platform.startswith("win"):
        kw["creationflags"] = 0x00000008 | 0x00000200          # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        kw["start_new_session"] = True
    p = subprocess.Popen(args, **kw)
    t0 = time.time()
    while time.time() - t0 < wait_s:
        if cdp_up(port):
            return p
        if p.poll() is not None:
            break
        time.sleep(0.3)
    raise RuntimeError(f"Chrome không mở cổng gỡ lỗi {port} sau {int(wait_s)} giây "
                       "(nếu Chrome đang chạy bằng hồ sơ này thì đóng hết cửa sổ Chrome rồi thử lại).")
