"""Mã chạy TRONG trang: cổng ổn định (port từ content.js: vis, dangTai, biChe, khoa, MutationObserver, setValue, clickEl).
Cài qua context.add_init_script (mọi tài liệu mới) và page.evaluate (trang đã mở). Idempotent."""

RUNTIME_JS = r"""
(() => {
  if (window.__bo600rt) return;
  const BO_QUA_DOM = '#toast-container, .toast, .toast-message, md-toast, .md-ripple-container, [data-bo600-ui]';
  const LOADING_SEL = 'div.block-ui, .block-ui-overlay, .block-ui-container, div.spinner, md-progress-linear, md-progress-circular, #loading-bar, #loading-bar-spinner';
  const rt = window.__bo600rt = { domLast: Date.now() };
  const attach = () => {
    try {
      new MutationObserver((ms) => {
        for (const m of ms) {
          const t = m.target;
          if (m.type === 'attributes' && t === document.documentElement) continue;
          const e = t && t.nodeType === 1 ? t : (t && t.parentElement);
          if (e && e.closest && e.closest(BO_QUA_DOM)) continue;
          rt.domLast = Date.now(); return;
        }
      }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
    } catch (e) { /* bỏ qua */ }
  };
  if (document.documentElement) attach();
  else new MutationObserver((_, o) => { if (document.documentElement) { o.disconnect(); attach(); } }).observe(document, { childList: true });

  rt.vis = (el) => {
    if (!el) return false;
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden') return false;
    return el.offsetParent !== null || s.position === 'fixed';
  };
  rt.khoa = (el) => !!(el.disabled || el.getAttribute('aria-disabled') === 'true' || (el.closest && el.closest('fieldset[disabled]')));
  rt.dangTai = () => {
    for (const x of document.querySelectorAll(LOADING_SEL)) {
      if (!rt.vis(x) || (x.closest && x.closest('[data-bo600-ui]'))) continue;
      const r = x.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue;
      if (/block-ui/.test(x.className || '') && !/fixed|absolute/.test(getComputedStyle(x).position) && !/block-ui-(visible|active)/.test(x.className || '')) continue;
      return (x.tagName || '').toLowerCase() + (typeof x.className === 'string' && x.className ? '.' + x.className.trim().split(/\s+/)[0] : '');
    }
    return '';
  };
  rt.biChe = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return 'không có kích thước';
    const x = r.left + Math.min(r.width / 2, 40), y = r.top + Math.min(r.height / 2, 14);
    if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return 'nằm ngoài màn hình';
    const h = document.elementFromPoint(x, y);
    if (!h || h === el || el.contains(h) || h.contains(el)) return '';
    if (h.closest && (h.closest('[data-bo600-ui]') || (h.closest('label') && h.closest('label').contains(el)))) return '';
    return 'đang bị che (' + (h.tagName || '').toLowerCase() + (typeof h.className === 'string' && h.className ? '.' + h.className.trim().split(/\s+/)[0] : '') + ')';
  };
  rt.touch = () => { rt.domLast = Date.now(); };
  rt.pageState = () => ({ tai: rt.dangTai(), domAge: Date.now() - rt.domLast });
  // Khám phần tử như onDinh: trả về trạng thái; cuộn vào giữa màn hình một lần nếu nằm ngoài
  rt.probe = async (el, an, cuon) => {
    const o = { connected: el.isConnected, vis: rt.vis(el), locked: rt.khoa(el), che: '', rect: '', scrolled: false };
    if (!o.connected || an || !o.vis || o.locked) return o;
    let r = el.getBoundingClientRect();
    if (!cuon && (r.bottom < 0 || r.top > innerHeight)) {
      try { el.scrollIntoView({ block: 'center' }); } catch (e) { /* bỏ qua */ }
      await new Promise((f) => setTimeout(f, 200)); r = el.getBoundingClientRect(); o.scrolled = true;
    }
    o.che = rt.biChe(el);
    o.rect = Math.round(r.left) + ',' + Math.round(r.top) + ',' + Math.round(r.width) + ',' + Math.round(r.height);
    return o;
  };
  rt.clickEl = (el) => ['mousedown', 'mouseup', 'click'].forEach((t) =>
    el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, button: 0 })));
  rt.setValue = (el, v) => {
    el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  // Tìm phần tử: css (+ text chứa/bằng, + rx), trong within; ưu tiên phần tử đang hiện
  rt.find = (a) => {
    const root = a.within ? document.querySelector(a.within) : document;
    if (!root) return null;
    let els = [...root.querySelectorAll(a.css || '*')];
    const txt = (e) => (e.innerText || e.value || '').replace(/\s+/g, ' ').trim();
    if (a.text != null) {
      const t = a.text.toLowerCase();
      els = els.filter((e) => { const x = txt(e).toLowerCase(); return a.exact ? x === t : x.includes(t); });
    }
    if (a.rx) { const re = new RegExp(a.rx, 'i'); els = els.filter((e) => re.test(txt(e))); }
    if (!a.css && els.length > 1 && els.length < 400) els = els.filter((e) => !els.some((o) => o !== e && e.contains(o)));
    if (!els.length) return null;
    const v = els.filter(rt.vis), pool = v.length ? v : els;
    return a.last ? pool[pool.length - 1] : pool[0];
  };
})();

;(() => {
  // Ghi lại thông báo (toast) của trang - port scanToasts của content.js. Đọc bằng Tab.toast_mark / toasts_since.
  if (window.__bo600toast) return;
  const T = window.__bo600toast = { list: [], ts: [] };
  const scan = (root) => {
    if (!root || !root.querySelectorAll) return;
    const list = root.matches && root.matches('.toast-message') ? [root] : root.querySelectorAll('.toast-message');
    list.forEach((el) => {
      const t = (el.textContent || '').trim();
      if (t && !el.__bo600Seen) { el.__bo600Seen = true; T.list.push(t); T.ts.push(Date.now()); }
    });
  };
  const attach = () => {
    try {
      scan(document.documentElement);
      new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => scan(n.nodeType === 1 ? n : null))))
        .observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) { /* bỏ qua */ }
  };
  if (document.documentElement) attach();
  else new MutationObserver((_, o) => { if (document.documentElement) { o.disconnect(); attach(); } }).observe(document, { childList: true });
})();

;(() => {
  // Hộp nhắc "ĐẾN GIỜ TÍCH HỒ SƠ" của TIC phủ kín màn hình: khi máy đang chạy (window.__bo600oke = true) tự bấm
  // "OKE, ĐỂ TÔI TÍCH!" (nút này chỉ đóng hộp và hẹn nhắc lại sau, không tích hồ sơ nào). Không bấm "CHƯA TÍCH ĐƯỢC".
  if (window.__bo600okeIv) return;
  window.__bo600okeIv = setInterval(() => {
    if (!window.__bo600oke) return;
    const ov = document.getElementById('__bhxh_remind_overlay'); if (!ov) return;
    const b = [...ov.querySelectorAll('button')].find((x) => /OKE/i.test(x.textContent || ''));
    if (b) { try { b.click(); } catch (e) { /* bỏ qua */ } }
  }, 700);
})();
"""
