"""Một tab trình duyệt + cổng ổn định + thao tác an toàn (port từ content.js: onDinh, bam, dien, sanSang, choTH, hetTai).

Nguyên tắc như extension: máy chỉ thao tác khi màn hình ổn định như người nhìn thấy; quá hạn thì BÁO LỖI [HT] và dừng lượt,
không bấm mò, không tự thử lại. Mọi chỗ chờ đều bơm sự kiện Playwright (page.wait_for_timeout) nên nghe mạng không bị đứng.
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from playwright.sync_api import Error as PWError

from .jsrt import RUNTIME_JS
from .net import NetLog

OD_MAC_DINH = {"langMs": 600, "nhipMin": 800, "nhipMax": 1500, "toiDaGiay": 90, "yeuCauCu": 15000, "domKhongLangSau": 20000}


class GateTimeout(RuntimeError):
    """[HT] Trang chưa ổn định / chưa phản hồi trong thời hạn - máy không thao tác."""


class NotReady(RuntimeError):
    """Không thao tác được phần tử (chưa hiện / bị khóa) - thao tác nhanh."""


@dataclass
class Target:
    """Cách tìm một phần tử: css (+ text/rx/within/last) hoặc hàm lay(page) -> ElementHandle|None."""
    css: Optional[str] = None
    text: Optional[str] = None
    exact: bool = False
    rx: Optional[str] = None
    within: Optional[str] = None
    last: bool = False
    lay: Optional[Callable] = None
    ten: str = ""
    an: bool = False          # phần tử ẩn (ô file...): bỏ kiểm tra hiện/che

    def resolve(self, page):
        if self.lay:
            return self.lay(page)
        h = page.evaluate_handle("a => __bo600rt.find(a)", {"css": self.css, "text": self.text, "exact": self.exact,
                                                              "rx": self.rx, "within": self.within, "last": self.last})
        el = h.as_element()
        if el is None:
            h.dispose()
        return el


def _tgt(t) -> Target:
    return Target(css=t) if isinstance(t, str) else t


class Tab:
    def __init__(self, session, page, role: str):
        self.session, self.page, self.role = session, page, role
        self.od = {**OD_MAC_DINH, **(session.od or {})}
        self.net = NetLog(page)
        self.last_act = 0.0
        self.ensure_rt()

    # ---------- hạ tầng ----------
    def _check_stop(self) -> None:
        if self.session.stop_check:
            self.session.stop_check()

    def ensure_rt(self) -> None:
        try:
            self.page.evaluate(RUNTIME_JS)
        except PWError:
            pass                                               # trang đang chuyển; init script sẽ cài ở tài liệu mới

    def sleep(self, ms: float) -> None:
        """Ngủ nhưng vẫn bơm sự kiện mạng và thoát khi bấm Dừng."""
        end = time.monotonic() + ms / 1000
        while True:
            self._check_stop()
            left = end - time.monotonic()
            if left <= 0:
                break
            try:
                self.page.wait_for_timeout(min(100, left * 1000))
            except PWError:
                time.sleep(min(0.1, left))
            self.net.process()
        self.net.process()

    def _touch(self) -> None:
        self.last_act = time.monotonic()
        try:
            self.page.evaluate("__bo600rt.touch()")
        except PWError:
            pass

    def page_state(self) -> dict:
        try:
            return self.page.evaluate("(window.__bo600rt ? __bo600rt.pageState() : null)") or self._reinstall()
        except PWError:
            self.ensure_rt()
            return {"tai": "", "domAge": 0}

    def _reinstall(self) -> dict:
        self.ensure_rt()
        return self.page.evaluate("__bo600rt.pageState()")

    # ---------- điều hướng ----------
    def goto(self, url: str, timeout_ms: int = 60000) -> None:
        self.page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
        self.ensure_rt()

    def goto_hash(self, h: str, timeout_ms: int = 15000) -> None:
        """Điều hướng SPA (Angular) bằng #hash rồi chờ hash khớp."""
        h = h if h.startswith("#") else "#" + h
        self.page.evaluate("h => { if (location.hash !== h) location.hash = h; }", h)
        end = time.monotonic() + timeout_ms / 1000
        while time.monotonic() < end:
            if self.page.evaluate("location.hash") == h:
                self._touch()
                return
            self.sleep(100)
        raise GateTimeout(f"[HT] Không chuyển được sang {h} sau {timeout_ms // 1000} giây")

    def bring_to_front(self) -> None:
        try:
            self.page.bring_to_front()
        except PWError:
            pass

    def ho_tai(self, toi_da_ms: int = 8000) -> None:
        """hetTai: chờ hết lớp 'đang tải'; quá hạn vẫn đi tiếp (TNHS có lệnh nạp ~60 giây kèm biểu tượng tải)."""
        end = time.monotonic() + toi_da_ms / 1000
        while time.monotonic() < end:
            if not self.page_state()["tai"]:
                return
            self.sleep(100)

    # ---------- cổng ổn định đầy đủ (onDinh) ----------
    def cho_on_dinh(self, target=None, *, san: Optional[Callable[[], bool]] = None, san_ten: str = "", viec: str = "",
                    toi_da: Optional[float] = None, khong_nghi: bool = False, ten: str = "", an: Optional[bool] = None):
        target = _tgt(target) if target is not None else None
        ten = ten or (target.ten if target else "") or "phần tử"
        an = (target.an if target else False) if an is None else an
        od = self.od
        t0 = time.monotonic()
        han = float(toi_da or od["toiDaGiay"])
        rect0, nghi_xong, cuon, el, ly = None, False, False, None, ""
        while True:
            self._check_stop()
            ly = ""
            el = None
            try:
                st = self.page_state()
                el = target.resolve(self.page) if target else None
                n_cho = self.net.yeu_cau_cho(self.last_act, od["yeuCauCu"])
                if st["tai"]:
                    ly = f'màn hình đang tải ({st["tai"]})'
                elif n_cho:
                    ly = f"còn {n_cho} yêu cầu dữ liệu đang chờ trả lời"
                elif st["domAge"] < od["langMs"] and (time.monotonic() - t0) * 1000 < od["domKhongLangSau"]:
                    ly = "giao diện đang thay đổi"
                elif san and not san():
                    ly = san_ten or "dữ liệu chưa nạp xong"
                elif target and el is None:
                    ly = f"chưa thấy {ten}"
                elif el is not None:
                    p = el.evaluate("(e, a) => __bo600rt.probe(e, a.an, a.cuon)", {"an": an, "cuon": cuon})
                    cuon = cuon or p["scrolled"]
                    if not p["connected"]:
                        ly = "phần tử đã bị trang vẽ lại"
                    elif not an and not p["vis"]:
                        ly = f"{ten} chưa hiện"
                    elif p["locked"]:
                        ly = f"{ten} đang bị khóa"
                    elif not an:
                        if p["che"]:
                            ly = f'{ten} {p["che"]}'
                        elif rect0 != p["rect"]:
                            rect0 = p["rect"]
                            ly = f"{ten} đang di chuyển"
            except PWError:
                ly = "trang đang chuyển hoặc tải lại"
                el = None
            if not ly:
                if nghi_xong or khong_nghi:
                    break
                self.sleep(od["nhipMin"] + random.random() * max(0, od["nhipMax"] - od["nhipMin"]))   # nhịp người
                nghi_xong = True
                continue
            nghi_xong = False
            if time.monotonic() - t0 > han:
                raise GateTimeout(f"[HT] Trang chưa ổn định sau {round(han)} giây" + (f' ở bước "{viec}"' if viec else "")
                                  + f": {ly} - máy không thao tác, dừng lượt (chạy lại ở lượt sau)")
            self.sleep(150)
        return el

    def bam(self, target, *, goc: bool = False, **o):
        el = self.cho_on_dinh(target, **o)
        el.evaluate("e => e.click()" if goc else "e => __bo600rt.clickEl(e)")
        self._touch()
        return el

    def dien(self, target, value: str, **o):
        el = self.cho_on_dinh(target, **o)
        try:
            el.evaluate("e => e.focus()")
        except PWError:
            pass
        el.evaluate("(e, v) => __bo600rt.setValue(e, v)", value)
        self._touch()
        return el

    # ---------- chờ theo tín hiệu (choTH) - bước 9 ----------
    def cho_th(self, target, *, san: Optional[Callable[[], bool]] = None, san_ten: str = "", viec: str = "",
               toi_da: float = 90, ten: str = "", an: Optional[bool] = None):
        target = _tgt(target)
        ten = ten or target.ten or "phần tử"
        an = target.an if an is None else an
        t0, ly = time.monotonic(), ""
        while time.monotonic() - t0 < toi_da:
            self._check_stop()
            try:
                st = self.page_state()
                el = target.resolve(self.page)
                if el is None:
                    ly = f"chưa thấy {ten}"
                else:
                    p = el.evaluate("(e, a) => __bo600rt.probe(e, true, true)", {})
                    if not p["connected"]:
                        ly = f"chưa thấy {ten}"
                    elif not an and not p["vis"]:
                        ly = f"{ten} chưa hiện"
                    elif not an and p["locked"]:
                        ly = f"{ten} đang bị khóa"
                    elif st["tai"]:
                        ly = f'màn hình đang tải ({st["tai"]})'
                    elif self.net.yeu_cau_moi(self.last_act):
                        ly = "còn yêu cầu dữ liệu đang chờ trả lời"
                    elif san and not san():
                        ly = san_ten or "dữ liệu chưa nạp xong"
                    else:
                        return el
            except PWError:
                ly = "trang đang chuyển hoặc tải lại"
            self.sleep(100)
        raise GateTimeout(f"[HT] Trang chưa phản hồi sau {round(toi_da)} giây" + (f' ở bước "{viec}"' if viec else "")
                          + f": {ly} - máy không thao tác, dừng lượt (chạy lại ở lượt sau)")

    def bam_th(self, target, *, goc: bool = False, **o):
        el = self.cho_th(target, **o)
        el.evaluate("e => e.click()" if goc else "e => __bo600rt.clickEl(e)")
        self._touch()
        return el

    # ---------- thao tác nhanh (sanSang) - bước 1-5 và 8 ----------
    def san_sang(self, target, *, ten: str = "", viec: str = "", toi_da: float = 15, an: Optional[bool] = None):
        target = _tgt(target)
        ten = ten or target.ten or "phần tử"
        an = target.an if an is None else an
        t0 = time.monotonic()
        while time.monotonic() - t0 < toi_da:
            self._check_stop()
            try:
                el = target.resolve(self.page)
                if el is not None:
                    p = el.evaluate("e => __bo600rt.probe(e, true, true)")
                    if p["connected"] and (an or p["vis"]) and not p["locked"]:
                        return el
            except PWError:
                pass
            self.sleep(100)
        raise NotReady(f"Không thao tác được {ten}" + (f' ở bước "{viec}"' if viec else "")
                       + f": chưa hiện hoặc đang bị khóa sau {round(toi_da)} giây")

    def bam_n(self, target, *, goc: bool = False, **o):
        el = self.san_sang(target, **o)
        el.evaluate("e => e.click()" if goc else "e => __bo600rt.clickEl(e)")
        self._touch()
        return el

    def dien_n(self, target, value: str, **o):
        el = self.san_sang(target, **o)
        el.evaluate("(e, v) => __bo600rt.setValue(e, v)", value)
        self._touch()
        return el

    # ---------- thông báo (toast) của trang ----------
    def toast_mark(self) -> int:
        """Mốc để đọc các thông báo xuất hiện SAU thời điểm này (toasts_since)."""
        try:
            return int(self.page.evaluate("(window.__bo600toast ? window.__bo600toast.list.length : 0)"))
        except PWError:
            return 0

    def toasts_since(self, mark: int) -> list:
        try:
            return list(self.page.evaluate("(m) => (window.__bo600toast ? window.__bo600toast.list.slice(m) : [])", mark))
        except PWError:
            return []

    def cho_toast(self, rx, mark: int, toi_da: float = 15) -> Optional[str]:
        """Chờ thông báo khớp biểu thức `rx` xuất hiện sau `mark`. Trả nội dung, hoặc None nếu quá hạn (không ném lỗi)."""
        import re
        re_ = re.compile(rx) if isinstance(rx, str) else rx
        t0 = time.monotonic()
        while True:
            for t in self.toasts_since(mark):
                if re_.search(t):
                    return t
            if time.monotonic() - t0 > toi_da:
                return None
            self.sleep(200)

    def cho_het_toast(self, mark: int, yen_ms: int = 2000, toi_da: float = 30) -> list:
        """Chờ đến khi không còn thông báo mới trong `yen_ms` (tối đa `toi_da` giây). Trả mọi thông báo từ `mark`."""
        t0 = quiet = time.monotonic()
        n = len(self.toasts_since(mark))
        while time.monotonic() - t0 < toi_da and (time.monotonic() - quiet) * 1000 < yen_ms:
            self.sleep(300)
            m = len(self.toasts_since(mark))
            if m != n:
                n, quiet = m, time.monotonic()
        return self.toasts_since(mark)

    def tu_oke(self, on: bool) -> None:
        """Bật/tắt việc tự bấm "OKE, ĐỂ TÔI TÍCH!" ở hộp nhắc của TIC (chỉ nên bật khi máy đang chạy)."""
        try:
            self.page.evaluate("(v) => { window.__bo600oke = v; }", bool(on))
        except PWError:
            pass

    # ---------- đọc ----------
    def exists(self, target) -> bool:
        el = _tgt(target).resolve(self.page)
        return el is not None

    def text(self, target) -> str:
        el = _tgt(target).resolve(self.page)
        return (el.inner_text() if el else "").strip()

    # ---------- file ----------
    def tai_ve(self, action: Callable[[], None], dest: str | Path, timeout_ms: int = 60000) -> Path:
        """Chạy `action` (bấm nút tải) và lưu file trình duyệt tải về vào `dest`."""
        with self.page.expect_download(timeout=timeout_ms) as dl:
            action()
        d = dl.value
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        d.save_as(str(dest))
        self.sleep(0)
        return dest

    def tai_ve_cho(self, action: Callable[[], None], dest_stem: str | Path, toi_da: float = 60, duoi_mac_dinh: str = ".xlsx") -> Path:
        """Như tai_ve nhưng chờ bằng sleep() của tab (bấm Dừng thoát ngay, vẫn bơm sự kiện mạng) - dùng khi máy chủ tạo file lâu.
        Đuôi file lấy theo tên trình duyệt gợi ý; quá `toi_da` giây thì ném GateTimeout."""
        got: list = []
        def cb(d):                                             # hàm thường: Playwright gắn thuộc tính lên callback, list.append thì không được
            got.append(d)
        self.page.on("download", cb)
        try:
            action()
            t0 = time.monotonic()
            while not got:
                if time.monotonic() - t0 > toi_da:
                    raise GateTimeout(f"[HT] Đã bấm tải file nhưng sau {round(toi_da)} giây chưa nhận được file - dừng lượt")
                self.sleep(200)
        finally:
            self.page.remove_listener("download", cb)
        d = got[0]
        if callable(dest_stem):                                # dest_stem(tên gốc do trang gợi ý) -> (đường dẫn không đuôi, đuôi)
            stem, duoi = dest_stem(d.suggested_filename or "")
            dest = Path(str(stem) + (duoi or duoi_mac_dinh))
        else:
            duoi = Path(d.suggested_filename or "").suffix.lower() or duoi_mac_dinh
            dest = Path(str(dest_stem) + duoi)
        dest.parent.mkdir(parents=True, exist_ok=True)
        d.save_as(str(dest))
        return dest

    def tai_len(self, target, path: str | Path, **o) -> None:
        el = self.cho_on_dinh(target, an=True, **o)
        el.set_input_files(str(path))
        self._touch()
