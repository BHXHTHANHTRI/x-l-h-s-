"""Ba cổng của thủ tục 600 (theo manifest của extension)."""
PORTALS = {
    "tst": ("tst.bhxh.gov.vn", "https://tst.bhxh.gov.vn/"),
    "tnhs": ("tnhs.bhxh.gov.vn", "https://tnhs.bhxh.gov.vn/"),
    "hgd": ("hgd.bhxh.gov.vn", "https://hgd.bhxh.gov.vn/"),
}
