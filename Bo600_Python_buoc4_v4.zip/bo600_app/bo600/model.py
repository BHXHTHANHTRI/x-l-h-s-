"""A1 - Mô hình hồ sơ và trạng thái từng bước (port từ core.js).

Lô (lot) = một ngày tải: {"id": "2026-10-23", "status": "open", "items": [item, ...]}
Hồ sơ (item) là dict, các trường chính:
  id, sohoso, madonvi, kykekhai, file (đường dẫn tương đối trong thư mục lô), rows,
  ktn{status,note,donVi{khoi}}, f2{status}, the{status}, tc{status},
  q{kind: 'import'|'tuchoi', lyDo, deNghi}, imp{kq: 'xong'|'loi'|'chua_ro'}, duyet{kq, at},
  nguoiLam{ktn|f2|the: ...}, reopenTs, atTs/ktnTs/f2Ts/theTs, rk, rkx
"""
from __future__ import annotations

import random
import re
import string
import time

KTN_OK = "Đạt - lưu được"
KTN_RED = "Không đạt - có lỗi đỏ"
KTN_ERR = "Lỗi chạy"
KTN_DUP = "Đã lưu trước đó (sổ cái)"

BO_PHAN_THU = "112"        # mã bộ phận trên TNHS
BO_PHAN_CAP_SO_THE = "109"


def new_id(tag: str = "") -> str:
    ms = int(time.time() * 1000)
    rnd = "".join(random.choices(string.ascii_lowercase + string.digits, k=5))
    return f"{ms}-{tag}-{rnd}" if tag else f"{ms}-{rnd}"


def nguoi_lam(it: dict, k: str):
    return (it.get("nguoiLam") or {}).get(k)


def ktn_xong(it: dict) -> bool:
    st = (it.get("ktn") or {}).get("status", "")
    return bool(re.match(r"^(Đạt|Không đạt|Đã lưu)", st or "")) or bool(nguoi_lam(it, "ktn"))


def f2_xong(it: dict) -> bool:
    # Lô cũ: tra cứu F2 và thẻ chạy chung, chỉ có it.tc
    return (bool(it.get("f2") and it["f2"].get("status") == "Xong")
            or bool(not it.get("f2") and it.get("tc") and it["tc"].get("status") == "Xong")
            or bool(nguoi_lam(it, "f2")))


def the_xong(it: dict) -> bool:
    return (bool(it.get("the") and it["the"].get("status") == "Xong")
            or bool(not it.get("the") and it.get("tc") and it["tc"].get("status") == "Xong")
            or bool(nguoi_lam(it, "the")))


def lot_open(lot: dict) -> bool:
    return lot.get("status") != "closed"
