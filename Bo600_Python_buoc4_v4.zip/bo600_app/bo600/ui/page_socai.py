"""Trang Sổ cái: trạng thái sao lưu/khôi phục, danh sách lượt ghi, nhật ký các lần chạy."""
from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import ttkbootstrap as tb

from .common import make_tree, open_path

COLS = [("at", "Lúc", 150, "w"), ("he", "Hệ", 60, "w"), ("viec", "Việc", 190, "w"), ("so", "Số hồ sơ", 140, "w"),
        ("kq", "Kết quả", 260, "w"), ("ai", "Ai làm", 80, "w"), ("dv", "Mã ĐV", 100, "w")]


class SoCaiPage:
    def __init__(self, parent, app):
        self.app = app
        self.frame = f = ttk.Frame(parent)
        f.columnconfigure(0, weight=1)
        f.rowconfigure(3, weight=2)
        f.rowconfigure(5, weight=1)
        ttk.Label(f, text="Sổ cái", font=("", 14, "bold")).grid(row=0, column=0, sticky="w")
        self.banner = tk.StringVar()
        self.lbl_banner = ttk.Label(f, textvariable=self.banner, wraplength=1000, justify="left")
        self.lbl_banner.grid(row=1, column=0, sticky="w", pady=(0, 6))
        bar = ttk.Frame(f)
        bar.grid(row=2, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(bar, text="Lọc số hồ sơ:").pack(side="left")
        self.flt = tk.StringVar()
        e = ttk.Entry(bar, textvariable=self.flt, width=22)
        e.pack(side="left", padx=6)
        e.bind("<KeyRelease>", lambda ev: self.refresh())
        tb.Button(bar, text="Khôi phục từ file…", bootstyle="warning", command=self._restore).pack(side="right", padx=4)
        tb.Button(bar, text="Xuất bảng (TSV)", bootstyle="secondary-outline", command=self._tsv).pack(side="right", padx=4)
        tb.Button(bar, text="Sao lưu ngay", bootstyle="secondary-outline", command=self._backup).pack(side="right", padx=4)
        tf, self.tree = make_tree(f, COLS, height=10)
        tf.grid(row=3, column=0, sticky="nsew")
        hdr = ttk.Frame(f)
        hdr.grid(row=4, column=0, sticky="ew", pady=(10, 2))
        ttk.Label(hdr, text="Nhật ký các lần chạy (bấm đúp để mở)", font=("", 10, "bold")).pack(side="left")
        tb.Button(hdr, text="Mở thư mục dữ liệu", bootstyle="link", command=app.open_data_dir).pack(side="right")
        self.lb = tk.Listbox(f, height=5, activestyle="none")
        self.lb.grid(row=5, column=0, sticky="nsew")
        self.lb.bind("<Double-1>", self._open_log)
        self._logs: list = []

    def refresh(self) -> None:
        s = self.app.socai
        s.refresh()
        m, st = s.meta(), s.state
        bk = self.app.store.kv_get("socaiBackup") or {}
        text = f'Sổ cái {m["id"]} · {s.idx["count"]} lượt ghi · sao lưu gần nhất: {bk.get("at", "chưa có")}'
        if st["locked"]:
            text = ("CHƯA KHÔI PHỤC: còn sổ cái cũ " + ", ".join(f"socai_{x}.json" for x in st["old"])
                    + " trong thư mục _socai. Không import thật cho đến khi khôi phục.\n") + text
            self.lbl_banner.configure(foreground="#c0392b")
        else:
            self.lbl_banner.configure(foreground="#1e7e34")
        self.banner.set(text)
        self.tree.delete(*self.tree.get_children())
        q = self.flt.get().strip()
        for e in reversed(s.idx["list"][-3000:]):
            so = ", ".join(e.get("sohosos") or [])
            if q and q not in so:
                continue
            tag = "ok" if e.get("ok") else "err"
            self.tree.insert("", "end", tags=(tag,), values=(
                e.get("at"), e.get("he") or "TST", e.get("viec") or "Lưu import", so,
                e.get("ketqua") or ("Thành công" if e.get("ok") else "Không thành công"),
                "Máy" if e.get("who") == "may" else "Người", e.get("madv") or ""))
        self._logs = sorted(self.app.paths.nhatky.glob("*.txt"), reverse=True)[:50]
        self.lb.delete(0, "end")
        for p in self._logs:
            self.lb.insert("end", p.name)

    def _restore(self) -> None:
        f = filedialog.askopenfilename(title="File sổ cái socai_*.json", initialdir=str(self.app.paths.socai), filetypes=[("Sổ cái", "*.json")])
        if not f:
            return
        try:
            r = self.app.socai.restore_file(f)
        except Exception as e:                                   # noqa: BLE001
            messagebox.showerror("Bộ 600", f"Không khôi phục được:\n{e}")
            return
        self.app.log(f"Đã khôi phục sổ cái: thêm {r['added']} lượt, tổng {r['count']}.", "ok")
        self.app.refresh_all()

    def _backup(self) -> None:
        r = self.app.socai.write_backup()
        self.app.log(f"Đã sao lưu sổ cái: {r['count']} lượt -> {r['filename']}", "ok")
        self.refresh()

    def _tsv(self) -> None:
        f = filedialog.asksaveasfilename(defaultextension=".tsv", initialfile="socai.tsv", filetypes=[("TSV", "*.tsv")])
        if f:
            with open(f, "w", encoding="utf-8", newline="") as fh:
                fh.write(self.app.socai.tsv())
            open_path(f)

    def _open_log(self, _e) -> None:
        s = self.lb.curselection()
        if s:
            open_path(self._logs[s[0]])
