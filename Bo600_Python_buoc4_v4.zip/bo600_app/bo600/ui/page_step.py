"""Trang một bước (1-6, 8, 9): danh sách hồ sơ + trạng thái bước, chạy/chạy lại, "người đã làm", và phần riêng từng bước."""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import ttkbootstrap as tb

from .. import duyet_actions as A
from ..d02_io import codes_of_cq
from ..steps.donvi import dam_bao_xlsx
from ..steps.tiepnhan import tom_tat
from ..runner import BUOC
from ..tranthe import TranThe, TranTheError, tran_dem
from .common import make_tree, open_path
from .status import step_status

MO_TA = {
    "dv": "Lấy danh sách mã đơn vị thuộc chuyên quản của bạn từ file Danh mục đơn vị xuất từ TST.",
    "tn": "Tiếp nhận hồ sơ trên TNHS (điều khiển tiện ích TIC). Có thể làm tay rồi ghi nhận “Người đã làm bước này”.",
    "tai": "Lọc hồ sơ thủ tục 600 điện tử trên TNHS và tải file D02 mẫu TST về thư mục ngày.",
    "ktn": "Nạp D02 vào màn import TST ở chế độ nháp và đọc lỗi từng dòng. Không bấm Lưu.",
    "f2": "Tra cứu F2 (chỉ đọc) để lấy mã số BHXH / CCCD đề xuất.",
    "the": "Tra cứu thẻ BHYT và tràn thẻ cơ sở KCB Hà Nội (chỉ đọc).",
    "imp": "Import thật lên TST theo hàng chờ. Chỉ chạy hồ sơ đã gửi từ bước 7; mỗi hồ sơ một lần theo sổ cái.",
    "tnhs": "XỬ LÝ trên TNHS: hợp lệ / không hợp lệ, phiếu truy thu, cấp sổ-thẻ.",
}
COLS = [("hs", "Số hồ sơ", 150, "w"), ("dv", "Mã ĐV", 110, "w"), ("st", "Trạng thái", 260, "w"), ("gc", "Ghi chú", 360, "w")]


class StepPage:
    def __init__(self, parent, app, key: str):
        self.app, self.key = app, key
        so, ten = BUOC[key]
        self.frame = f = ttk.Frame(parent)
        f.columnconfigure(0, weight=1)
        f.rowconfigure(3, weight=1)
        ttk.Label(f, text=f"{so}. {ten}", font=("", 14, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Label(f, text=MO_TA.get(key, ""), foreground="#6c757d", wraplength=900, justify="left").grid(row=1, column=0, sticky="w", pady=(0, 6))
        self.extra = ttk.Frame(f)
        self.extra.grid(row=2, column=0, sticky="ew")
        self.lookup: dict = {}
        if key not in ("dv", "tn"):
            tf, self.tree = make_tree(f, COLS, height=12)
            tf.grid(row=3, column=0, sticky="nsew", pady=(4, 0))
            self.tree.bind("<Double-1>", lambda e: self._open_folder())
        else:
            self.tree = None
        bar = ttk.Frame(f)
        bar.grid(row=4, column=0, sticky="ew", pady=(8, 0))
        self._buttons(bar)
        getattr(self, f"_extra_{key}", lambda: None)()

    # ---------- nút ----------
    def _buttons(self, bar) -> None:
        app, key = self.app, self.key
        tb.Button(bar, text="▶ Chạy bước này", bootstyle="primary", command=self._run).pack(side="left", padx=(0, 4))
        self.btn_pause = tb.Button(bar, text="Ⅱ Tạm dừng", bootstyle="warning", command=app.toggle_pause, state="disabled")
        self.btn_pause.pack(side="left", padx=4)
        self.btn_stop = tb.Button(bar, text="■ Dừng", bootstyle="danger-outline", command=app.runner.stop, state="disabled")
        self.btn_stop.pack(side="left", padx=4)
        if self.tree is None:
            return
        tb.Button(bar, text="↻ Chạy lại bước này", bootstyle="warning-outline", command=self._rerun).pack(side="left", padx=4)
        if key not in ("imp",):
            tb.Button(bar, text="Người đã làm bước này", bootstyle="secondary-outline", command=lambda: self._nguoi_lam(True)).pack(side="left", padx=4)
            tb.Button(bar, text="Bỏ ghi nhận", bootstyle="link", command=lambda: self._nguoi_lam(False)).pack(side="left")
        if key == "tai":
            tb.Button(bar, text="Nạp D02 thủ công…", bootstyle="secondary-outline", command=app.nap_d02_dialog).pack(side="right")
        if key == "imp":
            tb.Button(bar, text="Rút khỏi hàng chờ", bootstyle="secondary-outline", command=self._rut).pack(side="left", padx=4)
            tb.Button(bar, text="Đã Lưu (đã xem trên TST)", bootstyle="success-outline", command=self._da_luu).pack(side="left", padx=4)
            tb.Button(bar, text="Chưa Lưu - đưa lại hàng chờ", bootstyle="warning-outline", command=self._lai_hang_cho).pack(side="left", padx=4)

    def _sel(self) -> list:
        return [self.lookup[i] for i in (self.tree.selection() if self.tree else ()) if i in self.lookup]

    def _run(self) -> None:
        if self.key == "dv" and not self._dv_luu_form():
            return
        sel = self._sel() or None
        self.app.run_step(self.key, sel)

    def _rerun(self) -> None:
        sel = self._sel()
        if not sel:
            messagebox.showinfo("Bộ 600", "Chọn hồ sơ cần chạy lại.")
            return
        for lot, it in sel:
            A.xoa_ket_qua_buoc(self.app.store, lot["id"], it["id"], self.key)
        self.app.log(f"Xóa kết quả bước {BUOC[self.key][0]} của {len(sel)} hồ sơ để chạy lại (sổ cái giữ nguyên).")
        self.app.run_step(self.key, [self.app.store.find_item(l["id"], i["id"]) for l, i in sel])
        self.refresh()

    def _nguoi_lam(self, on: bool) -> None:
        sel = self._sel()
        if not sel:
            messagebox.showinfo("Bộ 600", "Chọn hồ sơ trước.")
            return
        for lot, it in sel:
            A.danh_dau_nguoi_lam(self.app.store, lot["id"], it["id"], self.key, on)
        self.app.refresh_all()

    def _open_folder(self) -> None:
        sel = self._sel()
        if sel:
            open_path(self.app.paths.lot_dir(sel[0][0]["id"]))

    # ---------- hàng chờ import ----------
    def _rut(self) -> None:
        for lot, it in self._sel():
            A.rut_hang_cho(self.app.store, lot, it)
        self.app.refresh_all()

    def _da_luu(self) -> None:
        sel = self._sel()
        if sel and messagebox.askyesno("Bộ 600", f"Ghi nhận {len(sel)} hồ sơ ĐÃ Lưu trên TST (người xác nhận)? Hồ sơ sẽ không bị import lại."):
            for lot, it in sel:
                A.nguoi_import_thu_cong(self.app.store, self.app.socai, lot, it, da_xu_ly_tnhs=False)
            self.app.refresh_all()

    def _lai_hang_cho(self) -> None:
        for lot, it in self._sel():
            def mark(i2, _l):
                i2["imp"] = None
                i2["q"] = {"kind": "import", "ts": 0, "at": "", "src": "Đưa lại hàng chờ"}
            self.app.store.edit_item(lot["id"], it["id"], mark)
        self.app.refresh_all()

    # ---------- phần riêng từng bước ----------
    def _extra_dv(self) -> None:
        e = self.extra
        st = self.app.cfg.settings()
        self.dv_file = tk.StringVar()
        self.dv_cq = tk.StringVar(value=st.get("cq", ""))
        self.dv_tu_xuat = tk.BooleanVar(value=bool(st.get("dv_tu_xuat")))
        self.dv_msg = tk.StringVar(value="Chưa chọn file.")
        self.dv_tic = tk.StringVar()
        r = ttk.Frame(e); r.pack(fill="x", pady=4)
        ttk.Label(r, text="File danh mục đơn vị:").pack(side="left")
        ttk.Entry(r, textvariable=self.dv_file, width=60).pack(side="left", padx=6)
        tb.Button(r, text="Chọn…", bootstyle="secondary-outline", command=self._dv_chon).pack(side="left")
        r2 = ttk.Frame(e); r2.pack(fill="x", pady=4)
        ttk.Label(r2, text="Chuyên quản:").pack(side="left")
        ttk.Entry(r2, textvariable=self.dv_cq, width=34).pack(side="left", padx=6)
        tb.Button(r2, text="Đọc mã đơn vị", bootstyle="primary", command=self._dv_doc).pack(side="left")
        ttk.Checkbutton(e, text="Tự tải file Danh sách đơn vị từ TST (bỏ qua file đã chọn ở trên)", variable=self.dv_tu_xuat).pack(anchor="w", pady=2)
        ttk.Label(e, textvariable=self.dv_msg, foreground="#495057").pack(anchor="w", pady=(4, 0))
        self.dv_tic_lbl = ttk.Label(e, textvariable=self.dv_tic, foreground="#495057", wraplength=1000, justify="left")
        self.dv_tic_lbl.pack(anchor="w", pady=(2, 4))
        self._dv_hien()

    def _dv_hien(self) -> None:
        """Hiện file/chuyên quản đã lưu và kết quả lần nạp TIC gần nhất."""
        saved = self.app.store.kv_get("donvi")
        if not saved:
            return
        if saved.get("file"):
            self.dv_file.set(saved["file"])
        if saved.get("codes") is not None:
            self.dv_msg.set(f'Đã đọc {len(saved["codes"])} mã đơn vị của "{saved.get("cq", "")}" ({saved.get("at", "")}).')
        tic = saved.get("tic")
        if not tic:
            self.dv_tic.set("TIC: chưa nạp (bấm “▶ Chạy bước này” để nạp vào TIC trên TNHS).")
            return
        t = f'TIC (lần nạp {tic.get("at", "")}, chuyên quản "{tic.get("cq", "")}"): đang giữ {tic.get("n_giu", 0)} mã. {tic.get("lay_ma", "")}'
        if tic.get("thua"):
            t += f'\nMã thừa {len(tic["thua"])} (TIC giữ, không thuộc chuyên quản trong file; không tự xóa): ' + ", ".join(tic["thua"][:15]) + (" ..." if len(tic["thua"]) > 15 else "")
        if tic.get("thieu"):
            t += f'\nCẢNH BÁO - thiếu {len(tic["thieu"])} mã có trong file mà TIC chưa giữ: ' + ", ".join(tic["thieu"][:15]) + (" ..." if len(tic["thieu"]) > 15 else "")
        self.dv_tic.set(t)
        self.dv_tic_lbl.configure(foreground="#c0392b" if tic.get("thieu") else "#495057")

    def _dv_luu_form(self) -> bool:
        """Lưu lựa chọn trên form (file, chuyên quản, tự tải) để handler đọc. False nếu thiếu thông tin."""
        cq = self.dv_cq.get().strip()
        if not self.dv_tu_xuat.get():
            f = self.dv_file.get().strip()
            if not f:
                if messagebox.askyesno("Bộ 600", "Chưa chọn file danh mục đơn vị.\nĐể máy tự tải file từ TST?"):
                    self.dv_tu_xuat.set(True)
                else:
                    return False
            elif not Path(f).is_file():
                messagebox.showerror("Bộ 600", f"Không thấy file:\n{f}")
                return False
        saved = self.app.store.kv_get("donvi") or {}
        if self.dv_file.get().strip() != saved.get("file", ""):
            saved.pop("codes", None)                            # file đổi: mã cũ không còn đúng
        saved.update(file=self.dv_file.get().strip(), cq=cq)
        self.app.store.kv_set("donvi", saved)
        self.app.cfg.save_settings({"cq": cq, "dv_tu_xuat": bool(self.dv_tu_xuat.get())})
        return True

    def _dv_chon(self) -> None:
        f = filedialog.askopenfilename(title="Danh mục đơn vị (xuất từ TST)", filetypes=[("Excel", "*.xlsx *.xlsm *.xls")])
        if f:
            self.dv_file.set(f)

    def _dv_doc(self) -> None:
        from ..util import now_vn
        try:
            codes = sorted(codes_of_cq(dam_bao_xlsx(self.dv_file.get()), self.dv_cq.get().strip()))
        except Exception as e:                                   # noqa: BLE001
            messagebox.showerror("Bộ 600", f"Không đọc được file:\n{e}")
            return
        if not codes:
            self.dv_msg.set("Không tìm thấy mã đơn vị nào của chuyên quản này - kiểm tra tên chuyên quản.")
            return
        saved = self.app.store.kv_get("donvi") or {}
        saved.update(file=self.dv_file.get(), cq=self.dv_cq.get().strip(), codes=codes, at=now_vn())
        self.app.store.kv_set("donvi", saved)
        self.app.cfg.save_settings({"cq": self.dv_cq.get().strip()})
        self.dv_msg.set(f'Đã đọc {len(codes)} mã đơn vị của "{self.dv_cq.get().strip()}". Ví dụ: {", ".join(codes[:6])}')
        self.app.log(f"Bước 1: {len(codes)} mã đơn vị của {self.dv_cq.get().strip()}.")

    def _extra_tn(self) -> None:
        self.tn_msg = tk.StringVar()
        self.tn_hoso = tk.StringVar()
        box = ttk.LabelFrame(self.extra, text="Kết quả lần chạy gần nhất", padding=8)
        box.pack(fill="x", pady=(0, 4))
        self.tn_lbl = ttk.Label(box, textvariable=self.tn_msg, wraplength=1000, justify="left")
        self.tn_lbl.pack(anchor="w")
        ttk.Label(box, textvariable=self.tn_hoso, foreground="#6c757d", wraplength=1000, justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Label(self.extra, foreground="#6c757d", wraplength=1000, justify="left",
                  text="Cần: Chrome điều khiển được đã đăng nhập TNHS, đã cài TIC và đã chạy bước 1 (TIC giữ danh sách đơn vị quản lý). "
                       "Máy tự đổi về Bộ phận Quản lý thu nếu tab đang ở Cấp sổ-thẻ. Trong lúc chạy KHÔNG thao tác trên tab TNHS. "
                       "Không có TIC: tiếp nhận tay rồi chạy tiếp các bước sau; trong “Chạy cả chuỗi” bước này tự được bỏ qua.").pack(anchor="w", pady=(2, 4))
        self._tn_hien()

    def _tn_hien(self) -> None:
        kq = self.app.store.kv_get("tiepnhan")
        self.tn_msg.set(tom_tat(kq))
        self.tn_lbl.configure(foreground="#c0392b" if kq and not kq.get("ok") else "#212529")
        hs = (kq or {}).get("hoso") or []
        self.tn_hoso.set(("Số hồ sơ đã tiếp nhận: " + ", ".join(hs[:12]) + (f" ... (+{len(hs) - 12})" if len(hs) > 12 else "")) if hs else "")

    def _extra_the(self) -> None:
        self.tran = TranThe(self.app.store)
        self.tran_lbl = tk.StringVar()
        box = ttk.LabelFrame(self.extra, text="Danh mục tràn thẻ (cơ sở KCB Hà Nội)", padding=8)
        box.pack(fill="x", pady=(0, 4))
        self.tran_msg = ttk.Label(box, textvariable=self.tran_lbl, wraplength=900, justify="left")
        self.tran_msg.pack(side="left", fill="x", expand=True)
        tb.Button(box, text="Xuất danh mục", bootstyle="secondary-outline", command=self._tran_xuat).pack(side="right", padx=4)
        tb.Button(box, text="Nạp danh mục mới…", bootstyle="primary", command=self._tran_nap).pack(side="right", padx=4)

    def _tran_nap(self) -> None:
        f = filedialog.askopenfilename(title="File danh mục tràn thẻ", filetypes=[("Excel", "*.xlsx")])
        if not f:
            return
        try:
            p = self.tran.preview(f)
        except TranTheError as e:
            messagebox.showerror("Bộ 600 - file không được nhận", str(e))
            return
        if messagebox.askyesno("Nạp danh mục tràn thẻ", p["tom_tat"] + ("\n" + p["so_sanh"] if p["so_sanh"] else "") + "\n\nThay TOÀN BỘ danh mục đang dùng?"):
            self.tran.apply(f, p["rows"])
            self.app.log("Đã nạp danh mục tràn thẻ: " + p["tom_tat"])
            self.refresh()

    def _tran_xuat(self) -> None:
        try:
            open_path(self.tran.export())
        except TranTheError as e:
            messagebox.showinfo("Bộ 600", str(e))

    # ---------- làm mới ----------
    def _hien(self, it: dict) -> bool:
        k, q = self.key, it.get("q") or {}
        if k == "imp":
            return q.get("kind") == "import" or (it.get("imp") or {}).get("kq") in ("loi", "chua_ro", "xong")
        if k == "tnhs":
            return q.get("kind") == "tuchoi" or bool(self.app.socai.hit(it)) or bool(self.app.socai.tnhs_events(it.get("sohoso")))
        return True

    def refresh(self) -> None:
        if self.key == "the":
            d = self.tran.load()
            if d:
                c = tran_dem(d["rows"])
                self.tran_lbl.set(f'Đang dùng: {d["file"]} ({d["at"]}) - {c["n"]} cơ sở; tràn thẻ {c["tran"]}, chưa tràn {c["khong"]}, chưa có số phân bổ {c["chua"]}.')
            else:
                self.tran_lbl.set("CHƯA có danh mục tràn thẻ: cột BV_D02_tran sẽ ghi “chưa có dữ liệu”. Nạp file danh mục để dùng.")
        if self.key == "dv":
            self._dv_hien()
        if self.key == "tn":
            self._tn_hien()
        if self.tree is None:
            return
        self.tree.delete(*self.tree.get_children())
        self.lookup = {}
        for lot, it in self.app.store.all_items():
            if not self._hien(it) or (self.key != "tai" and not it.get("file")):
                continue
            iid = f'{lot["id"]}|{it["id"]}'
            self.lookup[iid] = (lot, it)
            st, tag = step_status(self.key, it, self.app.socai)
            note = ""
            if self.key == "ktn":
                note = (it.get("ktn") or {}).get("note", "")
            elif self.key == "imp":
                note = (it.get("q") or {}).get("src", "") or (it.get("imp") or {}).get("nguon", "")
            self.tree.insert("", "end", iid=iid, tags=(tag,), values=(it.get("sohoso"), it.get("madonvi"), st, note))
