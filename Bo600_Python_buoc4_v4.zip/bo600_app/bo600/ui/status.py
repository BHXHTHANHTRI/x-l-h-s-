"""Hàm thuần dữ liệu: trạng thái từng bước của một hồ sơ để hiển thị (không đụng widget, test được)."""
from __future__ import annotations

from ..model import f2_xong, ktn_xong, nguoi_lam, the_xong

OK, WARN, ERR, NONE = "ok", "warn", "err", "none"


def tai_status(it: dict):
    return ("Đã tải", OK) if it.get("file") else ("-", NONE)


def ktn_status(it: dict):
    k = it.get("ktn") or {}
    st = k.get("status", "")
    if nguoi_lam(it, "ktn") and not st:
        return "Người đã làm", OK
    if st.startswith("Đạt"):
        return "Đạt", OK
    if st.startswith("Không đạt"):
        return "Có lỗi đỏ", WARN
    if st.startswith("Đã lưu"):
        return "Đã Lưu (sổ cái)", WARN
    if st:
        return st, ERR
    return "-", NONE


def _tra_cuu(it: dict, key: str, done: bool):
    if (it.get(key) or {}).get("status") == "Xong" or (key == "f2" and not it.get("f2") and (it.get("tc") or {}).get("status") == "Xong") \
            or (key == "the" and not it.get("the") and (it.get("tc") or {}).get("status") == "Xong"):
        return "Xong", OK
    if nguoi_lam(it, key):
        return "Người đã làm", OK
    st = (it.get(key) or {}).get("status")
    return (st, ERR) if st else ("-", NONE)


def f2_status(it: dict):
    return _tra_cuu(it, "f2", f2_xong(it))


def the_status(it: dict):
    return _tra_cuu(it, "the", the_xong(it))


def duyet_status(it: dict, nhom_ten: str = ""):
    d = it.get("duyet") or {}
    if d.get("kq"):
        return d["kq"], (WARN if d["kq"].startswith("Từ chối") else OK)
    return (nhom_ten, NONE) if nhom_ten else ("Chưa duyệt", NONE)


def imp_status(it: dict, socai):
    imp, q = it.get("imp") or {}, it.get("q") or {}
    if imp.get("kq") == "loi":
        return "Lỗi sau import", ERR
    if imp.get("kq") == "chua_ro":
        return "Chưa rõ - cần xem TST", ERR
    hit = socai.hit(it) if socai else None
    if hit:
        return ("Đã Lưu (người xác nhận)" if hit[-1].get("nguon") == "xacnhan" else "Đã Lưu"), OK
    if imp.get("kq") == "xong":
        return "Đã import", OK
    if q.get("kind") == "import":
        return "Trong hàng chờ", WARN
    return "-", NONE


def tnhs_status(it: dict, socai):
    ev = [e for e in (socai.tnhs_events(it.get("sohoso")) if socai else []) if e.get("loai") == "xuly" and e.get("ok", True)]
    cut = it.get("reopenTs") or 0
    ev = [e for e in ev if (e.get("ts") or 0) >= cut]
    if ev:
        return "; ".join(f'{e.get("bophan")}: {e.get("ketqua") or "xong"}' for e in ev), OK
    if (it.get("q") or {}).get("kind") == "tuchoi":
        return "Chờ xử lý (từ chối)", WARN
    return "-", NONE


def worst(*tags: str) -> str:
    for t in (ERR, WARN):
        if t in tags:
            return t
    return OK if OK in tags else NONE


def step_status(key: str, it: dict, socai, nhom_ten: str = ""):
    if key == "tai":
        return tai_status(it)
    if key == "ktn":
        return ktn_status(it)
    if key == "f2":
        return f2_status(it)
    if key == "the":
        return the_status(it)
    if key == "duyet":
        return duyet_status(it, nhom_ten)
    if key == "imp":
        return imp_status(it, socai)
    if key == "tnhs":
        return tnhs_status(it, socai)
    return "-", NONE


def badge_counts(items: list, socai) -> dict:
    """Số hồ sơ còn việc ở từng bước (hiện cạnh tên ở thanh bên)."""
    n = dict(tai=0, ktn=0, f2=0, the=0, duyet=0, imp=0, tnhs=0)
    for _lot, it in items:
        if not it.get("file"):
            continue
        n["ktn"] += not ktn_xong(it)
        n["f2"] += not f2_xong(it)
        n["the"] += not the_xong(it)
        q = it.get("q") or {}
        n["duyet"] += not q and not (it.get("imp") or {}).get("kq") == "xong" and not (socai and socai.hit(it))
        n["imp"] += q.get("kind") == "import" and not (socai and socai.hit(it))
        n["tnhs"] += (q.get("kind") == "tuchoi" or bool(socai and socai.hit(it))) and tnhs_status(it, socai)[1] != OK
    return n
