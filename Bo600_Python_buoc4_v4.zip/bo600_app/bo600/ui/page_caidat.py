"""Trang Cài đặt: cài đặt chung + quy tắc tiền kiểm (nhóm đích, mẫu lý do/đề nghị)."""
from __future__ import annotations

import copy
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import ttkbootstrap as tb

from ..config import NHOM_TEN, QT_TEN, QUY_TAC_MAC_DINH, SETTINGS_MAC_DINH
from .common import make_tree

NHOM_CHON = {"tuchoi": "Đề xuất từ chối", "nguoi": "Cần người xem", "dinhdanh": "Tra cứu định danh"}


class CaiDatPage:
    def __init__(self, parent, app):
        self.app = app
        self.frame = f = ttk.Frame(parent)
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        top = ttk.Frame(f)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(top, text="Cài đặt", font=("", 14, "bold")).pack(side="left")
        tb.Button(top, text="Lưu", bootstyle="primary", command=self._save).pack(side="right", padx=4)
        tb.Button(top, text="Khôi phục mặc định", bootstyle="secondary-outline", command=self._default).pack(side="right", padx=4)
        nb = ttk.Notebook(f)
        nb.grid(row=1, column=0, sticky="nsew")
        self.v: dict = {}
        self._chung(nb)
        self._quy_tac(nb)
        self._trinh_duyet(nb)
        self.rules = copy.deepcopy(QUY_TAC_MAC_DINH)

    # ---------- chung ----------
    def _chung(self, nb) -> None:
        g = ttk.Frame(nb, padding=12)
        nb.add(g, text="Chung")
        r = 0

        def row(label, key, width=10, hint=""):
            nonlocal r
            ttk.Label(g, text=label).grid(row=r, column=0, sticky="w", pady=3)
            self.v[key] = tk.StringVar()
            ttk.Entry(g, textvariable=self.v[key], width=width).grid(row=r, column=1, sticky="w", padx=8)
            if hint:
                ttk.Label(g, text=hint, foreground="#6c757d").grid(row=r, column=2, sticky="w")
            r += 1

        ttk.Label(g, text="Chuyên quản (tên như trong Danh mục đơn vị)").grid(row=r, column=0, sticky="w", pady=3)
        self.v["cq"] = tk.StringVar()
        ttk.Entry(g, textvariable=self.v["cq"], width=32).grid(row=r, column=1, columnspan=2, sticky="w", padx=8); r += 1
        row("Nghỉ giữa các thao tác (ms)", "delay_ms", hint="tối thiểu 500")
        row("Số hồ sơ tối đa mỗi lô XỬ LÝ", "lo_xu_ly_toi_da")
        row("Giữ hồ sơ đã xong (ngày)", "giu_ho_so_xong_ngay")
        row("Từ chối: chờ trước khi chuyển sang TNHS (giây)", "tu_choi_cho_giay")
        row("Chờ người ghi nhận trên TNHS (giây)", "tnhs_cho_nguoi_giay")
        row("BV lưu ngay (ngày)", "bv_luu_ngay", hint="cache tra cứu thẻ")
        row("Lý do “Không hợp lệ” mặc định", "tnhs_ly_do_khong_hop_le", width=48)
        ttk.Label(g, text="Cổng ổn định (ms / giây)").grid(row=r, column=0, sticky="w", pady=3)
        fr = ttk.Frame(g); fr.grid(row=r, column=1, columnspan=2, sticky="w", padx=8)
        for k, lab in (("langMs", "lặng"), ("nhipMin", "nghỉ min"), ("nhipMax", "nghỉ max"), ("toiDaGiay", "tối đa (s)")):
            self.v["od_" + k] = tk.StringVar()
            ttk.Label(fr, text=lab).pack(side="left"); ttk.Entry(fr, textvariable=self.v["od_" + k], width=6).pack(side="left", padx=(2, 10))
        r += 1
        self.v["m_duyet"], self.v["m_import"], self.v["m_tnhs"], self.v["tnhs_tu_dong"] = (tk.BooleanVar() for _ in range(4))
        box = ttk.LabelFrame(g, text="Module", padding=8); box.grid(row=r, column=0, columnspan=3, sticky="ew", pady=8)
        tb.Checkbutton(box, text="7. Duyệt", variable=self.v["m_duyet"], bootstyle="round-toggle").pack(side="left", padx=8)
        tb.Checkbutton(box, text="8. Import TST (cần bật cùng Duyệt)", variable=self.v["m_import"], bootstyle="round-toggle").pack(side="left", padx=8)
        tb.Checkbutton(box, text="9. Xử lý TNHS", variable=self.v["m_tnhs"], bootstyle="round-toggle").pack(side="left", padx=8)
        r += 1
        tb.Checkbutton(g, text="TNHS tự bấm GHI NHẬN (tắt = máy điền sẵn rồi dừng chờ người bấm - khuyên dùng)", variable=self.v["tnhs_tu_dong"], bootstyle="round-toggle").grid(row=r, column=0, columnspan=3, sticky="w"); r += 1
        ttk.Label(g, text="Mẫu phiếu truy thu ({THANG_BAO_TANG}, {TU_THANG_GOC} được điền tự động)").grid(row=r, column=0, columnspan=3, sticky="w", pady=(8, 2)); r += 1
        self.t_truythu = tk.Text(g, height=5, width=90, wrap="word"); self.t_truythu.grid(row=r, column=0, columnspan=3, sticky="w")
        r += 1
        ttk.Label(g, text="Thư mục lưu dữ liệu Bộ 600").grid(row=r, column=0, sticky="w", pady=(10, 0))
        self.v["data_dir"] = tk.StringVar(value=str(self.app.paths.base))
        ttk.Entry(g, textvariable=self.v["data_dir"], width=62).grid(row=r, column=1, sticky="ew", padx=8, pady=(10, 0))
        tb.Button(g, text="Chọn thư mục…", bootstyle="secondary-outline", command=self._chon_thu_muc).grid(row=r, column=2, sticky="w", pady=(10, 0))
        r += 1
        ttk.Label(g, text="Khi đổi vị trí, dữ liệu hiện tại sẽ được sao chép sang thư mục mới. Đóng và mở lại ứng dụng để áp dụng.",
                  foreground="#6c757d", wraplength=900).grid(row=r, column=0, columnspan=3, sticky="w", pady=(3, 0))

    def _chon_thu_muc(self) -> None:
        selected = filedialog.askdirectory(title="Chọn thư mục lưu dữ liệu Bộ 600",
                                           initialdir=self.v["data_dir"].get() or str(self.app.paths.base),
                                           mustexist=False)
        if selected:
            self.v["data_dir"].set(selected)

    # ---------- trình duyệt ----------
    def _trinh_duyet(self, nb) -> None:
        g = ttk.Frame(nb, padding=12)
        nb.add(g, text="Trình duyệt")
        self.v["chrome_port"], self.v["chrome_path"] = tk.StringVar(), tk.StringVar()
        ttk.Label(g, text="Bộ 600 điều khiển một cửa sổ Chrome riêng (hồ sơ riêng), không đụng Chrome thường ngày của bạn.\n"
                          "Mở bằng nút dưới, đăng nhập TST/TNHS (và cài tiện ích TIC nếu dùng bước 2) một lần trong cửa sổ đó.",
                  justify="left", wraplength=900).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 10))
        ttk.Label(g, text="Cổng gỡ lỗi").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Entry(g, textvariable=self.v["chrome_port"], width=8).grid(row=1, column=1, sticky="w", padx=8)
        ttk.Label(g, text="Đường dẫn Chrome").grid(row=2, column=0, sticky="w", pady=3)
        ttk.Entry(g, textvariable=self.v["chrome_path"], width=60).grid(row=2, column=1, sticky="w", padx=8)
        ttk.Label(g, text="để trống = tự tìm chrome.exe / msedge.exe", foreground="#6c757d").grid(row=2, column=2, sticky="w")
        row = ttk.Frame(g); row.grid(row=3, column=0, columnspan=3, sticky="w", pady=12)
        tb.Button(row, text="Mở Chrome điều khiển được", bootstyle="primary", command=self.app.mo_chrome).pack(side="left", padx=(0, 6))
        tb.Button(row, text="Kiểm tra kết nối", bootstyle="secondary-outline", command=self.app.kiem_tra_chrome).pack(side="left")
        ttk.Label(g, text=f"Hồ sơ Chrome riêng: {self.app.paths.base / '_chrome_profile'}", foreground="#6c757d").grid(row=4, column=0, columnspan=3, sticky="w")

    # ---------- quy tắc ----------
    def _quy_tac(self, nb) -> None:
        g = ttk.Frame(nb, padding=12)
        nb.add(g, text="Quy tắc tiền kiểm")
        g.columnconfigure(1, weight=1)
        top = ttk.Frame(g); top.grid(row=0, column=0, columnspan=2, sticky="ew")
        for i, (lab, key, w) in enumerate((("ML tối thiểu", "mlToiThieu", 12), ("TYLE chuẩn", "tyleChuan", 6),
                                           ("MACV chung chung (phẩy)", "macvTuChoi", 44), ("PA báo tăng (phẩy)", "paTang", 18))):
            ttk.Label(top, text=lab).grid(row=0, column=i * 2, padx=(0 if i == 0 else 12, 4))
            self.v["r_" + key] = tk.StringVar()
            ttk.Entry(top, textvariable=self.v["r_" + key], width=w).grid(row=0, column=i * 2 + 1)
        tf, self.rt = make_tree(g, [("ten", "Quy tắc", 330, "w"), ("nhom", "Nhóm khi gặp", 160, "w")], height=12, selectmode="browse")
        tf.grid(row=1, column=0, sticky="nsew", pady=10)
        g.rowconfigure(1, weight=1)
        self.rt.bind("<<TreeviewSelect>>", self._chon_qt)
        ed = ttk.LabelFrame(g, text="Quy tắc đang chọn", padding=8); ed.grid(row=1, column=1, sticky="nsew", padx=(10, 0), pady=10)
        ttk.Label(ed, text="Nhóm").grid(row=0, column=0, sticky="w")
        self.v["qt_nhom"] = tk.StringVar()
        self.cb_nhom = ttk.Combobox(ed, textvariable=self.v["qt_nhom"], values=list(NHOM_CHON.values()), state="readonly", width=24)
        self.cb_nhom.grid(row=0, column=1, sticky="w", padx=6)
        self.cb_nhom.bind("<<ComboboxSelected>>", self._doi_nhom)
        ttk.Label(ed, text="Lý do soạn sẵn").grid(row=1, column=0, sticky="nw", pady=(8, 0))
        self.t_lydo = tk.Text(ed, height=4, width=60, wrap="word"); self.t_lydo.grid(row=1, column=1, sticky="w", pady=(8, 0))
        ttk.Label(ed, text="Đề nghị soạn sẵn").grid(row=2, column=0, sticky="nw", pady=(8, 0))
        self.t_denghi = tk.Text(ed, height=4, width=60, wrap="word"); self.t_denghi.grid(row=2, column=1, sticky="w", pady=(8, 0))
        self.qt_cur = None
        for t in (self.t_lydo, self.t_denghi):
            t.bind("<FocusOut>", lambda e: self._luu_mau())

    def _chon_qt(self, _e=None) -> None:
        self._luu_mau()
        s = self.rt.selection()
        if not s:
            return
        k = self.qt_cur = s[0]
        self.v["qt_nhom"].set(NHOM_CHON.get(self.rules["nhom"].get(k), NHOM_TEN.get(self.rules["nhom"].get(k), "")))
        mau = self.rules["mau"].get(k)
        for t, f in ((self.t_lydo, "lyDo"), (self.t_denghi, "deNghi")):
            t.configure(state="normal" if mau else "disabled")
            t.delete("1.0", "end")
            t.insert("1.0", (mau or {}).get(f, "") if mau else "(quy tắc này không có mẫu)")

    def _luu_mau(self) -> None:
        k = self.qt_cur
        if k and self.rules["mau"].get(k) is not None and str(self.t_lydo.cget("state")) == "normal":
            self.rules["mau"][k]["lyDo"] = self.t_lydo.get("1.0", "end").strip()
            self.rules["mau"][k]["deNghi"] = self.t_denghi.get("1.0", "end").strip()

    def _doi_nhom(self, _e=None) -> None:
        if self.qt_cur:
            inv = {v: k for k, v in NHOM_CHON.items()}
            self.rules["nhom"][self.qt_cur] = inv[self.v["qt_nhom"].get()]
            self._fill_rt()

    def _fill_rt(self) -> None:
        sel = self.qt_cur
        self.rt.delete(*self.rt.get_children())
        for k, ten in QT_TEN.items():
            self.rt.insert("", "end", iid=k, values=(ten, NHOM_CHON.get(self.rules["nhom"].get(k, "nguoi"), "")))
        if sel and self.rt.exists(sel):
            self.rt.selection_set(sel)

    # ---------- nạp / lưu ----------
    def refresh(self) -> None:
        s, v = self.app.cfg.settings(), self.v
        for k in ("cq", "delay_ms", "lo_xu_ly_toi_da", "giu_ho_so_xong_ngay", "tu_choi_cho_giay", "tnhs_cho_nguoi_giay",
                  "bv_luu_ngay", "tnhs_ly_do_khong_hop_le"):
            v[k].set(s[k])
        for k, val in s["on_dinh"].items():
            v["od_" + k].set(val)
        v["m_duyet"].set(s["modules"]["duyet"]); v["m_import"].set(s["modules"]["import"]); v["m_tnhs"].set(s["modules"]["tnhs"])
        v["tnhs_tu_dong"].set(s["tnhs_tu_dong"])
        v["chrome_port"].set(s["chrome_port"]); v["chrome_path"].set(s["chrome_path"])
        v["data_dir"].set(str(self.app.paths.base))
        self.t_truythu.delete("1.0", "end"); self.t_truythu.insert("1.0", s["mau_phieu_truy_thu"])
        self.rules = self.app.cfg.rules()
        v["r_mlToiThieu"].set(self.rules["mlToiThieu"]); v["r_tyleChuan"].set(self.rules["tyleChuan"])
        v["r_macvTuChoi"].set(", ".join(self.rules["macvTuChoi"])); v["r_paTang"].set(", ".join(self.rules["paTang"]))
        self._fill_rt()

    def _default(self) -> None:
        if messagebox.askyesno("Bộ 600", "Đưa toàn bộ cài đặt và quy tắc về mặc định?"):
            self.app.cfg.save_settings(copy.deepcopy(SETTINGS_MAC_DINH))
            self.app.cfg.save_rules({})
            self.refresh()

    def _save(self) -> None:
        self._luu_mau()
        v = self.v
        try:
            ints = {k: int(str(v[k].get()).strip()) for k in ("delay_ms", "lo_xu_ly_toi_da", "giu_ho_so_xong_ngay",
                                                              "tu_choi_cho_giay", "tnhs_cho_nguoi_giay", "bv_luu_ngay")}
            port = int(str(v["chrome_port"].get()).strip())
            od = {k: int(str(v["od_" + k].get()).strip()) for k in ("langMs", "nhipMin", "nhipMax", "toiDaGiay")}
            ml, ty = float(str(v["r_mlToiThieu"].get()).replace(",", ".")), float(str(v["r_tyleChuan"].get()).replace(",", "."))
        except ValueError:
            messagebox.showerror("Bộ 600", "Các ô số phải là số nguyên (ML, TYLE có thể là số thập phân).")
            return
        if od["nhipMin"] > od["nhipMax"]:
            messagebox.showerror("Bộ 600", "Nghỉ min không được lớn hơn nghỉ max.")
            return
        self.app.cfg.save_settings({
            **ints, "chrome_port": port, "chrome_path": v["chrome_path"].get().strip(), "cq": v["cq"].get().strip(), "on_dinh": od, "tnhs_ly_do_khong_hop_le": v["tnhs_ly_do_khong_hop_le"].get().strip(),
            "modules": {"duyet": v["m_duyet"].get(), "import": v["m_import"].get(), "tnhs": v["m_tnhs"].get()},
            "tnhs_tu_dong": v["tnhs_tu_dong"].get(), "mau_phieu_truy_thu": self.t_truythu.get("1.0", "end").strip()})
        r = self.rules
        r["mlToiThieu"] = int(ml) if ml == int(ml) else ml
        r["tyleChuan"] = int(ty) if ty == int(ty) else ty
        r["macvTuChoi"] = [x.strip() for x in v["r_macvTuChoi"].get().split(",") if x.strip()]
        r["paTang"] = [x.strip().upper() for x in v["r_paTang"].get().split(",") if x.strip()]
        self.app.cfg.save_rules(r)
        chosen_dir = self.v["data_dir"].get().strip()
        if not chosen_dir:
            messagebox.showerror("Bộ 600", "Hãy chọn thư mục lưu dữ liệu Bộ 600.")
            return
        try:
            self.app.change_data_dir(chosen_dir)
        except Exception as e:
            messagebox.showerror("Bộ 600", f"Không đổi được thư mục dữ liệu:\n{e}")
            return
        self.app.log("Đã lưu cài đặt và quy tắc. Hồ sơ ở màn Duyệt sẽ tính lại đề xuất (giữ ô người đã sửa).", "ok")
        self.app.refresh_all()
