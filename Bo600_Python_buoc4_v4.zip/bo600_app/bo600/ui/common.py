"""Tiện ích widget dùng chung."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from tkinter import ttk

TAG_BG = {"ok": "#e6f4ea", "warn": "#fff4d6", "err": "#fde7e9", "none": ""}


def open_path(p) -> None:
    p = str(p)
    if sys.platform.startswith("win"):
        os.startfile(p)                                    # noqa: S606 - mở bằng chương trình mặc định (Excel, Explorer)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", p])
    else:
        subprocess.Popen(["xdg-open", p])


def make_tree(parent, columns, height=12, selectmode="extended"):
    """columns: [(id, tiêu đề, rộng, căn)]. Trả về (khung, tree) có thanh cuộn dọc + ngang."""
    f = ttk.Frame(parent)
    t = ttk.Treeview(f, columns=[c[0] for c in columns], show="headings", height=height, selectmode=selectmode)
    for cid, title, w, anchor in columns:
        t.heading(cid, text=title)
        t.column(cid, width=w, anchor=anchor, stretch=False)
    vs = ttk.Scrollbar(f, orient="vertical", command=t.yview)
    hs = ttk.Scrollbar(f, orient="horizontal", command=t.xview)
    t.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
    t.grid(row=0, column=0, sticky="nsew")
    vs.grid(row=0, column=1, sticky="ns")
    hs.grid(row=1, column=0, sticky="ew")
    f.rowconfigure(0, weight=1)
    f.columnconfigure(0, weight=1)
    for tag, bg in TAG_BG.items():
        if bg:
            t.tag_configure(tag, background=bg)
    return f, t


def item_label(it: dict) -> str:
    return f'{it.get("sohoso", "?")} ({it.get("madonvi", "")})'


def selected_items(tree, lookup: dict) -> list:
    """Các (lot, item) đang chọn trong tree; iid của dòng = id hồ sơ, lookup: id -> (lot, it)."""
    return [lookup[i] for i in tree.selection() if i in lookup]


def vn_int(v) -> str:
    try:
        return f"{int(v):,}".replace(",", ".")
    except (TypeError, ValueError):
        return str(v)
