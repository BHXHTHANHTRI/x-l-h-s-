"""Giao diện Tkinter/ttkbootstrap của Bộ 600 (tầng D)."""
