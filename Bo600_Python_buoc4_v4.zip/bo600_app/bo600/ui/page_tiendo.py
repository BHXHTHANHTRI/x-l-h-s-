"""Trang Tiến độ: mỗi hồ sơ một dòng, trạng thái từng bước, chạy cả chuỗi."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

import ttkbootstrap as tb

from ..duyet_actions import load_dx
from ..rules import tab_of
from ..config import NHOM_TEN
from .common import make_tree
from .status import step_status, worst

COLS = [("hs", "Số hồ sơ", 130, "w"), ("dv", "Mã ĐV", 110, "w"), ("ky", "Kỳ", 70, "w"), ("n", "Dòng", 50, "e"),
        ("tai", "3 Tải", 70, "w"), ("ktn", "4 Kiểm tra nháp", 115, "w"), ("f2", "5 F2", 90, "w"), ("the", "6 Thẻ", 90, "w"),
        ("duyet", "7 Duyệt", 215, "w"), ("imp", "8 Import", 130, "w"), ("tnhs", "9 TNHS", 150, "w")]


class TienDoPage:
    def __init__(self, parent, app):
        self.app = app
        self.frame = f = ttk.Frame(parent)
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        bar = ttk.Frame(f)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(bar, text="Tiến độ", font=("", 14, "bold")).pack(side="left")
        ttk.Label(bar, text="  Lô:").pack(side="left")
        self.lot_var = tk.StringVar(value="Tất cả")
        self.cb = ttk.Combobox(bar, textvariable=self.lot_var, state="readonly", width=14, values=["Tất cả"])
        self.cb.pack(side="left")
        self.cb.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        tb.Button(bar, text="▶ Chạy cả chuỗi (2→9)", bootstyle="primary", command=lambda: app.run_chain("tn")).pack(side="right", padx=4)
        tb.Button(bar, text="Nạp D02 thủ công…", bootstyle="primary-outline", command=app.nap_d02_dialog).pack(side="right", padx=4)
        tb.Button(bar, text="Làm mới", bootstyle="link", command=self.refresh).pack(side="right")
        tf, self.tree = make_tree(f, COLS, height=16)
        tf.grid(row=1, column=0, sticky="nsew")
        self.info = ttk.Label(f, text="", foreground="#6c757d")
        self.info.grid(row=2, column=0, sticky="w", pady=(6, 0))

    def refresh(self) -> None:
        app = self.app
        lots = sorted(app.store.get_lots())
        self.cb.configure(values=["Tất cả", *lots])
        sel = self.lot_var.get()
        self.tree.delete(*self.tree.get_children())
        n = 0
        rules = app.cfg.rules()
        for lot, it in app.store.all_items():
            if sel not in ("Tất cả", lot["id"]):
                continue
            nhom = ""
            if it.get("file") and not it.get("q"):
                try:
                    dx = load_dx(app.store, app.socai, rules, lot, it)
                    nhom = NHOM_TEN.get(tab_of(it, dx), "")
                except Exception:                              # noqa: BLE001 - thiếu file D02: để trống nhóm
                    nhom = "(không đọc được D02)"
            st = {k: step_status(k, it, app.socai, nhom if k == "duyet" else "") for k in ("tai", "ktn", "f2", "the", "duyet", "imp", "tnhs")}
            w = worst(*[st[k][1] for k in ("ktn", "f2", "the", "duyet", "imp", "tnhs")])
            tag = w if w in ("err", "warn") else ("ok" if st["imp"][1] == "ok" and st["tnhs"][1] == "ok" else "none")
            self.tree.insert("", "end", iid=f'{lot["id"]}|{it["id"]}', tags=(tag,),
                             values=(it.get("sohoso"), it.get("madonvi"), it.get("kykekhai", ""), it.get("rows", ""),
                                     *[st[k][0] for k in ("tai", "ktn", "f2", "the", "duyet", "imp", "tnhs")]))
            n += 1
        self.info.configure(text=f"{n} hồ sơ" + ("" if n else " - chưa có hồ sơ. Bấm “Nạp D02 thủ công…” để thử màn Duyệt khi chưa có bước Tải D02 tự động."))
