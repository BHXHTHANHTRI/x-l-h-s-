"""Cửa sổ chính: thanh bên các bước, vùng trang, nhật ký, thanh trạng thái, nút Dừng."""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import ttkbootstrap as tb

from .. import VERSION
from ..config import Config, Paths
import threading
import shutil

from ..browser import BrowserSession, launch_chrome
from ..browser.portals import PORTALS
from ..duyet_actions import doan_so_ho_so, nap_d02_thu_cong
from ..d02_io import read_d02
from ..runner import BUOC, CHUOI_MAC_DINH, Runner
from ..socai import Socai
from ..steps import register_all
from ..store import Store
from ..sukien import SuKien
from .common import open_path
from .status import badge_counts

NAV = [("dv", "1. Đơn vị quản lý"), ("tn", "2. Tiếp nhận"), ("tai", "3. Tải D02"), ("ktn", "4. Kiểm tra nháp"),
       ("f2", "5. Tra cứu F2"), ("the", "6. Tra cứu thẻ"), ("duyet", "7. Duyệt"), ("imp", "8. Import TST"),
       ("tnhs", "9. Xử lý TNHS"), (None, None), ("tiendo", "Tiến độ"), ("socai", "Sổ cái"), ("cai", "Cài đặt")]


class App:
    def __init__(self, data_dir=None, theme: str = "flatly", headless: bool = False):
        self.paths = Paths(data_dir).ensure()
        self.store = Store(self.paths)
        self.socai = Socai(self.store)
        self.sk = SuKien(self.store)
        self.cfg = Config(self.paths)
        self.runner = Runner(self.store, self.socai, self.cfg)
        register_all(self.runner)
        self.root = tb.Window(title=f"Bộ 600 - bản Python {VERSION}", themename=theme, size=(1360, 840))
        self.root.minsize(1100, 680)
        self.pages: dict = {}
        self.cur = None
        self.nav_btns: dict = {}
        self.nav_var = tk.StringVar()
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.show("tiendo")
        self.log(f"Thư mục dữ liệu: {self.paths.base}")
        if self.socai.state["locked"]:
            self.log("CẢNH BÁO: sổ cái chưa khôi phục - mở trang Sổ cái để khôi phục trước khi import thật.", "err")
        self._poll_id = self.root.after(120, self._poll)

    # ---------- dựng khung ----------
    def _build(self) -> None:
        from .page_caidat import CaiDatPage
        from .page_duyet import DuyetPage
        from .page_socai import SoCaiPage
        from .page_step import StepPage
        from .page_tiendo import TienDoPage

        root = self.root
        root.columnconfigure(1, weight=1)
        root.rowconfigure(0, weight=1)
        st = ttk.Style()
        c = self.root.style.colors
        st.configure("Nav.TButton", anchor="w", padding=(12, 7), background=c.bg, foreground=c.fg, borderwidth=0, relief="flat")
        st.map("Nav.TButton", background=[("active", c.light)], foreground=[("active", c.fg)])
        st.configure("NavSel.TButton", anchor="w", padding=(12, 7), background=c.primary, foreground="#ffffff", borderwidth=0, relief="flat")
        st.map("NavSel.TButton", background=[("active", c.primary)], foreground=[("active", "#ffffff")])
        side = ttk.Frame(root, padding=(10, 10))
        side.grid(row=0, column=0, sticky="ns")
        ttk.Label(side, text="BỘ 600", font=("", 16, "bold")).pack(anchor="w")
        ttk.Label(side, text=f"Thủ tục 600 · v{VERSION}", foreground="#6c757d").pack(anchor="w", pady=(0, 10))
        for key, text in NAV:
            if key is None:
                ttk.Separator(side).pack(fill="x", pady=8)
                continue
            b = ttk.Button(side, text=text, style="Nav.TButton", width=24, command=lambda k=key: self.show(k))
            b.pack(fill="x", pady=1)
            self.nav_btns[key] = (b, text)

        main = ttk.Frame(root)
        main.grid(row=0, column=1, sticky="nsew", padx=(0, 10), pady=10)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=1)
        area = ttk.Frame(main)
        area.grid(row=0, column=0, sticky="nsew")
        area.columnconfigure(0, weight=1)
        area.rowconfigure(0, weight=1)
        self.area = area

        # nhật ký + thanh trạng thái
        bottom = ttk.Frame(root)
        bottom.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 8))
        bottom.columnconfigure(0, weight=1)
        self.log_text = tk.Text(bottom, height=6, wrap="word", state="disabled", font=("Consolas", 9), relief="flat",
                                background="#f8f9fa")
        self.log_text.grid(row=0, column=0, sticky="ew")
        sb = ttk.Scrollbar(bottom, command=self.log_text.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=sb.set)
        self.log_text.tag_configure("err", foreground="#c0392b")
        self.log_text.tag_configure("ok", foreground="#1e7e34")
        bar = ttk.Frame(bottom)
        bar.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        bar.columnconfigure(0, weight=1)
        self.status_var = tk.StringVar(value="Sẵn sàng")
        ttk.Label(bar, textvariable=self.status_var).grid(row=0, column=0, sticky="w")
        self.btn_pause = tb.Button(bar, text="Ⅱ Tạm dừng", bootstyle="warning", command=self.toggle_pause, state="disabled")
        self.btn_pause.grid(row=0, column=1, sticky="e", padx=(0, 6))
        self.btn_stop = tb.Button(bar, text="■ Dừng", bootstyle="danger", command=self.runner.stop, state="disabled")
        self.btn_stop.grid(row=0, column=2, sticky="e")

        for key, _ in NAV:
            if key is None:
                continue
        classes = {"tiendo": TienDoPage, "duyet": DuyetPage, "socai": SoCaiPage, "cai": CaiDatPage}
        for key, _t in NAV:
            if key is None:
                continue
            page = classes[key](area, self) if key in classes else StepPage(area, self, key)
            page.frame.grid(row=0, column=0, sticky="nsew")
            self.pages[key] = page

    # ---------- điều hướng ----------
    def show(self, key: str) -> None:
        self.cur = key
        for k, (b, _t) in self.nav_btns.items():
            b.configure(style="NavSel.TButton" if k == key else "Nav.TButton")
        self.pages[key].frame.tkraise()
        self.pages[key].refresh()
        self._badges()

    def refresh_all(self) -> None:
        if self.cur:
            self.pages[self.cur].refresh()
        self._badges()

    def _badges(self) -> None:
        n = badge_counts(self.store.all_items(), self.socai)
        for key, (b, text) in self.nav_btns.items():
            c = n.get(key)
            tat = key in ("imp", "tnhs") and not self.cfg.module_on(key)
            b.configure(text=f"{text}  ({c})" if c else text + ("  (tắt)" if tat else ""))

    # ---------- nhật ký / chạy bước ----------
    def log(self, msg: str, tag: str = "") -> None:
        t = self.log_text
        t.configure(state="normal")
        if not tag:
            tag = "err" if ("LỖI" in msg or "CẢNH BÁO" in msg) else ("ok" if msg.startswith(("XONG", "[")) and "XONG" in msg else "")
        t.insert("end", msg + "\n", tag or ())
        t.see("end")
        t.configure(state="disabled")

    def toggle_pause(self) -> None:
        if not self.runner.busy:
            return
        self.runner.toggle_pause()
        label = "▶ Tiếp tục" if self.runner.paused else "Ⅱ Tạm dừng"
        try:
            self.btn_pause.configure(text=label)
            for page in self.pages.values():
                if hasattr(page, "btn_pause"):
                    page.btn_pause.configure(text=label)
        except Exception:
            pass

    def run_step(self, key: str, items=None) -> None:
        if not self.runner.run(key, items):
            messagebox.showinfo("Bộ 600", "Đang có bước khác chạy - bấm Dừng hoặc đợi xong.")

    def run_chain(self, start: str = "tn") -> None:
        keys = CHUOI_MAC_DINH[CHUOI_MAC_DINH.index(start):] if start in CHUOI_MAC_DINH else CHUOI_MAC_DINH
        keys = [k for k in keys if k not in ("imp", "tnhs") or self.cfg.module_on(k)]
        if not self.runner.run(keys):
            messagebox.showinfo("Bộ 600", "Đang có bước khác chạy - bấm Dừng hoặc đợi xong.")

    def _poll(self) -> None:
        try:
            while True:
                kind, *rest = self.runner.q.get_nowait()
                if kind == "log":
                    self.log(rest[0])
                elif kind == "status":
                    self.status_var.set(rest[0])
                elif kind == "busy":
                    state = "normal" if rest[0] else "disabled"
                    self.btn_stop.configure(state=state)
                    self.btn_pause.configure(state=state, text="Ⅱ Tạm dừng")
                    for page in self.pages.values():
                        if hasattr(page, "btn_stop"):
                            page.btn_stop.configure(state=state)
                            page.btn_pause.configure(state=state, text="Ⅱ Tạm dừng")
                elif kind == "done":
                    self.socai.refresh()
                    self.sk.refresh()
                    self.refresh_all()
        except Exception:                                      # queue.Empty và lỗi hiển thị không được làm sập vòng lặp
            pass
        self._poll_id = self.root.after(120, self._poll)

    # ---------- nạp D02 thủ công ----------
    def nap_d02_dialog(self) -> None:
        files = filedialog.askopenfilenames(title="Chọn file D02 (.xlsx)", filetypes=[("Excel", "*.xlsx *.xlsm")])
        for f in files:
            self._nap_mot_file(Path(f))

    def _nap_mot_file(self, path: Path) -> None:
        try:
            guess = doan_so_ho_so(read_d02(path))
        except Exception as e:                                 # noqa: BLE001
            messagebox.showerror("Bộ 600", f"Không đọc được {path.name}:\n{e}")
            return
        d = tb.Toplevel(self.root)
        d.title("Nạp D02 thủ công")
        d.transient(self.root)
        d.grab_set()
        ttk.Label(d, text=path.name, font=("", 10, "bold")).grid(row=0, column=0, columnspan=2, padx=12, pady=(12, 6), sticky="w")
        vars_ = {}
        for i, (lab, val) in enumerate([("Số hồ sơ", guess), ("Mã đơn vị", path.stem.split("_")[0].upper()), ("Kỳ kê khai", "")], 1):
            ttk.Label(d, text=lab).grid(row=i, column=0, padx=12, pady=3, sticky="w")
            v = tk.StringVar(value=val)
            ttk.Entry(d, textvariable=v, width=34).grid(row=i, column=1, padx=12, pady=3)
            vars_[lab] = v

        def ok():
            try:
                it = nap_d02_thu_cong(self.store, path, vars_["Số hồ sơ"].get(), vars_["Mã đơn vị"].get(), vars_["Kỳ kê khai"].get())
            except Exception as e:                             # noqa: BLE001
                messagebox.showerror("Bộ 600", str(e), parent=d)
                return
            self.log(f"Đã nạp D02 thủ công: {it['sohoso']} ({it['madonvi']}), {it['rows']} dòng.")
            d.destroy()
            self.refresh_all()

        row = ttk.Frame(d)
        row.grid(row=4, column=0, columnspan=2, pady=12)
        tb.Button(row, text="Nạp", bootstyle="primary", command=ok).pack(side="left", padx=4)
        tb.Button(row, text="Hủy", bootstyle="secondary", command=d.destroy).pack(side="left", padx=4)
        d.wait_window()

    # ---------- trình duyệt ----------
    def _thread(self, fn) -> None:
        """Việc có thể chậm (mở Chrome, nối CDP) chạy nền; kết quả báo về khung nhật ký qua hàng đợi."""
        def run():
            try:
                fn()
            except Exception as e:                             # noqa: BLE001
                self.runner.q.put(("log", f"LỖI {e}"))
        threading.Thread(target=run, daemon=True).start()

    def mo_chrome(self) -> None:
        s = self.cfg.settings()

        def work():
            p = launch_chrome(self.paths.base / "_chrome_profile", int(s["chrome_port"]),
                              urls=[PORTALS["tst"][1], PORTALS["tnhs"][1]], chrome_path=s["chrome_path"] or None)
            self.runner.q.put(("log", "Đã mở Chrome điều khiển được. Đăng nhập TST/TNHS (và cài tiện ích TIC nếu dùng bước 2) "
                                      "trong cửa sổ đó - chỉ cần làm một lần." if p else
                                      f"Chrome đã mở sẵn cổng gỡ lỗi {s['chrome_port']}."))
        self.log("Đang mở Chrome điều khiển được...")
        self._thread(work)

    def kiem_tra_chrome(self) -> None:
        port = int(self.cfg.settings()["chrome_port"])

        def work():
            with BrowserSession(port) as br:
                info = br.info()
                self.runner.q.put(("log", f'XONG nối Chrome {info["version"]}: {len(info["tabs"])} tab'))
                for role, (host, _u) in PORTALS.items():
                    ok = br.find_page(host) is not None
                    self.runner.q.put(("log", f'    {role.upper()} ({host}): ' + ("đã mở" if ok else "CHƯA mở/đăng nhập")))
        self._thread(work)

    # ---------- đóng ----------
    def on_close(self) -> None:
        if self.runner.busy and not messagebox.askyesno("Bộ 600", "Đang chạy một bước. Dừng và thoát?"):
            return
        self.runner.stop()
        try:
            self.root.after_cancel(self._poll_id)
        except Exception:                                      # noqa: BLE001
            pass
        try:
            self.socai.flush()
            self.store.close()
        finally:
            self.root.destroy()

    def change_data_dir(self, target: str) -> None:
        """Lưu vị trí dữ liệu mới và sao chép dữ liệu hiện tại; cần khởi động lại."""
        from pathlib import Path
        target_path = Path(target).expanduser().resolve()
        current = self.paths.base.resolve()
        if target_path == current:
            return
        if target_path in current.parents or current in target_path.parents:
            raise RuntimeError("Hãy chọn thư mục độc lập, không nằm bên trong hoặc bao quanh thư mục dữ liệu hiện tại.")
        if self.runner.busy:
            raise RuntimeError("Không thể đổi thư mục khi đang chạy một bước. Hãy dừng bước hiện tại trước.")
        target_path.mkdir(parents=True, exist_ok=True)
        # Sao chép các thư mục/tệp dữ liệu hiện tại, không ghi đè tệp đã có ở đích.
        for item in current.iterdir():
            dest = target_path / item.name
            if item.is_dir():
                if dest.exists():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                else:
                    shutil.copytree(item, dest)
            elif not dest.exists():
                shutil.copy2(item, dest)
        Paths.save_default_base(target_path)
        self.log(f"Đã lưu vị trí dữ liệu mới: {target_path}. Hãy đóng và mở lại Bộ 600 để áp dụng.", "ok")

    def open_data_dir(self) -> None:
        open_path(self.paths.base)

    def mainloop(self) -> None:
        self.root.mainloop()
