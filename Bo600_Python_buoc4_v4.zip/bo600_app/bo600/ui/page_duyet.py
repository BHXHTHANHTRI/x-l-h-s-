"""Trang 7. Duyệt: 6 tab nhóm, danh sách hồ sơ bên trái, bảng dòng bên phải (sửa ô, tích duyệt), gửi hàng chờ / từ chối / truy thu."""
from __future__ import annotations

import tkinter as tk
from collections import Counter
from tkinter import filedialog, messagebox, ttk

import ttkbootstrap as tb

from .. import duyet_actions as A
from ..config import COT_KHOA, NHOM_TAB, NHOM_TEN
from ..model import f2_xong, ktn_xong, the_xong
from ..rules import da_tick, issues_all, tab_of
from .common import make_tree, open_path

# (id cột, tiêu đề, rộng, căn, tên cột D02 hoặc None)
COLS = [("tick", "Duyệt", 50, "center", None), ("stt", "STT", 42, "e", "STT"), ("hoten", "Họ tên", 150, "w", "HOTEN"),
        ("sobhxh", "Mã BHXH", 95, "w", "SOBHXH"), ("socmnd", "CCCD/CMND", 105, "w", "SOCMND"),
        ("ngaysinh", "Ngày sinh", 80, "w", "NGAYSINH"), ("macv", "MACV", 110, "w", "MACV"), ("ma_tinh", "Tỉnh", 40, "w", "MA_TINH"),
        ("ma_bv", "BV", 50, "w", "MA_BV"), ("pa", "PA", 38, "w", "PA"), ("ml", "ML", 82, "e", "ML"), ("tyle", "TYLE", 45, "e", "TYLE"),
        ("tuthang", "TUTHANG", 72, "w", "TUTHANG"), ("tinhlai", "Lãi", 38, "w", "TINHLAI"),
        ("vd", "Vấn đề", 230, "w", None), ("tt", "Thay đổi", 170, "w", None)]
LEFT = [("hs", "Số hồ sơ", 105, "w"), ("dv", "Mã ĐV", 75, "w"), ("td", "Tích", 42, "center"), ("vd", "Vấn đề", 110, "w")]
NGUON = {"tay": "người", "tc": "tra cứu", "co": "máy"}


def _changes(r: dict) -> list:
    out = []
    for c, v in r["chot"].items():
        if str(v) != str("" if r["goc"].get(c) is None else r["goc"][c]):
            nguon = "tay" if r["tay"].get(c) else r["dx"].get(c, "co")
            out.append((c, NGUON.get(nguon, nguon)))
    return out


class DuyetPage:
    def __init__(self, parent, app):
        self.app = app
        self.frame = f = ttk.Frame(parent)
        f.columnconfigure(0, weight=1)
        f.rowconfigure(2, weight=1)
        self.tab = "tuchoi"
        self.entries: list = []
        self.cur = None
        self._busy_nb = False
        self._err_seen: set = set()
        head = ttk.Frame(f)
        head.grid(row=0, column=0, sticky="ew")
        ttk.Label(head, text="7. Duyệt", font=("", 14, "bold")).pack(side="left")
        ttk.Label(head, text="  Sửa ô → tích “Duyệt” từng dòng → Gửi vào hàng chờ. Máy không tự import hồ sơ chưa tích đủ dòng.",
                  foreground="#6c757d").pack(side="left")
        self.nb = ttk.Notebook(f)
        for k in NHOM_TAB:
            self.nb.add(ttk.Frame(self.nb), text=NHOM_TEN[k])
        self.nb.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        self.nb.bind("<<NotebookTabChanged>>", self._tab_changed)
        pw = ttk.Panedwindow(f, orient="horizontal")
        pw.grid(row=2, column=0, sticky="nsew", pady=(4, 0))
        self.pw = pw
        # --- trái ---
        left = ttk.Frame(pw)
        left.columnconfigure(0, weight=1); left.rowconfigure(0, weight=1)
        lf, self.lst = make_tree(left, LEFT, height=14, selectmode="browse")
        lf.grid(row=0, column=0, sticky="nsew")
        self.lst.bind("<<TreeviewSelect>>", self._pick)
        self.btn_gui_tab = tb.Button(left, text="Gửi các hồ sơ đã tích đủ của tab này", bootstyle="primary", command=self._gui_tab)
        self.btn_gui_tab.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        pw.add(left, weight=1)
        # --- phải ---
        right = ttk.Frame(pw)
        right.columnconfigure(0, weight=1); right.rowconfigure(3, weight=1)
        self.lbl_hs = ttk.Label(right, text="", font=("", 11, "bold")); self.lbl_hs.grid(row=0, column=0, sticky="w")
        self.lbl_state = ttk.Label(right, text="", wraplength=900, justify="left"); self.lbl_state.grid(row=1, column=0, sticky="w")
        tools = ttk.Frame(right); tools.grid(row=2, column=0, sticky="ew", pady=4)
        self.btn = {}
        spec = [("tick_all", "Tích cả hồ sơ", "success-outline", lambda: self._tick(None, True)),
                ("untick", "Bỏ tích", "secondary-outline", lambda: self._tick(None, False)),
                ("recalc", "Tính lại", "secondary-outline", self._recalc),
                ("reset", "Làm lại từ gốc", "secondary-outline", self._reset),
                ("open_xl", "Mở Excel để sửa", "info-outline", self._open_xl),
                ("nap", "Nạp file đã sửa…", "info-outline", self._nap),
                ("thoi", "Thôi sửa ngoài", "secondary-outline", self._thoi),
                ("gui", "Gửi hàng chờ", "primary", self._gui_one),
                ("rut", "Rút khỏi hàng chờ", "warning-outline", self._rut),
                ("thucong", "Đã import thủ công", "secondary-outline", self._thucong)]
        for i, (k, t, st, cmd) in enumerate(spec):
            b = tb.Button(tools, text=t, bootstyle=st, command=cmd)
            b.grid(row=i // 5, column=i % 5, padx=2, pady=2, sticky="w")
            self.btn[k] = b
        rf, self.rows = make_tree(right, [c[:4] for c in COLS], height=9, selectmode="browse")
        rf.grid(row=3, column=0, sticky="nsew")
        self.rows.tag_configure("tick", background="#d9f2e0")
        self.rows.tag_configure("vd", background="#fde7e9")
        self.rows.tag_configure("nguoi", background="#dbe8ff")
        self.rows.tag_configure("may", background="#fff4d6")
        self.rows.bind("<Button-1>", self._click)
        self.rows.bind("<Double-1>", self._edit)
        self.rows.bind("<<TreeviewSelect>>", self._row_detail)
        self.lbl_row = ttk.Label(right, text="", wraplength=900, justify="left", foreground="#495057")
        self.lbl_row.grid(row=4, column=0, sticky="w", pady=4)
        self.msg = tk.StringVar(); ttk.Label(right, textvariable=self.msg, foreground="#b35c00").grid(row=5, column=0, sticky="w")
        # từ chối / truy thu
        self.tc_var = tk.BooleanVar(); self.tt_var = tk.BooleanVar()
        self.f_tc = ttk.LabelFrame(right, text="Từ chối", padding=6); self.f_tc.grid(row=6, column=0, sticky="ew", pady=(4, 0))
        self.f_tc.columnconfigure((1, 3), weight=1)
        self.chk_tc = tb.Checkbutton(self.f_tc, text="Duyệt từ chối hồ sơ này", variable=self.tc_var, command=self._toggle_tc, bootstyle="round-toggle")
        self.chk_tc.grid(row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(self.f_tc, text="Lý do").grid(row=1, column=0, sticky="nw")
        self.t_lydo = tk.Text(self.f_tc, height=3, width=40, wrap="word"); self.t_lydo.grid(row=1, column=1, sticky="ew", padx=4)
        ttk.Label(self.f_tc, text="Đề nghị").grid(row=1, column=2, sticky="nw")
        self.t_denghi = tk.Text(self.f_tc, height=3, width=40, wrap="word"); self.t_denghi.grid(row=1, column=3, sticky="ew", padx=4)
        self.f_tt = ttk.LabelFrame(right, text="Truy thu", padding=6); self.f_tt.grid(row=7, column=0, sticky="ew", pady=(4, 0))
        self.f_tt.columnconfigure(1, weight=1)
        self.chk_tt = tb.Checkbutton(self.f_tt, text="Có phiếu truy thu", variable=self.tt_var, command=self._toggle_tt, bootstyle="round-toggle")
        self.chk_tt.grid(row=0, column=0, sticky="w")
        self.t_tt = tk.Text(self.f_tt, height=3, wrap="word"); self.t_tt.grid(row=0, column=1, sticky="ew", padx=6)
        for t in (self.t_lydo, self.t_denghi, self.t_tt):
            t.bind("<FocusOut>", lambda e: self._commit_texts())
        pw.add(right, weight=4)
        self._sash_done = False
        self.pw.bind("<Map>", lambda e: self._place_sash())
        right.bind("<Configure>", lambda e: [w.configure(wraplength=max(300, e.width - 20)) for w in (self.lbl_state, self.lbl_row)])

    def _place_sash(self) -> None:
        if self._sash_done or self.pw.winfo_width() < 700:
            return
        try:
            self.pw.sashpos(0, 330)
            self._sash_done = True
        except tk.TclError:
            pass

    # ================= nạp lại =================
    def refresh(self, select: str | None = None) -> None:
        self.frame.after(30, self._place_sash)
        app = self.app
        keep = select or (f'{self.cur["lot"]["id"]}|{self.cur["it"]["id"]}' if self.cur else None)
        rules = app.cfg.rules()
        self.entries = []
        for lot, it in app.store.all_items():
            if not it.get("file"):
                continue
            try:
                dx = A.load_dx(app.store, app.socai, rules, lot, it)
            except Exception as e:                           # noqa: BLE001 - một hồ sơ hỏng không làm hỏng cả trang
                if it["id"] not in self._err_seen:
                    self._err_seen.add(it["id"])
                    app.log(f'LỖI không tính được đề xuất {it.get("sohoso")}: {e}', "err")
                continue
            self.entries.append({"lot": lot, "it": it, "dx": dx, "tab": tab_of(it, dx), "iid": f'{lot["id"]}|{it["id"]}'})
        n = Counter(e["tab"] for e in self.entries)
        self._busy_nb = True
        for i, k in enumerate(NHOM_TAB):
            self.nb.tab(i, text=f"{NHOM_TEN[k]} ({n[k]})")
        self._busy_nb = False
        self._fill_list(keep)

    def _tab_changed(self, _e=None) -> None:
        if self._busy_nb:
            return
        self.tab = NHOM_TAB[self.nb.index("current")]
        self._fill_list(None)

    def _fill_list(self, keep) -> None:
        self.lst.delete(*self.lst.get_children())
        first = None
        for e in self.entries:
            if e["tab"] != self.tab:
                continue
            dx, it = e["dx"], e["it"]
            t = da_tick(dx)
            ntick = (sum(bool(x) for x in (dx["excel"]["tick"] if (dx.get("excel") or {}).get("state") == "sansang" else [r["tick"] for r in dx["rows"]])))
            ntot = len(dx["rows"]) if not ((dx.get("excel") or {}).get("state") == "sansang") else dx["excel"]["nRows"]
            ks = list(dict.fromkeys(i["k"] for i in issues_all(dx)))
            tag = "warn" if A.khoa(it, dx) else ("ok" if t["all"] else "none")
            self.lst.insert("", "end", iid=e["iid"], tags=(tag,),
                            values=(("🔒 " if A.khoa(it, dx) else "") + str(it.get("sohoso")), it.get("madonvi"), f"{ntick}/{ntot}",
                                    ", ".join(ks[:3]) or "sạch"))
            first = first or e["iid"]
        pick = keep if keep and self.lst.exists(keep) else first
        if pick:
            self.lst.selection_set(pick)
            self.lst.see(pick)
        else:
            self._show(None)

    def _pick(self, _e=None) -> None:
        s = self.lst.selection()
        e = next((x for x in self.entries if x["iid"] == s[0]), None) if s else None
        self._show(e)

    # ================= hiển thị hồ sơ =================
    def _view_rows(self, e: dict) -> list:
        dx = e["dx"]
        ex = dx.get("excel") or {}
        out = []
        if ex.get("state") == "sansang":
            for i, r in enumerate(ex["rows"]):
                out.append({"tick": bool(ex["tick"][i]) if i < len(ex["tick"]) else False, "cells": r, "vd": "", "tt": "(file người sửa)", "tag": ""})
            return out
        for r in dx["rows"]:
            ch = _changes(r)
            tag = "tick" if r["tick"] else ("vd" if r["issues"] else ("nguoi" if any(n == "người" for _c, n in ch) else ("may" if ch else "")))
            out.append({"tick": r["tick"], "cells": r["chot"], "vd": "; ".join(i["txt"] for i in r["issues"]),
                        "tt": ", ".join(f"{c} ({n})" for c, n in ch), "tag": tag})
        return out

    def _show(self, e) -> None:
        self.cur = e
        self.msg.set("")
        self.rows.delete(*self.rows.get_children())
        if not e:
            self.lbl_hs.configure(text="Chưa chọn hồ sơ")
            self.lbl_state.configure(text="")
            self.lbl_row.configure(text="")
            for b in self.btn.values():
                b.configure(state="disabled")
            self.f_tt.grid_remove()
            for t in (self.t_lydo, self.t_denghi, self.t_tt):
                t.configure(state="disabled")
            self.chk_tc.configure(state="disabled")
            return
        it, dx = e["it"], e["dx"]
        self.lbl_hs.configure(text=f'{it.get("sohoso")}   ·   {it.get("madonvi")}   ·   {NHOM_TEN[tab_of(it, dx)]}   ·   {len(dx["rows"])} dòng')
        for i, v in enumerate(self._view_rows(e)):
            vals = [("☑" if v["tick"] else "☐") if c[4] is None and c[0] == "tick" else
                    (v["vd"] if c[0] == "vd" else (v["tt"] if c[0] == "tt" else v["cells"].get(c[4], ""))) for c in COLS]
            self.rows.insert("", "end", iid=str(i), values=vals, tags=(v["tag"],) if v["tag"] else ())
        self._state_and_buttons()
        self._texts()
        if self.rows.get_children():
            self.rows.selection_set("0")

    def _state_and_buttons(self) -> None:
        e = self.cur
        it, dx = e["it"], e["dx"]
        q, ex = it.get("q") or {}, dx.get("excel") or {}
        notes = []
        if q.get("kind") == "import":
            notes.append("Đang trong hàng chờ import (khóa) - rút ra để sửa.")
        if q.get("kind") == "tuchoi":
            notes.append("Đã duyệt từ chối - chờ chuyển sang Xử lý TNHS (bỏ tích duyệt từ chối để rút).")
        if ex.get("state") == "dangsua":
            notes.append(f'Đang sửa ngoài bằng Excel: {ex.get("name")} - sửa, lưu, đóng Excel rồi bấm “Import lại file đã sửa…”.')
        if ex.get("state") == "sansang":
            notes.append(f'Đang dùng file người sửa: {ex.get("name")} ({ex.get("nRows")} dòng, đọc {ex.get("docLuc")}). Tích duyệt để gửi.')
        if (it.get("imp") or {}).get("kq") in ("loi", "chua_ro"):
            notes.append("Còn lỗi sau import chưa xử lý (khóa).")
        thieu = [n for n, ok in (("Kiểm tra nháp", ktn_xong(it)), ("Tra cứu F2", f2_xong(it)), ("Tra cứu thẻ", the_xong(it))) if not ok]
        if thieu:
            notes.append("Chưa có kết quả: " + ", ".join(thieu) + " (đề xuất theo tra cứu và lỗi đỏ TST chưa đầy đủ).")
        self.lbl_state.configure(text="\n".join(notes), foreground="#b35c00" if notes else "#6c757d")
        locked = A.khoa(it, dx)
        st = lambda ok: "normal" if ok else "disabled"
        b = self.btn
        b["tick_all"].configure(state=st(not locked)); b["untick"].configure(state=st(not locked))
        b["recalc"].configure(state=st(not locked and ex.get("state") != "sansang"))
        b["reset"].configure(state=st(not locked))
        b["open_xl"].configure(state=st(not q))
        b["nap"].configure(state=st(not q))
        b["thoi"].configure(state=st(ex.get("state") in ("dangsua", "sansang")))
        b["gui"].configure(state=st(not locked and da_tick(dx)["all"]))
        b["rut"].configure(state=st(q.get("kind") in ("import", "tuchoi")))
        b["thucong"].configure(state=st(not q and (it.get("imp") or {}).get("kq") != "xong"))

    def _texts(self) -> None:
        e = self.cur
        it, dx = e["it"], e["dx"]
        locked = A.khoa(it, dx)
        tc = dx.get("tuChoi") or {"lyDo": "", "deNghi": ""}
        for t, v in ((self.t_lydo, tc["lyDo"]), (self.t_denghi, tc["deNghi"])):
            t.configure(state="normal"); t.delete("1.0", "end"); t.insert("1.0", v or "")
            t.configure(state="disabled" if (it.get("q") or {}).get("kind") else "normal")
        self.tc_var.set((it.get("q") or {}).get("kind") == "tuchoi")
        self.chk_tc.configure(state="disabled" if (it.get("q") or {}).get("kind") == "import" else "normal")
        has_tt = any(i["k"] == "truyThu" for i in issues_all(dx)) or bool((dx.get("truyThu") or {}).get("on"))
        if has_tt:
            self.f_tt.grid()
            tt = dx.get("truyThu") or {"on": False, "noiDung": ""}
            self.tt_var.set(bool(tt.get("on")))
            self.t_tt.configure(state="normal"); self.t_tt.delete("1.0", "end"); self.t_tt.insert("1.0", tt.get("noiDung", ""))
            self.t_tt.configure(state="disabled" if locked else "normal")
            self.chk_tt.configure(state="disabled" if locked else "normal")
        else:
            self.f_tt.grid_remove()

    def _row_detail(self, _e=None) -> None:
        e, s = self.cur, self.rows.selection()
        if not e or not s or (e["dx"].get("excel") or {}).get("state") == "sansang":
            self.lbl_row.configure(text="")
            return
        r = e["dx"]["rows"][int(s[0])]
        lines = [f'Dòng STT {r["stt"]} - {r["goc"].get("HOTEN")}']
        for i in r["issues"]:
            lines.append(f'• [{i["k"]}] {i["txt"]}')
        for c, n in _changes(r):
            lines.append(f'• {c}: gốc “{r["goc"].get(c, "")}” → “{r["chot"][c]}” ({n})')
        if r["tra"]:
            lines.append("• Tra cứu: " + "; ".join(f"{k}={v}" for k, v in r["tra"].items()))
        self.lbl_row.configure(text="\n".join(lines))

    # ================= thao tác =================
    def _flash(self, text: str) -> None:
        self.msg.set(text)

    def _sel_row(self):
        s = self.rows.selection()
        return s[0] if s else None

    def _reload(self, keep_row=None) -> None:
        iid = self.cur["iid"] if self.cur else None
        self.refresh(select=iid)
        if keep_row is not None and self.rows.exists(str(keep_row)):
            self.rows.selection_set(str(keep_row))
        self.app._badges()

    def _click(self, ev) -> None:
        if self.rows.identify_region(ev.x, ev.y) != "cell" or self.rows.identify_column(ev.x) != "#1" or not self.cur:
            return
        i = int(self.rows.identify_row(ev.y) or -1)
        e = self.cur
        if i < 0:
            return
        cur = self._view_rows(e)[i]["tick"]
        try:
            A.set_tick(self.app.store, e["lot"], e["it"], e["dx"], i, not cur)
        except ValueError as ex:
            self._flash(str(ex))
            return "break"
        self._reload(i)
        return "break"

    def _tick(self, i, on) -> None:
        if not self.cur:
            return
        try:
            A.set_tick(self.app.store, self.cur["lot"], self.cur["it"], self.cur["dx"], i, on)
        except ValueError as ex:
            self._flash(str(ex))
            return
        self._reload()

    def _edit(self, ev) -> None:
        tree, e = self.rows, self.cur
        if not e or tree.identify_region(ev.x, ev.y) != "cell":
            return
        iid, col = tree.identify_row(ev.y), tree.identify_column(ev.x)
        cid, d02 = COLS[int(col[1:]) - 1][0], COLS[int(col[1:]) - 1][4]
        if not d02 or d02 in COT_KHOA or d02 not in e["dx"]["head"]:
            return
        dx, it = e["dx"], e["it"]
        i = int(iid)
        if A.khoa(it, dx) or (dx.get("excel") or {}).get("state") == "sansang":
            self._flash("Hồ sơ đang bị khóa hoặc đang dùng file Excel - không sửa trong bảng.")
            return
        if dx["rows"][i]["tick"]:
            self._flash("Dòng đã tích duyệt bị khóa sửa - bỏ tích trước.")
            return
        x, y, w, h = tree.bbox(iid, col)
        ent = ttk.Entry(tree)
        ent.place(x=x, y=y, width=max(w, 70), height=h)
        ent.insert(0, dx["rows"][i]["chot"].get(d02, ""))
        ent.focus_set(); ent.select_range(0, "end")
        done = {"v": False}

        def commit(_ev=None):
            if done["v"]:
                return
            done["v"] = True
            v = ent.get()
            ent.destroy()
            msg = A.set_cell(self.app.store, e["lot"], it, dx, i, d02, v)
            self._reload(i)
            self._flash(msg or "")

        def cancel(_ev=None):
            done["v"] = True
            ent.destroy()

        ent.bind("<Return>", commit); ent.bind("<Escape>", cancel); ent.bind("<FocusOut>", commit)

    def _commit_texts(self) -> None:
        e = self.cur
        if not e or A.khoa(e["it"], e["dx"]) or str(self.t_lydo.cget("state")) == "disabled":
            return
        dx = e["dx"]
        ly, dn = self.t_lydo.get("1.0", "end").strip(), self.t_denghi.get("1.0", "end").strip()
        changed = (ly, dn) != (dx["tuChoi"].get("lyDo", ""), dx["tuChoi"].get("deNghi", ""))
        dx["tuChoi"]["lyDo"], dx["tuChoi"]["deNghi"] = ly, dn
        if str(self.f_tt.winfo_manager()) and str(self.t_tt.cget("state")) == "normal":
            tt = dx.setdefault("truyThu", {"on": False, "noiDung": ""})
            nd = self.t_tt.get("1.0", "end").strip()
            changed |= nd != tt.get("noiDung", "")
            tt["noiDung"] = nd
        if changed:
            A.save_dx(self.app.store, e["lot"], e["it"], dx)

    def _toggle_tc(self) -> None:
        e = self.cur
        if not e:
            return
        self._commit_texts()
        on = self.tc_var.get()
        try:
            A.dat_tu_choi(self.app.store, e["lot"], e["it"], e["dx"], on, int(self.app.cfg.settings()["tu_choi_cho_giay"]))
        except ValueError as ex:
            self.tc_var.set(not on)
            messagebox.showwarning("Bộ 600", str(ex))
            return
        self.app.log(("DUYỆT TỪ CHỐI " if on else "Rút duyệt từ chối ") + str(e["it"].get("sohoso")))
        self._reload()

    def _toggle_tt(self) -> None:
        e = self.cur
        if not e:
            return
        self._commit_texts()
        A.set_truy_thu(self.app.store, e["lot"], e["it"], e["dx"], self.tt_var.get(), None, self.app.cfg.settings()["mau_phieu_truy_thu"])
        self._reload()

    def _recalc(self) -> None:
        e = self.cur
        if e:
            A.load_dx(self.app.store, self.app.socai, self.app.cfg.rules(), e["lot"], e["it"], force=True, giu_tay=True)
            self._reload()
            self._flash("Đã tính lại đề xuất (giữ các ô người đã sửa).")

    def _reset(self) -> None:
        e = self.cur
        if e and messagebox.askyesno("Bộ 600", "Bỏ mọi ô đã sửa và tích duyệt, tính lại từ file gốc?"):
            A.load_dx(self.app.store, self.app.socai, self.app.cfg.rules(), e["lot"], e["it"], force=True, giu_tay=False)
            self._reload()

    def _open_xl(self) -> None:
        e = self.cur
        if not e:
            return
        try:
            tu_goc = False
            ex = e["dx"].get("excel") or {}
            if ex.get("state") == "sansang":
                tu_goc = not messagebox.askyesno("Bộ 600", "Đã có file người sửa nạp trước đó.\nCó = mở lại đúng file đó.\nKhông = làm lại từ bản gốc (file cũ đổi tên _cu).")
            f = A.mo_file_de_sua(self.app.store, e["lot"], e["it"], e["dx"], tu_goc)
        except ValueError as ex:
            messagebox.showwarning("Bộ 600", str(ex))
            return
        open_path(f)
        self.app.log(f"Mở Excel để sửa: {f}")
        self._reload()

    def _nap(self) -> None:
        e = self.cur
        if not e:
            return
        ex = e["dx"].get("excel") or {}
        init = str(__import__("pathlib").Path(ex["path"]).parent) if ex.get("path") else str(self.app.paths.lot_dir(e["lot"]["id"]) / "_sua")
        f = filedialog.askopenfilename(title="Chọn file đã sửa", initialdir=init, filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not f:
            return
        errs = A.nap_file_sua(self.app.store, e["lot"], e["it"], e["dx"], f)
        if errs:
            messagebox.showerror("Bộ 600 - file không được nhận", "\n".join(errs[:15]) + (f"\n... còn {len(errs) - 15} lỗi" if len(errs) > 15 else ""))
            return
        self.app.log(f'Đã nạp file sửa tay của {e["it"].get("sohoso")}.')
        self._reload()

    def _thoi(self) -> None:
        if self.cur:
            A.thoi_sua_ngoai(self.app.store, self.cur["lot"], self.cur["it"], self.cur["dx"])
            self._reload()

    def _gui_one(self) -> None:
        e = self.cur
        if not e:
            return
        try:
            mota = A.gui_hang_cho(self.app.store, e["lot"], e["it"], e["dx"])
        except ValueError as ex:
            messagebox.showwarning("Bộ 600", str(ex))
            return
        self._sau_khi_gui([f'{e["it"].get("sohoso")} ({mota})'])
        self._reload()

    def _gui_tab(self) -> None:
        cand = [x for x in self.entries if x["tab"] == self.tab and not A.khoa(x["it"], x["dx"])]
        full = [x for x in cand if da_tick(x["dx"])["all"]]
        part = [x for x in cand if da_tick(x["dx"])["any"] and not da_tick(x["dx"])["all"]]
        if part:
            k = messagebox.askyesnocancel("Bộ 600", f'{len(part)} hồ sơ mới tích MỘT PHẦN dòng ({", ".join(str(x["it"].get("sohoso")) for x in part)}). '
                                          f"Bộ 600 không import hồ sơ thiếu dòng.\n\nCó = tích nốt và gửi cùng\nKhông = chỉ gửi {len(full)} hồ sơ đã tích đủ\nHủy = thôi")
            if k is None:
                return
            if k:
                for x in part:
                    A.set_tick(self.app.store, x["lot"], x["it"], x["dx"], None, True)
                full += part
        if not full:
            self._flash("Chưa có hồ sơ nào được tích đủ dòng để gửi.")
            return
        done = []
        for x in full:
            try:
                done.append(f'{x["it"].get("sohoso")} ({A.gui_hang_cho(self.app.store, x["lot"], x["it"], x["dx"])})')
            except ValueError as ex:
                self.app.log(f'Không gửi được {x["it"].get("sohoso")}: {ex}', "err")
        self._sau_khi_gui(done)
        self._reload()

    def _sau_khi_gui(self, done: list) -> None:
        for d in done:
            self.app.log("Gửi vào hàng chờ import: " + d)
        if done:
            if self.app.cfg.module_on("import"):
                self.app.log(f"Đã gửi {len(done)} hồ sơ vào hàng chờ import. Vào mục 8 bấm “Chạy bước này” để máy import.")
            else:
                self.app.log("Module 8 (Import TST) đang tắt: hồ sơ nằm trong hàng chờ. Import tay trên TST rồi bấm “Tôi đã import thủ công”.")

    def _rut(self) -> None:
        e = self.cur
        if not e:
            return
        q = (e["it"].get("q") or {}).get("kind")
        if q == "tuchoi":
            self.tc_var.set(False)
            self._toggle_tc()
            return
        if A.rut_hang_cho(self.app.store, e["lot"], e["it"]):
            self.app.log(f'Rút khỏi hàng chờ: {e["it"].get("sohoso")}')
        self._reload()

    def _thucong(self) -> None:
        e = self.cur
        if not e:
            return
        k = messagebox.askyesnocancel("Bộ 600", "Ghi nhận bạn đã import hồ sơ này thủ công trên TST.\n\nBạn cũng đã XỬ LÝ (Thu) hồ sơ này trên TNHS rồi?\nCó = ghi cả hai · Không = chỉ ghi import · Hủy = thôi")
        if k is None:
            return
        A.nguoi_import_thu_cong(self.app.store, self.app.socai, e["lot"], e["it"], bool(k))
        self.app.log(f'Người xác nhận đã import thủ công: {e["it"].get("sohoso")}', "ok")
        self._reload()
