"""A5 - Cấu hình, đường dẫn dữ liệu, quy tắc mặc định (port từ config.js)."""
from __future__ import annotations

import copy
import json
import os
import json
from pathlib import Path
from typing import Optional

QUY_TAC_MAC_DINH = {
    "mlToiThieu": 5310000,
    "tyleChuan": 32,
    "macvTuChoi": ["nhân viên", "công nhân", "lái xe"],
    "paTang": ["TM", "TD", "TC", "ON", "AD"],
    "nhom": {
        "macv": "tuchoi", "khongMa": "tuchoi", "cmnd9KhongMa": "tuchoi", "cmnd9": "tuchoi",
        "cdChuHo": "tuchoi", "ml": "nguoi", "tyle": "nguoi", "truyThu": "nguoi", "soCai": "nguoi",
        "loiDo": "nguoi", "dinhDanh": "dinhdanh", "haiNguoi": "dinhdanh",
    },
    "mau": {
        "macv": {"lyDo": "Chức danh nghề, công việc ghi chung chung, không xác định được vị trí việc làm.",
                 "deNghi": "Đề nghị đơn vị ghi rõ chức danh nghề, công việc theo hợp đồng lao động và nộp lại hồ sơ."},
        "khongMa": {"lyDo": "Không kê khai mã số BHXH và số CCCD của người lao động.",
                    "deNghi": "Đề nghị đơn vị bổ sung mã số BHXH hoặc số CCCD 12 số của người lao động và nộp lại hồ sơ."},
        "cmnd9KhongMa": {"lyDo": "Không kê khai mã số BHXH; số giấy tờ kê khai là CMND 9 số đã hết giá trị sử dụng.",
                         "deNghi": "Đề nghị đơn vị bổ sung số CCCD 12 số của người lao động và nộp lại hồ sơ."},
        "cmnd9": {"lyDo": "Số CMND 9 số, không tra cứu được số CCCD tương ứng.",
                  "deNghi": "Đề nghị đơn vị bổ sung số CCCD 12 số của người lao động và nộp lại hồ sơ."},
        "cdChuHo": {"lyDo": "Hồ sơ báo tăng không đúng mã đơn vị.",
                    "deNghi": "Đề nghị đơn vị báo tăng chủ hộ kinh doanh đúng mã đơn vị theo quy định."},
        "ml": {"lyDo": "Mức lương đóng BHXH thấp hơn mức lương tối thiểu vùng.",
               "deNghi": "Đề nghị đơn vị điều chỉnh mức lương đóng không thấp hơn mức lương tối thiểu vùng và nộp lại hồ sơ."},
        "tyle": {"lyDo": "Tỷ lệ đóng không đúng quy định.",
                 "deNghi": "Đề nghị đơn vị kê khai lại tỷ lệ đóng đúng quy định."},
    },
}

QT_TEN = {
    "macv": "MACV chung chung / trống / ký tự lạ", "khongMa": "Trống cả mã số BHXH và CCCD",
    "cmnd9KhongMa": "Không có mã số BHXH, chỉ có CMND 9 số", "cmnd9": "CMND 9 số không tra được CCCD",
    "cdChuHo": "Khối CD báo tăng TYLE 32", "ml": "ML dưới mức tối thiểu", "tyle": "TYLE dưới tỷ lệ chuẩn",
    "truyThu": "Truy thu từ 2 tháng", "soCai": "Trùng dòng đã Lưu (sổ cái)",
    "loiDo": "Lỗi đỏ TST chưa có cách sửa tự động", "dinhDanh": "Cần tra định danh",
    "haiNguoi": "Mã số và CCCD 2 người / F2 nhiều kết quả",
}

NHOM_TEN = {"sach": "Import ngay", "tracuu": "Import theo tra cứu", "tuchoi": "Đề xuất từ chối",
            "dinhdanh": "Tra cứu định danh", "nguoi": "Cần người xem", "loisau": "Còn lỗi sau import"}
NHOM_TAB = ["tuchoi", "sach", "tracuu", "dinhdanh", "nguoi", "loisau"]

DUYET_COT_CO_DINH = ["STT", "HOTEN", "PA", "ML", "TYLE", "TUTHANG", "GHICHU"]
COT_TU_CHOI = {
    "macv": ["MACV"], "khongMa": ["SOBHXH", "SOCMND"], "cmnd9KhongMa": ["SOBHXH", "SOCMND"],
    "cmnd9": ["SOBHXH", "SOCMND"], "cdChuHo": ["TYLE"], "ml": ["ML"], "tyle": ["TYLE"],
    "truyThu": ["TUTHANG", "NGAY_NOP_HS"], "dinhDanh": ["SOBHXH", "SOCMND"], "haiNguoi": ["SOBHXH", "SOCMND"],
}
COT_KHOA = ["STT", "GHICHU"]
# Cột phải giữ dạng chữ (số 0 đầu, ngày tháng) - file sửa bằng Excel mà thành ô SỐ thì không nhận
COT_CHU = ["SOBHXH", "SOCMND", "MA_TINH", "MA_BV", "SDT", "MAVUNG", "MA_TINHCMT", "TINH_NK", "HUYEN_NK",
           "XA_NK", "TINH_LH", "HUYEN_LH", "XA_LH", "TINH_HK", "HUYEN_HK", "XA_HK", "TUTHANG", "DENTHANG",
           "NGAYSINH", "NGAYCMND", "NGAY_NOP_HS", "NGAY_HL_HDLD", "NGAY_CHET", "TUNGAY"]

SETTINGS_MAC_DINH = {
    "modules": {"duyet": True, "import": True, "tnhs": True},   # import cần bật cùng duyet
    "tnhs_tu_dong": False,          # False: máy điền sẵn phiếu rồi dừng chờ người bấm GHI NHẬN
    "lo_xu_ly_toi_da": 20,
    "on_dinh": {"langMs": 600, "nhipMin": 800, "nhipMax": 1500, "toiDaGiay": 90},
    "bv_luu_ngay": 30,
    "giu_ho_so_xong_ngay": 3,
    "tu_choi_cho_giay": 120,
    "tnhs_ly_do_khong_hop_le": "Hồ sơ kê khai không đúng quy định",
    "tnhs_cho_nguoi_giay": 900,
    "mau_phieu_truy_thu": (
        "1. Đã báo tăng tháng hiện tại ({THANG_BAO_TANG}) để đảm bảo quyền lợi KCB cho NLĐ.\n"
        "2. Truy thu từ tháng {TU_THANG_GOC}, đề nghị bổ sung hồ sơ: Giấy phép ĐKKD để tiến hành lập biên bản "
        "xác minh lao động truy thu tại cơ quan BHXH."
    ),
    "cq": "",
    "dv_tu_xuat": False,          # bước 1: True = tự xuất file Danh sách đơn vị từ TST; False = dùng file đã chọn
    "delay_ms": 2000,
    "chrome_port": 9222,
    "chrome_path": "",            # để trống = tự tìm chrome.exe / msedge.exe
}


class Paths:
    """Bố cục thư mục giữ nguyên như extension: <base>/<ngày>/, _nhatky, _socai, _danhmuc (+ _app cho CSDL)."""

    @staticmethod
    def default_base() -> Path:
        """Đọc vị trí dữ liệu đã chọn trong Cài đặt; tương thích bản cũ."""
        appdata = Path(os.environ.get("APPDATA", Path.home()))
        pointer = appdata / "Bo600" / "location.json"
        try:
            value = json.loads(pointer.read_text(encoding="utf-8")).get("base")
            if value:
                return Path(value).expanduser()
        except (OSError, ValueError, TypeError):
            pass
        return Path.home() / "Downloads" / "Bo600"

    @staticmethod
    def save_default_base(base: str | os.PathLike) -> None:
        appdata = Path(os.environ.get("APPDATA", Path.home()))
        pointer = appdata / "Bo600" / "location.json"
        pointer.parent.mkdir(parents=True, exist_ok=True)
        tmp = pointer.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({"base": str(Path(base).expanduser().resolve())}, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, pointer)

    def __init__(self, base: Optional[str | os.PathLike] = None):
        self.base = Path(base).expanduser() if base else self.default_base()
        self.app = self.base / "_app"
        self.nhatky = self.base / "_nhatky"
        self.socai = self.base / "_socai"
        self.danhmuc = self.base / "_danhmuc"

    def ensure(self) -> "Paths":
        for p in (self.base, self.app, self.nhatky, self.socai, self.danhmuc):
            p.mkdir(parents=True, exist_ok=True)
        return self

    @property
    def db_path(self) -> Path:
        return self.app / "bo600.sqlite"

    def lot_dir(self, lot_id: str) -> Path:
        return self.base / lot_id

    def res_dir(self, lot_id: str) -> Path:
        return self.lot_dir(lot_id) / "_ketqua"

    def item_path(self, lot_id: str, rel: str) -> Path:
        return self.lot_dir(lot_id) / str(rel or "")


def _merge(dst: dict, src: dict) -> dict:
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _merge(dst[k], v)
        elif k in dst:           # chỉ nhận khóa đã biết, tránh rác từ file cũ
            dst[k] = v
    return dst


class Config:
    """Cài đặt (settings.json) và quy tắc duyệt người dùng đã sửa (rules7.json)."""

    def __init__(self, paths: Paths):
        self.paths = paths

    def _read(self, name: str) -> dict:
        f = self.paths.app / name
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _write(self, name: str, data: dict) -> None:
        self.paths.app.mkdir(parents=True, exist_ok=True)
        f = self.paths.app / name
        tmp = f.with_suffix(f.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, f)

    # --- cài đặt chung ---
    def settings(self) -> dict:
        return _merge(copy.deepcopy(SETTINGS_MAC_DINH), self._read("settings.json"))

    def save_settings(self, s: dict) -> dict:
        merged = _merge(self.settings(), s)
        merged["delay_ms"] = max(500, int(merged.get("delay_ms") or 2000))
        self._write("settings.json", merged)
        return merged

    def module_on(self, name: str) -> bool:
        m = self.settings()["modules"]
        name = {"imp": "import"}.get(name, name)      # khóa bước 8 là "imp", khóa cài đặt là "import"
        if name == "import":
            return bool(m.get("import") and m.get("duyet"))
        return bool(m.get(name))

    # --- quy tắc tiền kiểm (core.js: getRules) ---
    def rules(self) -> dict:
        r = copy.deepcopy(QUY_TAC_MAC_DINH)
        o = self._read("rules7.json")
        for k in ("mlToiThieu", "tyleChuan"):
            if o.get(k) is not None:
                try:
                    r[k] = float(o[k]) if "." in str(o[k]) else int(o[k])
                except (TypeError, ValueError):
                    pass
        for k in ("macvTuChoi", "paTang"):
            if isinstance(o.get(k), list):
                r[k] = o[k]
        if isinstance(o.get("nhom"), dict):
            r["nhom"].update(o["nhom"])
        for k, v in (o.get("mau") or {}).items():
            r["mau"][k] = {**r["mau"].get(k, {}), **v}
        return r

    def save_rules(self, overrides: dict) -> None:
        self._write("rules7.json", overrides)
