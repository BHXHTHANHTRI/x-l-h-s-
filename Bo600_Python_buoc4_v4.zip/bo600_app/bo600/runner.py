"""Bộ chạy nền cho các bước (khung cho tầng B/C).

Giao diện không bao giờ gọi trình duyệt trực tiếp: mỗi bước đăng ký một hàm xử lý
    handler(ctx: StepContext, items: list[tuple[lot, item]]) -> None
Hàm xử lý chạy trong luồng nền, ghi nhật ký bằng ctx.log(), gọi ctx.check_stop() giữa các hồ sơ,
báo lỗi bằng cách ném exception. Giao diện nhận tin qua hàng đợi `runner.q` (cùng mẫu result_queue của BHXH Tool).
"""
from __future__ import annotations

import queue
import threading
import time
import traceback
from dataclasses import dataclass, field
from typing import Callable, Optional

from .util import now_vn, stamp_str

# khóa bước -> (số, tên). Khóa dùng chung cho giao diện, runner và hồ sơ (it['nguoiLam'][khóa]).
BUOC = {
    "dv": ("1", "Đơn vị quản lý"), "tn": ("2", "Tiếp nhận"), "tai": ("3", "Tải D02"),
    "ktn": ("4", "Kiểm tra nháp"), "f2": ("5", "Tra cứu F2"), "the": ("6", "Tra cứu thẻ"),
    "duyet": ("7", "Duyệt"), "imp": ("8", "Import TST"), "tnhs": ("9", "Xử lý TNHS"),
}
CHUOI_MAC_DINH = ["tn", "tai", "ktn", "f2", "the", "imp", "tnhs"]   # các bước máy tự chạy; bước 7 do người duyệt


class StopRequested(Exception):
    """Người bấm Dừng."""


@dataclass
class StepContext:
    store: object
    socai: object
    cfg: object
    runner: "Runner"
    key: str
    lines: list = field(default_factory=list)
    chain: bool = False          # True: bước đang chạy trong một chuỗi nhiều bước (bước 2 không có TIC thì bỏ qua thay vì dừng chuỗi)

    def log(self, msg: str) -> None:
        line = f"[{now_vn()[:8]}] {msg}"
        self.lines.append(line)
        self.runner.q.put(("log", line))

    def status(self, text: str) -> None:
        self.runner.q.put(("status", text))

    def check_stop(self) -> None:
        self.runner._wait_if_paused()

    def sleep(self, seconds: float) -> None:
        """Chờ có hỗ trợ tạm dừng và dừng."""
        end = time.monotonic() + max(0, seconds)
        while time.monotonic() < end:
            self.runner._wait_if_paused()
            if self.runner.stop_flag.wait(min(0.1, max(0, end - time.monotonic()))):
                raise StopRequested()


class Runner:
    def __init__(self, store, socai, cfg):
        self.store, self.socai, self.cfg = store, socai, cfg
        self.q: queue.Queue = queue.Queue()
        self.stop_flag = threading.Event()
        self.pause_flag = threading.Event()
        self.handlers: dict[str, Callable] = {}
        self._thread: Optional[threading.Thread] = None

    def register(self, key: str, fn: Callable) -> None:
        if key not in BUOC:
            raise KeyError(key)
        self.handlers[key] = fn

    def has(self, key: str) -> bool:
        return key in self.handlers

    @property
    def busy(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    @property
    def paused(self) -> bool:
        return self.pause_flag.is_set()

    def pause(self) -> None:
        if self.busy:
            self.pause_flag.set()
            self.q.put(("status", "Đang tạm dừng — sẽ dừng tại điểm an toàn tiếp theo"))

    def resume(self) -> None:
        self.pause_flag.clear()
        self.q.put(("status", "Đang tiếp tục"))

    def toggle_pause(self) -> None:
        if self.paused:
            self.resume()
        else:
            self.pause()

    def stop(self) -> None:
        self.stop_flag.set()
        self.pause_flag.clear()  # đánh thức luồng nếu đang tạm dừng

    def _wait_if_paused(self) -> None:
        while self.pause_flag.is_set():
            if self.stop_flag.is_set():
                raise StopRequested()
            time.sleep(0.1)
        if self.stop_flag.is_set():
            raise StopRequested()

    def run(self, keys: list[str] | str, items: Optional[list] = None) -> bool:
        """Chạy lần lượt các bước trong luồng nền. items=None: hàm xử lý tự chọn hồ sơ cần làm. False nếu đang bận."""
        if self.busy:
            return False
        keys = [keys] if isinstance(keys, str) else list(keys)
        self.stop_flag.clear()
        self.pause_flag.clear()
        self.q.put(("busy", True))
        self._thread = threading.Thread(target=self._work, args=(keys, items), daemon=True)
        self._thread.start()
        return True

    def _work(self, keys, items) -> None:
        err = None
        for key in keys:
            ctx = StepContext(self.store, self.socai, self.cfg, self, key, chain=len(keys) > 1)
            name = f"{BUOC[key][0]}. {BUOC[key][1]}"
            if key not in self.handlers:
                ctx.log(f"BỎ QUA {name}: bước này chưa được cài đặt trong bản này (cần lớp điều khiển trình duyệt).")
                continue
            ctx.log(f"BẮT ĐẦU {name}")
            ctx.status(f"Đang chạy: {name}")
            try:
                self.handlers[key](ctx, items)
                ctx.log(f"XONG {name}")
            except StopRequested:
                ctx.log(f"ĐÃ DỪNG {name} theo yêu cầu.")
                err = "stop"
            except Exception as e:                                    # noqa: BLE001 - báo cho người dùng, không làm sập app
                ctx.log(f"LỖI {name}: {e}")
                ctx.log(traceback.format_exc(limit=3).strip())
                err = str(e)
            self._save_log(ctx)
            if err:
                break
        self.q.put(("status", "Sẵn sàng" if not err else ("Đã dừng" if err == "stop" else "Có lỗi - xem nhật ký")))
        self.q.put(("busy", False))
        self.q.put(("done", keys, err))

    def _save_log(self, ctx: StepContext) -> None:
        try:
            d = self.store.paths.nhatky
            d.mkdir(parents=True, exist_ok=True)
            (d / f"{ctx.key}_{stamp_str()}.txt").write_text("\n".join(ctx.lines) + "\n", encoding="utf-8")
        except OSError:
            pass
