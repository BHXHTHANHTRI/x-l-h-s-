"""Ghi sổ cái các lệnh TNHS (tiếp nhận, XỬ LÝ, trình ký, phiếu hướng dẫn) mà máy bấm.

Port từ page_hook.js (nghe POST .../gateway/api/GetValues có "hanhdong" hoặc "noidungyeucauhths") và
content.js (onTnhsAct, parseLoose, deepGetCI). Chỉ ĐỌC lại nội dung trang tự gửi và kết quả máy chủ trả về.

    ghi = GhiSoCaiTnhs(tab, socai, run="tn")     # từ lúc này mọi lệnh máy bấm đều được ghi
    ... bấm GHI NHẬN ...
    tab.sleep(...)                               # sleep() của Tab xử lý phản hồi nên entry được ghi trong lúc chờ
    ghi.entries                                  # các entry đã ghi (để báo cáo)
"""
from __future__ import annotations

import json
import random
import re
import string
import time
from typing import Optional
from urllib.parse import parse_qsl

API_TNHS = r"/gateway/api/GetValues"
RX_LENH = re.compile(r"hanhdong|noidungyeucauhths", re.I)


def parse_loose(t) -> Optional[dict]:
    """JSON, hoặc dạng form a=b&c=d (giá trị nào là JSON thì giải mã)."""
    if not t:
        return None
    try:
        return json.loads(t)
    except ValueError:
        pass
    try:
        o = {}
        for k, v in parse_qsl(t, keep_blank_values=True):
            try:
                o[k] = json.loads(v)
            except ValueError:
                o[k] = v
        return o
    except Exception:                                          # noqa: BLE001
        return None


def deep_get_ci(o, key: str, depth: int = 0):
    """Lấy khóa không phân biệt hoa thường ở mọi tầng (chuỗi bắt đầu bằng { được giải mã). Không có: None."""
    if not isinstance(o, (dict, list)) or depth > 4:
        return None
    if isinstance(o, dict):
        for k in o:
            if k.lower() == key.lower():
                return o[k]
        vals = list(o.values())
    else:
        vals = o
    for v in vals:
        if isinstance(v, str) and v.lstrip().startswith("{"):
            try:
                v = json.loads(v)
            except ValueError:
                continue
        r = deep_get_ci(v, key, depth + 1)
        if r is not None:
            return r
    return None


def plain(html, mx: int) -> str:
    t = re.sub(r"<[^>]*>", " ", str(html or ""))
    return re.sub(r"\s+", " ", t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")).strip()[:mx]


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def entry_tu_lenh(req_text: str, resp_text: Optional[str], status: int, ts: int, who: str = "may", run: str = "", page: str = "") -> dict:
    """Entry sổ cái từ một lệnh TNHS. who: 'may' | 'nguoi'."""
    q = parse_loose(req_text) or {}
    r = parse_loose(resp_text)
    sohoso = _s(deep_get_ci(q, "sohoso"))
    rnd = "".join(random.choices(string.ascii_lowercase + string.digits, k=5))
    base = {"id": f"{ts}-{rnd}", "ts": ts, "at": time.strftime("%d/%m/%Y %H:%M:%S", time.localtime(ts / 1000)), "he": "TNHS",
            "who": who, "run": run, "status": status, "sohosos": [sohoso] if sohoso else [], "page": page}
    resp_ok_http = 200 <= status < 300
    code = deep_get_ci(r, "code") if isinstance(r, dict) else None
    msg = _s(deep_get_ci(r, "msg")) if isinstance(r, dict) else ""
    if deep_get_ci(q, "noidungyeucauhths") is not None:
        # Phiếu hướng dẫn: chỉ giữ lý do và nội dung đề nghị (không giữ địa chỉ, điện thoại, email...)
        ok = resp_ok_http and r is not False and not (code is not None and _num(code) != 0)
        return {**base, "viec": "Phiếu hướng dẫn", "loai": "phieu", "bophan": "Thu", "ok": ok,
                "ketqua": "Đã lưu" if ok else "Không thành công", "lydo": plain(deep_get_ci(q, "lydo"), 500),
                "denghi": plain(deep_get_ci(q, "noidungyeucauhths"), 1500), "madv": _s(deep_get_ci(q, "madonvi"))}
    ok = resp_ok_http and ((_num(code) == 0) if code is not None else bool(re.search("thành công", msg, re.I)))
    dg, buoc = _s(deep_get_ci(q, "loaidanhgia")), _s(deep_get_ci(q, "buoc"))
    hd, ctt, pbg = _s(deep_get_ci(q, "hanhdong")), _s(deep_get_ci(q, "currenttrangthaixuly")), _s(deep_get_ci(q, "dmphongbanguiid"))
    # Bộ phận gửi lệnh: 112 = Quản lý thu, 109 = Cấp sổ-thẻ; không có thì suy theo bước
    bophan = ("Cấp sổ-thẻ" if pbg == "109" else "Thu" if pbg == "112" else "Cấp sổ-thẻ" if buoc == "3" else "Thu" if buoc == "2"
              else ("phòng " + pbg if pbg else "?"))
    # Loại lệnh theo "hanhdong": 1 = tiếp nhận, 3 = XỬ LÝ, 4 = trình ký
    loai = "tiepnhan" if (hd == "1" or (not hd and ctt == "1")) else "xuly" if hd == "3" else "trinhky" if hd == "4" else "khac"
    kq = ("Đã tiếp nhận" if loai == "tiepnhan" else "Đã trình ký" if loai == "trinhky"
          else "Hợp lệ" if dg == "1" else "Không hợp lệ" if dg == "3" else ("Đánh giá " + dg if dg else ""))
    viec = {"tiepnhan": f"Tiếp nhận ({bophan})", "xuly": f"XỬ LÝ ({bophan})", "trinhky": f"Trình ký ({bophan})"}.get(
        loai, "TNHS hành động " + (hd or "?") + (f", bước {buoc}" if buoc else ""))
    return {**base, "viec": viec, "loai": loai, "bophan": bophan, "hanhdong": hd, "ok": ok,
            "ketqua": kq if ok else "Không thành công" + (": " + msg[:120] if msg else ""), "danhgia": dg, "buoc": buoc,
            "lydoId": _s(deep_get_ci(q, "dmloailydoid")), "phongTiep": _s(deep_get_ci(q, "dmphongbantiep")), "msg": msg[:200]}


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


class GhiSoCaiTnhs:
    """Nghe các lệnh TNHS của một tab và ghi vào sổ cái. Gắn một lần cho mỗi tab/lượt chạy."""

    def __init__(self, tab, socai, who: str = "may", run: str = ""):
        self.tab, self.socai, self.who, self.run = tab, socai, who, run
        self.entries: list[dict] = []
        tab.net.on_response(API_TNHS, self._on_hit)

    def _on_hit(self, hit) -> None:
        if hit.method != "POST":
            return
        body = hit.post_data() or ""
        if not RX_LENH.search(body):
            return
        e = entry_tu_lenh(body, hit.text(), hit.status, int(time.time() * 1000), self.who, self.run, self._hash())
        self.socai.add(e)
        self.entries.append(e)

    def _hash(self) -> str:
        try:
            u = self.tab.page.url
            return "#" + u.split("#", 1)[1].split("?")[0] if "#" in u else ""
        except Exception:                                      # noqa: BLE001
            return ""

    def so_ho_so(self, loai: str = "tiepnhan", ok: Optional[bool] = True) -> list[str]:
        return [s for e in self.entries if e["loai"] == loai and (ok is None or e["ok"] == ok) for s in e["sohosos"]]
