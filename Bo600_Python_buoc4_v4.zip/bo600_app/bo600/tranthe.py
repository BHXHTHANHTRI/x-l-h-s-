"""A3 - Danh mục tràn thẻ (chỉ cơ sở KCB Hà Nội, mã tỉnh 01): đọc + khóa cấu trúc file, tra chữ hiển thị, so sánh.

Port từ m4b_tranthe.js. File sai MỘT điểm là không nhận cả file, danh mục đang dùng giữ nguyên.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Optional

from openpyxl import load_workbook

from .d02_io import cell_text, write_xlsx_multi
from .store import Store
from .util import now_vn

TRAN_TINH = "01"
TRAN_SHEET = "DanhMucTranThe"
TRAN_HEAD = ["STT", "Mã BV", "Tên BV", "Trạng thái tràn thẻ", "Điều kiện đăng ký"]
TRAN_KEY = "tranThe540"
TRAN_FILE_LUU = "DanhMuc_TranThe.xlsx"
TRAN_FILE_XUAT = "DanhMuc_TranThe_dang_dung.xlsx"


class TranTheError(ValueError):
    pass


def _d1(s) -> str:
    return re.sub(r"\s+", " ", cell_text(s)).strip()


def tran_ma(bv) -> str:
    """Mã BV trong D02/thẻ -> khóa danh mục '01-xxx'."""
    b = str("" if bv is None else bv).strip().upper()
    if re.match(r"^01[0-9A-Z]{3}$", b):
        b = b[2:]
    return f"{TRAN_TINH}-{b}" if b else ""


def tran_text(tinh, bv, catalog: Optional[dict]) -> str:
    """Chữ ở cột BV_D02_tran. Không phải tỉnh 01: để trống. catalog = dict mã -> {ten, t, dk} hoặc None (chưa nạp)."""
    if str("" if tinh is None else tinh).strip() != TRAN_TINH:
        return ""
    if not catalog:
        return "chưa có dữ liệu"
    key = tran_ma(bv)
    if not key:
        return ""
    r = catalog.get(key)
    if not r:
        return "không có trong danh mục tràn thẻ"
    s = "TRÀN THẺ" if r["t"] == "1" else ("chưa tràn thẻ" if r["t"] == "0" else "chưa có số phân bổ")
    if r.get("dk"):
        s += ", điều kiện ĐK KCB: " + r["dk"]
    return s


def tran_parse(path: str | Path) -> dict:
    wb = load_workbook(str(path), data_only=True)
    if len(wb.sheetnames) != 1 or wb.sheetnames[0] != TRAN_SHEET:
        raise TranTheError(f'Sai cấu trúc: file phải có đúng 1 sheet tên "{TRAN_SHEET}" '
                           f'(file này có: {", ".join(wb.sheetnames)}).')
    ws = wb[TRAN_SHEET]
    raw = [(r_idx, [_d1(c) for c in row]) for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1)]
    raw = [(i, r) for i, r in raw if any(r)]                  # bỏ dòng trống
    if not raw:
        raise TranTheError("Sai cấu trúc: sheet trống.")
    _, h = raw[0]
    if any(h[5:]) or any((h[i] if i < len(h) else "") != x for i, x in enumerate(TRAN_HEAD)):
        raise TranTheError("Sai cấu trúc: dòng tiêu đề phải đúng 5 cột theo thứ tự: " + " | ".join(TRAN_HEAD)
                           + ". File này: " + " | ".join(x for i, x in enumerate(h) if x or i < 5))
    err, out, n = [], {}, 0
    for line, r in raw[1:]:                                    # line = số dòng thật trên sheet
        c = [(r[j] if j < len(r) else "") for j in range(5)]
        if any(r[5:]):
            err.append(f"Dòng {line}: có dữ liệu ngoài 5 cột")
            continue
        ma = c[1].upper()
        if not re.match(r"^\d+$", c[0]):
            err.append(f'Dòng {line}: STT "{c[0]}" không phải số')
        if not re.match(r"^01-[0-9A-Z]{3}$", ma):
            err.append(f'Dòng {line}: Mã BV "{c[1]}" không đúng dạng 01-xxx (chỉ cơ sở KCB Hà Nội)')
        if not c[2]:
            err.append(f"Dòng {line}: thiếu Tên BV")
        if not re.match(r"^[01]?$", c[3]):
            err.append(f'Dòng {line}: Trạng thái tràn thẻ "{c[3]}" chỉ được 1, 0 hoặc để trống (chưa có số phân bổ)')
        if ma in out:
            err.append(f"Dòng {line}: trùng Mã BV {ma} (đã có ở dòng {out[ma]['dong']})")
        else:
            out[ma] = {"ten": c[2], "t": c[3], "dk": c[4], "dong": line}
        n += 1
    if not n:
        err.append("File không có dòng dữ liệu nào.")
    if err:
        more = f"\n... còn {len(err) - 12} lỗi nữa" if len(err) > 12 else ""
        raise TranTheError(f"File KHÔNG được nhận ({len(err)} lỗi), danh mục đang dùng giữ nguyên:\n"
                           + "\n".join(err[:12]) + more)
    for v in out.values():
        del v["dong"]
    return out


def tran_dem(rows: Optional[dict]) -> dict:
    v = list((rows or {}).values())
    return {"n": len(v), "tran": sum(x["t"] == "1" for x in v), "khong": sum(x["t"] == "0" for x in v),
            "chua": sum(x["t"] == "" for x in v), "dk": sum(bool(x.get("dk")) for x in v)}


def tran_so_sanh(moi: dict, cu: Optional[dict]) -> str:
    if not cu:
        return ""
    them = sum(k not in cu for k in moi)
    doi = sum(k in cu and cu[k]["t"] != moi[k]["t"] for k in moi)
    bot = sum(k not in moi for k in cu)
    return (f"So với danh mục đang dùng: thêm {them} cơ sở, bớt {bot} cơ sở, đổi trạng thái tràn thẻ {doi} cơ sở.")


class TranThe:
    """Danh mục lưu lâu dài trong CSDL + bản sao nguyên văn ở _danhmuc."""

    def __init__(self, store: Store):
        self.store = store

    def load(self) -> Optional[dict]:
        return self.store.kv_get(TRAN_KEY)

    def rows(self) -> Optional[dict]:
        d = self.load()
        return d["rows"] if d else None

    def preview(self, path: str | Path) -> dict:
        """Đọc + kiểm tra file, trả tóm tắt để hỏi xác nhận (chưa thay danh mục)."""
        rows = tran_parse(path)
        d = tran_dem(rows)
        tom_tat = (f"File {Path(path).name}: {d['n']} cơ sở KCB - tràn thẻ {d['tran']}, chưa tràn {d['khong']}, "
                   f"chưa có số phân bổ {d['chua']}; có điều kiện đăng ký {d['dk']}.")
        return {"rows": rows, "tom_tat": tom_tat, "so_sanh": tran_so_sanh(rows, self.rows())}

    def apply(self, path: str | Path, rows: dict) -> None:
        """Nạp file mới THAY TOÀN BỘ danh mục cũ, ghi bản sao nguyên văn."""
        self.store.kv_set(TRAN_KEY, {"rows": rows, "ts": int(__import__("time").time() * 1000), "at": now_vn(),
                                     "file": Path(path).name})
        dst = self.store.paths.danhmuc / TRAN_FILE_LUU
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(str(path), str(dst))

    def export(self) -> Path:
        d = self.load()
        if not d:
            raise TranTheError("Chưa nạp danh mục tràn thẻ.")
        aoa = [TRAN_HEAD] + [[i, k, v["ten"], v["t"], v.get("dk", "")] for i, (k, v) in enumerate(sorted(d["rows"].items()), 1)]
        return write_xlsx_multi(self.store.paths.danhmuc / TRAN_FILE_XUAT,
                                [{"name": TRAN_SHEET, "aoa": aoa, "widths": [6, 12, 40, 20, 40]}])
