"""Test lớp điều khiển trình duyệt trên Chromium thật + trang giả lập. Cần biến môi trường BO600_TEST_CHROME=<đường dẫn chrome>.
(Có thể thêm BO600_TEST_CHROME_LD=<LD_LIBRARY_PATH> và BO600_TEST_CHROME_ARGS=<cờ, cách nhau dấu cách>.)"""
import os
import time
from pathlib import Path

import pytest

pytest.importorskip("playwright")
CHROME = os.environ.get("BO600_TEST_CHROME")
if not CHROME or not Path(CHROME).is_file():
    pytest.skip("đặt BO600_TEST_CHROME để chạy test trình duyệt", allow_module_level=True)

from bo600.browser import BrowserSession, GateTimeout, NotReady, Target, cdp_up, launch_chrome
from bo600.runner import StopRequested
import fake_site

PORT = 9351
OD = {"langMs": 150, "nhipMin": 40, "nhipMax": 80, "toiDaGiay": 20, "yeuCauCu": 15000, "domKhongLangSau": 5000}


@pytest.fixture(scope="module")
def chrome(tmp_path_factory):
    args = os.environ.get("BO600_TEST_CHROME_ARGS", "--headless=shell --no-sandbox --disable-gpu --disable-dev-shm-usage").split()
    env = {"LD_LIBRARY_PATH": os.environ["BO600_TEST_CHROME_LD"]} if os.environ.get("BO600_TEST_CHROME_LD") else None
    launch_chrome(tmp_path_factory.mktemp("prof"), PORT, chrome_path=CHROME, extra_args=args, env=env)
    yield PORT
    # Chrome do test mở: để tiến trình kết thúc cùng pytest (đã tách phiên)
    import urllib.request, json
    try:
        ws = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/version").read())["webSocketDebuggerUrl"]
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
            b.new_browser_cdp_session().send("Browser.close")
    except Exception:
        pass


@pytest.fixture(scope="module")
def site():
    srv, base = fake_site.start()
    yield srv, base
    srv.shutdown()


@pytest.fixture
def br(chrome):
    s = BrowserSession(chrome, od=OD).__enter__()
    for p in s.pages():
        if p.url.startswith("http://127.0.0.1:") and str(PORT) not in p.url:
            p.close()
    yield s
    s.close()


def open_tab(br, base, query="", role="t"):
    br.tabs.pop(role, None)
    for p in br.pages():
        if base in p.url:
            p.close()
    page = br.ctx.new_page()
    page.goto(f"{base}/{query}", wait_until="domcontentloaded")
    from bo600.browser.tab import Tab
    t = Tab(br, page, role)
    br.tabs[role] = t
    return t


def test_ket_noi_va_cai_runtime(br, site):
    t = open_tab(br, site[1])
    assert br.info()["version"]
    assert t.page.evaluate("typeof window.__bo600rt.find") == "function"     # runtime đã được cài vào trang
    t.goto(site[1] + "/?again=1")                                            # tài liệu mới: init script cài lại
    assert t.page.evaluate("typeof window.__bo600rt.probe") == "function"


def test_gate_cho_lop_dang_tai_va_yeu_cau(br, site):
    t = open_tab(br, site[1])
    t.bam("#btn-load")
    t0 = time.monotonic()
    t.cho_on_dinh("#status")
    assert time.monotonic() - t0 >= 1.0
    assert t.text("#status") == "done"                           # cổng chỉ qua khi hết lớp tải và hết yêu cầu


def test_phan_tu_hien_muon(br, site):
    t = open_tab(br, site[1], "?late=700")
    t0 = time.monotonic()
    t.bam("#late", ten="nút hiện muộn")
    assert time.monotonic() - t0 >= 0.6
    t.cho_on_dinh("#status")
    assert t.text("#status") == "late-clicked"


def test_phan_tu_bi_che(br, site):
    t = open_tab(br, site[1], "?cover=900")
    t.bam("#target", ten="nút Đích")
    gone = t.page.evaluate("window.__coverGone")
    clicked = t.page.evaluate("window.__clicks.target")
    assert gone and clicked and clicked >= gone                  # chỉ bấm sau khi lớp che biến mất


def test_het_han_bao_loi_HT_khong_bam_mo(br, site):
    t = open_tab(br, site[1], "?stuck=1")
    with pytest.raises(GateTimeout) as e:
        t.bam("#target", toi_da=1.2, viec="thử")
    assert "[HT]" in str(e.value) and "màn hình đang tải" in str(e.value) and 'ở bước "thử"' in str(e.value)
    assert t.page.evaluate("window.__clicks.target") is None


def test_phan_tu_bi_khoa_va_nhanh(br, site):
    t = open_tab(br, site[1])
    with pytest.raises(GateTimeout) as e:
        t.cho_on_dinh("#locked", toi_da=0.8)
    assert "đang bị khóa" in str(e.value)
    with pytest.raises(NotReady):
        t.san_sang("#locked", toi_da=0.5, ten="nút Khóa")
    assert t.san_sang("#target") is not None


def test_dien_ban_su_kien_input_va_change(br, site):
    t = open_tab(br, site[1])
    t.dien("#txt", "abc123")
    assert t.page.evaluate("window.__events") == ["input:abc123", "change:abc123"]
    t.dien_n("#txt", "xyz")
    assert t.page.evaluate("document.getElementById('txt').value") == "xyz"


def test_hash_va_doc_phan_hoi_mang(br, site):
    t = open_tab(br, site[1])
    since = time.monotonic()
    t.goto_hash("#/a")
    hit = t.net.find("/api/list", since)
    for _ in range(40):
        if hit:
            break
        t.sleep(100)
        hit = t.net.find("/api/list", since)
    assert hit and hit.status == 200
    t.cho_on_dinh("#lst", ten="bảng")
    assert hit.json() == {"rows": ["x", "y", "z"]}
    t.goto_hash("#/b")
    assert t.text("#pb") == "Trang B"


def test_bo_nghe_phan_hoi(br, site):
    t = open_tab(br, site[1])
    got = []
    t.net.on_response(r"/api/list", lambda h: got.append(h.json()))
    t.goto_hash("#/a")
    t.cho_on_dinh("#lst")
    t.sleep(100)
    assert got == [{"rows": ["x", "y", "z"]}]


def test_chan_lenh_luu(br, site):
    srv, _ = site
    srv.saves.clear()
    t = open_tab(br, site[1])
    t.net.block(r"/api/importTbb/import", label="ktn")
    t.bam("#btn-save"); t.sleep(600)
    assert srv.saves == [] and len(t.net.blocked) == 1 and t.text("#status") == "loi-chan"
    t.net.unblock_all()
    t.bam("#btn-save"); t.sleep(600)
    assert len(srv.saves) == 1 and t.text("#status") == "saved"
    hit = t.net.find("/api/importTbb/import", method="POST")
    assert hit and hit.json() == {"ok": True} and '"rows"' in hit.post_data()


def test_tai_ve_va_tai_len(br, site, tmp_path):
    t = open_tab(br, site[1])
    out = t.tai_ve(lambda: t.bam("#dl"), tmp_path / "x" / "mau.xlsx")
    assert out.read_bytes() == b"FAKEXLSX"
    f = tmp_path / "len.xlsx"; f.write_bytes(b"1")
    t.tai_len("#file", f)
    assert t.page.evaluate("window.__events") == ["file:len.xlsx"]


def test_tab_theo_vai_va_ngat_ket_noi_khong_dong_chrome(chrome, site):
    with BrowserSession(chrome, od=OD) as s:
        page = s.ctx.new_page(); page.goto(site[1] + "/?x=1")
        t = s.tab("tst", f"127.0.0.1:{site[1].rsplit(':', 1)[1]}")
        assert t.page.url.startswith(site[1])
        assert s.tab("tst", "khong-co-gi") is t
        with pytest.raises(LookupError):
            s.tab("tnhs", "tnhs.bhxh.gov.vn", mo_moi=False)
    assert cdp_up(chrome)                                         # đóng phiên không đóng Chrome


def test_bam_dung_dung_luc_bam_dung(chrome, site):
    class Stop(Exception): pass
    n = {"i": 0}
    def stop():
        n["i"] += 1
        if n["i"] > 6:
            raise StopRequested()
    with BrowserSession(chrome, od=OD, stop_check=stop) as s:
        t = open_tab(s, site[1], "?stuck=1")
        with pytest.raises(StopRequested):
            t.bam("#target", toi_da=30)


def test_cho_th_khong_cho_giao_dien_lang(br, site):
    t = open_tab(br, site[1])
    t.bam("#btn-load")
    t0 = time.monotonic()
    t.cho_th("#status")                                           # chờ hết tải + hết yêu cầu mới, không nghỉ nhịp
    assert 0.9 <= time.monotonic() - t0 < 3
    t = open_tab(br, site[1], "?stuck=1")
    with pytest.raises(GateTimeout):
        t.cho_th("#target", toi_da=0.8)


def test_target_theo_chu_va_lay(br, site):
    t = open_tab(br, site[1])
    assert t.text(Target(css="button", text="đích", exact=True)) == "Đích"
    assert t.exists(Target(css="button", rx="^Lư")) and not t.exists(Target(css="button", text="không có")) 
    assert t.text(Target(lay=lambda p: p.query_selector("#target"))) == "Đích"
    el = t.cho_on_dinh(Target(text="Tải file"))                      # css mặc định '*' chọn phần tử trong cùng
    assert el.evaluate("e => e.id") == "dl"
