"""Bước 1 (Đơn vị quản lý): phần thuần + điều phối (trình duyệt giả) + trang giao diện."""
import contextlib
from pathlib import Path

import pytest
from openpyxl import Workbook

from bo600.runner import Runner, StepContext, StopRequested
from bo600.steps import donvi as D

HEAD = ["STT", "Mã ĐV", "Tên đơn vị", "a", "b", "c", "d", "e", "Chuyên quản"]


def ds_xlsx(path, rows):
    wb = Workbook()
    ws = wb.active
    ws.append(["DANH SÁCH ĐƠN VỊ"])
    ws.append(HEAD)
    for i, (ma, cq) in enumerate(rows, 1):
        ws.append([i, ma, "Đơn vị " + ma, "", "", "", "", "", cq])
    wb.save(str(path))
    return Path(path)


# ---------- phần thuần ----------
def test_doi_chieu_thua_thieu():
    assert D.doi_chieu(["001a", "002B"], ["001A", " 003C ", "'004D"]) == (["003C", "004D"], ["002B"])
    assert D.doi_chieu([], []) == ([], [])


def test_dam_bao_xlsx(tmp_path):
    x = ds_xlsx(tmp_path / "a.xlsx", [("001A", "Khoa")])
    assert D.dam_bao_xlsx(x) == x
    (tmp_path / "rac.xlsx").write_bytes(b"khong phai excel")
    with pytest.raises(D.DonViError):
        D.dam_bao_xlsx(tmp_path / "rac.xlsx")


def test_dam_bao_xlsx_file_xlsx_that_dat_duoi_xls(tmp_path):
    """TST lưu file .xlsx thật nhưng đặt đuôi .xls: openpyxl từ chối theo đuôi -> phải chép sang .xlsx (lỗi gặp khi chạy thật)."""
    from bo600.d02_io import codes_of_cq
    x = ds_xlsx(tmp_path / "goc.xlsx", [("001A", "Khoa"), ("001B", "Khoa"), ("777X", "Lan")])
    xls = tmp_path / "DsDonVi_2026-10-24.xls"
    xls.write_bytes(x.read_bytes())
    with pytest.raises(Exception, match="old .xls"):                       # đọc thẳng như trước đây thì lỗi
        codes_of_cq(xls, "Khoa")
    out = D.dam_bao_xlsx(xls)
    assert out.suffix == ".xlsx" and out != xls and xls.exists()           # file gốc giữ nguyên
    assert codes_of_cq(out, "Khoa") == {"001A", "001B"}


def test_dam_bao_xlsx_doi_xls_cu(tmp_path):
    xlwt = pytest.importorskip("xlwt")
    pytest.importorskip("xlrd")
    wb = xlwt.Workbook()
    ws = wb.add_sheet("S")
    for c, v in enumerate(HEAD):
        ws.write(0, c, v)
    for c, v in enumerate([1, "001A", "Đơn vị", "", "", "", "", "", "Khoa"]):
        ws.write(1, c, v)
    wb.save(str(tmp_path / "ds.xls"))
    from bo600.d02_io import codes_of_cq
    assert codes_of_cq(D.dam_bao_xlsx(tmp_path / "ds.xls"), "Khoa") == {"001A"}


@pytest.mark.parametrize("r,frag", [
    ({"err": "trong"}, "Chưa có tên chuyên quản"),
    ({"err": "khong_co", "ten": "Khoa", "goiY": ["Khoa A", "Khoa B"]}, "Khoa A; Khoa B"),
    ({"err": "nhieu", "ten": "Khoa"}, "khớp nhiều tên"),
    ({"err": "khong_dien", "ten": "Khoa"}, "không điền được"),
    ({"err": "khong_ma", "ten": "Khoa"}, "không có mã nào"),
])
def test_loi_chuyen_quan(r, frag):
    assert frag in D.loi_chuyen_quan(r)


# ---------- điều phối: trình duyệt + TIC giả ----------
class FakeBr(contextlib.AbstractContextManager):
    def __exit__(self, *a):
        return False


def make_ctx(store, socai, cfg):
    return StepContext(store, socai, cfg, Runner(store, socai, cfg), "dv")


@pytest.fixture
def fake_browser(monkeypatch):
    """Thay phần chạm trình duyệt: ghi lại lời gọi, trả kết quả TIC do test đặt."""
    st = {"calls": [], "managed": ["001A", "001B", "009Z"], "cq_used": "Khoa", "xuat": None, "loi": None}
    import bo600.steps as S
    monkeypatch.setattr(S, "open_session", lambda ctx: FakeBr())
    monkeypatch.setattr(D, "mo_cong", lambda br, vai, h=None: st["calls"].append(("mo_cong", vai, h)) or vai)

    def xuat(ctx, tst, thu_muc):
        st["calls"].append(("xuat", str(thu_muc)))
        p = ds_xlsx(Path(thu_muc) / "DsDonVi_test.xlsx", [("001A", "Khoa"), ("001B", "Khoa"), ("001C", "Khoa"), ("777X", "Lan")])
        return p

    def nap(ctx, tnhs, file, cq):
        st["calls"].append(("nap", str(file), cq))
        if st["loi"]:
            raise D.DonViError(st["loi"])
        return {"read_msg": "Đọc xong 4 dòng", "imp_msg": "Thêm 3 mã", "cq_used": st["cq_used"], "managed": st["managed"]}
    monkeypatch.setattr(D, "xuat_tu_tst", xuat)
    monkeypatch.setattr(D, "nap_vao_tic", nap)
    return st


def test_chay_voi_file_da_chon(store, socai, cfg, tmp_path, fake_browser):
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Khoa"), ("001B", "Khoa"), ("001C", "Khoa"), ("777X", "Lan")])
    store.kv_set("donvi", {"file": str(f), "cq": "Khoa"})
    cfg.save_settings({"cq": "Khoa"})
    ctx = make_ctx(store, socai, cfg)
    D.chay_don_vi(ctx, None)
    assert [c[0] for c in fake_browser["calls"]] == ["mo_cong", "nap"]            # không xuất từ TST
    assert fake_browser["calls"][1][1:] == (str(f), "Khoa")
    kv = store.kv_get("donvi")
    assert kv["codes"] == ["001A", "001B", "001C"] and kv["tic"]["n_giu"] == 3
    assert kv["tic"]["thua"] == ["009Z"] and kv["tic"]["thieu"] == ["001C"]
    log = "\n".join(ctx.lines)
    assert "mã thừa: 1; mã thiếu: 1" in log and "CẢNH BÁO: mã có trong file nhưng TIC chưa giữ: 001C" in log


def test_chay_tu_xuat_tst_va_luu_ten_cq_neu_trong(store, socai, cfg, fake_browser):
    cfg.save_settings({"dv_tu_xuat": True})                                       # chưa có tên chuyên quản
    fake_browser["cq_used"] = "Khoa"
    ctx = make_ctx(store, socai, cfg)
    D.chay_don_vi(ctx, None)
    assert [c[0] for c in fake_browser["calls"]] == ["mo_cong", "xuat", "mo_cong", "nap"]
    assert fake_browser["calls"][0][1:] == ("tst", "#/dmDonVis") and fake_browser["calls"][2][1:] == ("tnhs", "#/ho-so-cho-thu-ly")
    assert Path(store.kv_get("donvi")["file"]).parent == store.paths.danhmuc
    assert cfg.settings()["cq"] == "Khoa"                                          # nhớ tên TIC đã dùng
    assert store.kv_get("donvi")["tic"]["tu_xuat"] is True


def test_thieu_file_bao_loi_ro(store, socai, cfg, fake_browser):
    with pytest.raises(D.DonViError, match="Chưa chọn file"):
        D.chay_don_vi(make_ctx(store, socai, cfg), None)
    assert fake_browser["calls"] == []                                             # chưa chạm trình duyệt


def test_loi_tic_khong_ghi_ket_qua(store, socai, cfg, tmp_path, fake_browser):
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Khoa")])
    store.kv_set("donvi", {"file": str(f), "cq": "Khoa"})
    fake_browser["loi"] = "TIC: tên chuyên quản không có trong file"
    with pytest.raises(D.DonViError):
        D.chay_don_vi(make_ctx(store, socai, cfg), None)
    assert "tic" not in store.kv_get("donvi")


def test_khong_doc_duoc_file_van_ghi_ket_qua_tic(store, socai, cfg, tmp_path, fake_browser):
    f = tmp_path / "ds.xlsx"
    f.write_bytes(b"PK-hong")                                                      # TIC nạp được nhưng ta không đọc được
    store.kv_set("donvi", {"file": str(f), "cq": "Khoa"})
    ctx = make_ctx(store, socai, cfg)
    D.chay_don_vi(ctx, None)
    kv = store.kv_get("donvi")
    assert kv["tic"]["n_giu"] == 3 and kv["tic"]["thua"] == [] and "Không đối chiếu được" in "\n".join(ctx.lines)


def test_runner_goi_dung_handler(store, socai, cfg, tmp_path, fake_browser):
    from bo600.steps import register_all
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Khoa")])
    store.kv_set("donvi", {"file": str(f), "cq": "Khoa"})
    r = Runner(store, socai, cfg)
    register_all(r)
    assert r.has("dv") and r.has("tn") and r.has("tai")
    import time
    assert r.run("dv")
    t0 = time.time()
    while r.busy and time.time() - t0 < 10:
        time.sleep(0.05)
    msgs = []
    while not r.q.empty():
        msgs.append(r.q.get())
    assert ("done", ["dv"], None) in msgs
    assert any(m[0] == "log" and "XONG 1. Đơn vị quản lý" in m[1] for m in msgs)
