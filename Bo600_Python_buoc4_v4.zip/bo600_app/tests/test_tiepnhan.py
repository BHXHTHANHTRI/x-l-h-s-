"""Bước 2 (Tiếp nhận): phần thuần, ghi sổ cái lệnh TNHS, điều phối với trình duyệt giả. Test trên Chromium thật: test_tiepnhan_browser.py."""
import contextlib
import json

import pytest

from bo600.runner import Runner, StepContext
from bo600.steps import tiepnhan as T
from bo600.steps.tnhs_vai import vai_cua
from bo600.tnhs_socai import deep_get_ci, entry_tu_lenh, parse_loose, plain


# ---------- phần thuần ----------
def test_doc_so_tich():
    assert T.doc_so_tich("Đã tích 12 hồ sơ") == 12
    assert T.doc_so_tich("Đã tích 3 hồ sơ, bỏ qua 2") == 3
    assert T.doc_so_tich("") == 0 and T.doc_so_tich("Không khớp") == 0


def test_con_trong_bang():
    bang = "1 100/2026/1 Đơn vị A 2 101/2026/2 Đơn vị B"
    assert T.con_trong_bang(["100/2026/1", "999/2026/9", ""], bang) == ["100/2026/1"]
    assert T.con_trong_bang([], bang) == []


def test_tom_tat():
    assert T.tom_tat(None) == "Chưa chạy lần nào."
    t = T.tom_tat({"at": "24/10/2026", "total": 5, "rounds": 2, "ok": False, "note": "bấm Dừng"})
    assert "5 hồ sơ" in t and "2 lượt" in t and "Dừng giữa chừng" in t and "bấm Dừng" in t
    assert "Hoàn thành" in T.tom_tat({"total": 0, "rounds": 0, "ok": True})


@pytest.mark.parametrize("label,role", [("Bộ phận Quản lý thu", "thu"), ("Bộ phận Quản lý thu (112)", "thu"),
                                        ("Bộ phận Cấp sổ-thẻ", "cst"), ("Bộ phận Cấp  sổ thẻ", "cst"), ("Bộ phận X", ""), ("", "")])
def test_vai_cua(label, role):
    assert vai_cua(label) == role


# ---------- ghi sổ cái lệnh TNHS ----------
REQ_TN = json.dumps({"hanhdong": "1", "sohoso": "100/2026/1", "dmphongbanguiid": "112", "currenttrangthaixuly": "1"})


def test_parse_loose_va_deep_get():
    assert parse_loose('{"a": 1}') == {"a": 1}
    assert parse_loose("a=1&b=%7B%22c%22%3A2%7D") == {"a": 1, "b": {"c": 2}}
    assert parse_loose("") is None
    o = {"Data": '{"SoHoSo": "5/2026/1"}', "x": [{"hanhdong": 3}]}
    assert deep_get_ci(o, "sohoso") == "5/2026/1" and deep_get_ci(o, "HANHDONG") == 3 and deep_get_ci(o, "khong") is None


def test_entry_tiep_nhan_thanh_cong():
    e = entry_tu_lenh(REQ_TN, json.dumps({"code": 0, "msg": "Tiếp nhận thành công"}), 200, 1_700_000_000_000, "may", "tn", "#/ho-so-cho-thu-ly")
    assert (e["loai"], e["bophan"], e["ok"], e["viec"], e["ketqua"]) == ("tiepnhan", "Thu", True, "Tiếp nhận (Thu)", "Đã tiếp nhận")
    assert e["sohosos"] == ["100/2026/1"] and e["who"] == "may" and e["he"] == "TNHS" and e["page"] == "#/ho-so-cho-thu-ly"


def test_entry_tiep_nhan_that_bai_va_suy_loai_theo_trang_thai():
    e = entry_tu_lenh(REQ_TN, json.dumps({"code": 1, "msg": "Sai bộ phận"}), 200, 1)
    assert e["ok"] is False and e["ketqua"] == "Không thành công: Sai bộ phận"
    e = entry_tu_lenh(json.dumps({"sohoso": "1/2026/1", "currenttrangthaixuly": "1", "buoc": "2"}), json.dumps({"msg": "Thành công"}), 200, 1)
    assert e["loai"] == "tiepnhan" and e["ok"] is True and e["bophan"] == "Thu"     # không có hanhdong: theo currenttrangthaixuly, msg
    assert entry_tu_lenh(REQ_TN, "{}", 500, 1)["ok"] is False


def test_entry_xu_ly_va_phieu():
    xl = json.dumps({"hanhdong": "3", "sohoso": "7/2026/1", "loaidanhgia": "3", "dmphongbanguiid": "109"})
    e = entry_tu_lenh(xl, json.dumps({"code": 0}), 200, 1)
    assert (e["loai"], e["bophan"], e["danhgia"], e["ketqua"]) == ("xuly", "Cấp sổ-thẻ", "3", "Không hợp lệ")
    ph = json.dumps({"sohoso": "7/2026/1", "noidungyeucauhths": "<p>Bổ sung <b>ĐKKD</b></p>", "lydo": "<p>Lý do</p>", "madonvi": "001A"})
    e = entry_tu_lenh(ph, json.dumps({"code": 0}), 200, 1)
    assert (e["loai"], e["viec"], e["ok"], e["denghi"], e["lydo"], e["madv"]) == ("phieu", "Phiếu hướng dẫn", True, "Bổ sung ĐKKD", "Lý do", "001A")
    assert plain("<p>a&nbsp;b</p>", 10) == "a b"


def test_entry_vao_so_cai_va_thanh_tinh_theo_ho_so(socai):
    e = entry_tu_lenh(REQ_TN, json.dumps({"code": 0}), 200, 1_700_000_000_000)
    assert socai.add(e)["added"] is True
    assert [x["loai"] for x in socai.tnhs_events("100/2026/1")] == ["tiepnhan"]


# ---------- điều phối: trình duyệt giả ----------
class FakeBr(contextlib.AbstractContextManager):
    def __exit__(self, *a):
        return False


class FakeTab:
    """Đủ phương thức mà handler gọi ngoài các hàm đã monkeypatch."""
    def __init__(self):
        self.calls = []
        self.net = type("N", (), {"on_response": lambda s, *a: None, "process": lambda s: None, "clear_listeners": lambda s: None})()
    def tu_oke(self, on): self.calls.append(("oke", on))
    def goto_hash(self, h): self.calls.append(("hash", h))
    def ho_tai(self): pass
    def sleep(self, ms): pass
    class page:
        @staticmethod
        def evaluate(js, *a): return True              # JS_TIC_HIEN


@pytest.fixture
def fake(monkeypatch):
    st = {"tab": FakeTab(), "luot": [], "vai": 0, "trang_sau": False}
    import bo600.steps as S
    monkeypatch.setattr(S, "open_session", lambda ctx: FakeBr())
    monkeypatch.setattr(T, "mo_cong", lambda br, vai, h=None: st["tab"])
    monkeypatch.setattr(T, "dam_bao_thu", lambda ctx, tab, why="": st.__setitem__("vai", st["vai"] + 1))
    monkeypatch.setattr(T, "dat_co_trang", lambda ctx, tab, n=100: None)
    monkeypatch.setattr(T, "mot_luot", lambda ctx, tab: st["luot"].pop(0))
    monkeypatch.setattr(T, "sang_trang_sau", lambda tab: st["trang_sau"])
    return st


def mkctx(store, socai, cfg, chain=False):
    cfg.save_settings({"delay_ms": 500})
    return StepContext(store, socai, cfg, Runner(store, socai, cfg), "tn", chain=chain)


def done(so, *hs):
    return {"status": "done", "ticked": len(hs), "hoso": list(hs), "toasts": ["Tiếp nhận thành công"], "rows_before": 9, "rows_after": 4, "still": []}


def test_chay_het_ho_so_ghi_ket_qua(store, socai, cfg, fake):
    fake["luot"] = [done(1, "1/2026/1", "2/2026/1"), done(2, "3/2026/1"), {"status": "empty"}]
    ctx = mkctx(store, socai, cfg)
    T.chay_tiep_nhan(ctx, None)
    kv = store.kv_get("tiepnhan")
    assert (kv["total"], kv["rounds"], kv["ok"]) == (3, 2, True) and kv["hoso"] == ["1/2026/1", "2/2026/1", "3/2026/1"]
    assert fake["vai"] == 1 and ("hash", T.TNHS_DANG_THU_LY) in fake["tab"].calls and fake["tab"].calls[-1] == ("oke", False)
    log = "\n".join(ctx.lines)
    assert "Lượt 1: tích 2 hồ sơ" in log and "Danh sách Chờ thụ lý trống" in log and "Hoàn thành" in log


def test_nomatch_sang_trang_sau_roi_het(store, socai, cfg, fake):
    fake["luot"] = [{"status": "nomatch", "msg": "Không khớp"}, done(1, "1/2026/1"), {"status": "nomatch", "msg": "Không khớp 2"}]
    fake["trang_sau"] = True
    ctx = mkctx(store, socai, cfg)
    n = {"c": 0}
    orig = T.sang_trang_sau
    def trang_sau(tab):                                      # lần đầu có trang sau, lần hai hết
        n["c"] += 1
        return n["c"] == 1
    T.sang_trang_sau = trang_sau
    try:
        T.chay_tiep_nhan(ctx, None)
    finally:
        T.sang_trang_sau = orig
    log = "\n".join(ctx.lines)
    assert "chuyển sang trang sau" in log and "Không còn hồ sơ thuộc danh sách đơn vị quản lý (Không khớp 2)" in log
    assert store.kv_get("tiepnhan")["total"] == 1


def test_khong_xac_nhan_thi_dung_va_ghi_ket_qua_do(store, socai, cfg, fake):
    fake["luot"] = [done(1, "1/2026/1"), {"status": "noconfirm", "ticked": 2, "hoso": ["2/2026/1"], "toasts": ["Lỗi X"]}]
    ctx = mkctx(store, socai, cfg)
    with pytest.raises(T.TiepNhanError, match="Không xác nhận được"):
        T.chay_tiep_nhan(ctx, None)
    kv = store.kv_get("tiepnhan")
    assert kv["ok"] is False and kv["total"] == 1 and "Không xác nhận" in kv["note"]
    assert "Lỗi X" in "\n".join(ctx.lines) and fake["tab"].calls[-1] == ("oke", False)   # vẫn tắt tự bấm OKE


def test_con_ho_so_sau_tiep_nhan_thi_dung_tranh_lap(store, socai, cfg, fake):
    r = done(1, "1/2026/1", "2/2026/1")
    r["still"] = ["2/2026/1"]
    fake["luot"] = [r]
    with pytest.raises(T.TiepNhanError, match="vẫn còn 1 hồ sơ"):
        T.chay_tiep_nhan(mkctx(store, socai, cfg), None)


def test_toi_da_40_luot(store, socai, cfg, fake):
    fake["luot"] = [done(i, f"{i}/2026/1") for i in range(60)]
    ctx = mkctx(store, socai, cfg)
    T.chay_tiep_nhan(ctx, None)
    assert store.kv_get("tiepnhan")["rounds"] == 40 and "giới hạn 40 lượt" in "\n".join(ctx.lines)


def test_bam_dung_giua_chung_ghi_dung_ket_qua(store, socai, cfg, fake, monkeypatch):
    from bo600.runner import StopRequested
    def luot(ctx, tab):
        if fake["luot"]:
            return fake["luot"].pop(0)
        raise StopRequested()
    fake["luot"] = [done(1, "1/2026/1")]
    monkeypatch.setattr(T, "mot_luot", luot)
    with pytest.raises(StopRequested):
        T.chay_tiep_nhan(mkctx(store, socai, cfg), None)
    kv = store.kv_get("tiepnhan")
    assert kv["total"] == 1 and kv["ok"] is False and kv["note"] == "bấm Dừng"


def test_khong_co_tic_chay_rieng_bao_loi_trong_chuoi_thi_bo_qua(store, socai, cfg, fake, monkeypatch):
    from bo600.browser import NotReady
    from bo600.steps.donvi import KhongCoTic
    tab = fake["tab"]
    tab.page = type("P", (), {"evaluate": staticmethod(lambda js, *a: False)})        # JS_TIC_HIEN = False
    def khong_thay(target, **kw):
        raise NotReady("x")
    tab.san_sang = khong_thay
    with pytest.raises(T.TiepNhanError, match="Không thấy tiện ích TIC"):
        T.chay_tiep_nhan(mkctx(store, socai, cfg), None)
    assert store.kv_get("tiepnhan")["ok"] is False
    ctx = mkctx(store, socai, cfg, chain=True)
    T.chay_tiep_nhan(ctx, None)                                                      # trong chuỗi: không ném lỗi
    assert "BỎ QUA bước Tiếp nhận" in "\n".join(ctx.lines)
    kv = store.kv_get("tiepnhan")
    assert kv["ok"] is True and kv["note"] == "bỏ qua: không có TIC"
    assert issubclass(KhongCoTic, Exception)


def test_runner_dang_ky_buoc_2_va_chuoi_bat_dau_tu_tn(store, socai, cfg, fake):
    from bo600.runner import CHUOI_MAC_DINH
    from bo600.steps import register_all
    assert CHUOI_MAC_DINH[0] == "tn"
    r = Runner(store, socai, cfg)
    register_all(r)
    assert r.has("tn")
    fake["luot"] = [{"status": "empty"}]
    import time
    assert r.run("tn")
    t0 = time.time()
    while r.busy and time.time() - t0 < 10:
        time.sleep(0.05)
    msgs = []
    while not r.q.empty():
        msgs.append(r.q.get())
    assert ("done", ["tn"], None) in msgs
    assert any(m[0] == "log" and "XONG 2. Tiếp nhận" in m[1] for m in msgs)
