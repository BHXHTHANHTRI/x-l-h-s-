"""Trang SPA giả lập kiểu TST/TNHS (AngularJS): lớp block-ui, yêu cầu chậm, phần tử hiện muộn, bị che, #hash, Lưu, tải file."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PAGE = """<!doctype html><html><head><meta charset=utf-8><title>Fake</title><style>
 .block-ui{position:fixed;left:0;top:0;width:100%;height:100%;background:rgba(255,255,255,.5);display:none;z-index:10}
 .block-ui.block-ui-visible{display:block}
 #cover{position:fixed;left:0;top:0;width:100%;height:100%;z-index:50}
 #late{display:none}
</style></head><body>
<div class="block-ui" id="bu"></div>
<h3>Trang thử</h3>
<button id="btn-load">Tải</button> <button id="btn-save">Lưu</button> <button id="target">Đích</button>
<button id="late">Hiện muộn</button> <button id="locked" disabled>Khóa</button> <a id="dl" href="/file.xlsx" download="mau.xlsx">Tải file</a>
<input id="txt"> <input type="file" id="file" style="display:none"> <div id="status"></div><div id="app"></div>
<script>
 const q = new URLSearchParams(location.search);
 const bu = document.getElementById('bu'), st = document.getElementById('status');
 window.__events = []; window.__clicks = {};
 function showLoading(ms){ bu.classList.add('block-ui-visible'); setTimeout(()=>bu.classList.remove('block-ui-visible'), ms); }
 if (q.get('stuck')) bu.classList.add('block-ui-visible');
 document.getElementById('btn-load').addEventListener('click', () => {
   showLoading(1200); fetch('/api/slow?ms=1200').then(r=>r.json()).then(()=>{ st.textContent='done'; });
 });
 document.getElementById('btn-save').addEventListener('click', () => {
   fetch('/api/importTbb/import', {method:'POST', body: JSON.stringify({rows:2})}).then(r=>r.json()).then(d=>{ st.textContent='saved'; }).catch(()=>{ st.textContent='loi-chan'; });
 });
 document.getElementById('target').addEventListener('click', () => { window.__clicks.target = Date.now(); });
 document.getElementById('late').addEventListener('click', () => { st.textContent='late-clicked'; });
 const txt = document.getElementById('txt');
 ['input','change'].forEach(t => txt.addEventListener(t, () => window.__events.push(t + ':' + txt.value)));
 document.getElementById('file').addEventListener('change', e => window.__events.push('file:' + e.target.files[0].name));
 if (q.get('late')) setTimeout(()=>{ document.getElementById('late').style.display='inline-block'; }, +q.get('late'));
 if (q.get('cover')) { const c=document.createElement('div'); c.id='cover'; document.body.appendChild(c);
   setTimeout(()=>{ c.remove(); window.__coverGone = Date.now(); }, +q.get('cover')); }
 function render(){
   const h = location.hash || '#/';
   const app = document.getElementById('app');
   if (h === '#/a') { showLoading(500); fetch('/api/list?delay=500').then(r=>r.json()).then(d=>{ app.innerHTML='<table id="lst"><tr>'+d.rows.map(x=>'<td>'+x+'</td>').join('')+'</tr></table>'; }); }
   else if (h === '#/b') { app.innerHTML = '<p id="pb">Trang B</p>'; }
   else app.innerHTML = '';
 }
 window.addEventListener('hashchange', render); render();
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json", headers=None):
        b = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/":
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if u.path == "/api/list":
            time.sleep(int(q.get("delay", ["0"])[0]) / 1000)
            return self._send(200, json.dumps({"rows": ["x", "y", "z"]}))
        if u.path == "/api/slow":
            time.sleep(int(q.get("ms", ["0"])[0]) / 1000)
            return self._send(200, json.dumps({"ok": True}))
        if u.path == "/file.xlsx":
            return self._send(200, b"FAKEXLSX", "application/octet-stream", {"Content-Disposition": 'attachment; filename="mau.xlsx"'})
        self._send(404, "{}")

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n)
        if self.path == "/api/importTbb/import":
            self.server.saves.append(body)
            return self._send(200, json.dumps({"ok": True}))
        self._send(404, "{}")


def start():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    srv.saves = []
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}"
