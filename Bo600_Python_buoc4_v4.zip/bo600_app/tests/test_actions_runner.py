import time
from pathlib import Path

import pytest
from openpyxl import load_workbook

from bo600 import duyet_actions as A
from bo600.config import QUY_TAC_MAC_DINH, SETTINGS_MAC_DINH
from bo600.d02_io import read_d02
from bo600.rules import da_tick
from bo600.runner import Runner
from conftest import make_row, write_d02

LOT = "2026-10-23"


def seed(store, socai, tmp_path, rows=None, so="123/2026"):
    src = write_d02(tmp_path / "src" / "ABC12302_102026.xlsx" if (tmp_path / "src").mkdir(exist_ok=True) is None else None,
                    rows or [make_row(), make_row(STT="2", HOTEN="Tran B", DIACHI="abc")])
    it = A.nap_d02_thu_cong(store, src, so, "abc123", "10/2026", LOT)
    lot, it = store.find_item(LOT, it["id"])
    dx = A.load_dx(store, socai, QUY_TAC_MAC_DINH, lot, it)
    return lot, it, dx


def fresh(store, lot, it):
    lot, it = store.find_item(lot["id"], it["id"])
    return lot, it


def test_nap_thu_cong_va_trung_so(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    assert it["madonvi"] == "ABC123" and it["rows"] == 2 and store.paths.item_path(LOT, it["file"]).is_file()
    assert dx["nhom"] == "sach" and len(dx["rows"]) == 2
    with pytest.raises(ValueError):
        A.nap_d02_thu_cong(store, tmp_path / "src" / "ABC12302_102026.xlsx", "123/2026", "X")
    assert A.doan_so_ho_so(read_d02(tmp_path / "src" / "ABC12302_102026.xlsx")) == "123/2026"


def test_load_dx_cache_va_tinh_lai_khi_sig_doi(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    assert A.load_dx(store, socai, QUY_TAC_MAC_DINH, lot, it)["at"] == dx["at"]       # dùng lại bản lưu
    A.set_cell(store, lot, it, dx, 0, "ML", "7000000")
    store.edit_item(LOT, it["id"], lambda i, l: i.update(f2Ts=5))                     # tra cứu mới -> sig đổi
    lot, it = fresh(store, lot, it)
    dx2 = A.load_dx(store, socai, QUY_TAC_MAC_DINH, lot, it)
    assert dx2["sig"] != dx["sig"] and dx2["rows"][0]["chot"]["ML"] == "7000000"      # giữ ô người đã sửa


def test_sua_o_va_khoa_dong_da_tich(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    assert A.set_cell(store, lot, it, dx, 0, "ML", "7000000") is None
    assert dx["rows"][0]["tay"]["ML"] is True
    assert A.set_cell(store, lot, it, dx, 0, "STT", "9") and A.set_cell(store, lot, it, dx, 0, "KHONGCO", "9")
    A.set_tick(store, lot, it, dx, 0, True)
    assert "bị khóa" in A.set_cell(store, lot, it, dx, 0, "ML", "1")
    # luật TINHLAI: TUTHANG = tháng hiện tại thì không nhận 'x'
    from bo600.util import thang_nay
    t = thang_nay(); mm = f"{(t - 1) % 12 + 1:02d}/{(t - 1) // 12}"
    assert A.set_cell(store, lot, it, dx, 1, "TUTHANG", mm) is None
    assert "không tính lãi" in A.set_cell(store, lot, it, dx, 1, "TINHLAI", "x")
    assert dx["rows"][1]["chot"]["TINHLAI"] == ""


def test_gui_hang_cho_can_tich_du(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    A.set_tick(store, lot, it, dx, 0, True)
    with pytest.raises(ValueError, match="chưa tích đủ"):
        A.gui_hang_cho(store, lot, it, dx)
    A.set_tick(store, lot, it, dx, None, True)
    assert da_tick(dx)["all"]
    A.set_cell  # (đã tích: không sửa được nữa)
    mota = A.gui_hang_cho(store, lot, it, dx)
    assert "2 dòng" in mota and "Sửa trong app" in mota
    lot, it = fresh(store, lot, it)
    assert it["q"]["kind"] == "import" and it["duyet"]["kq"].startswith("Import")
    out = store.paths.lot_dir(LOT) / "_import" / it["file"]
    T = read_d02(out)
    assert T.rows[1].o["DIACHI"] == "."                                               # giá trị chốt đã ghi
    assert (store.paths.res_dir(LOT) / "duyet.xlsx").is_file()
    assert A.khoa(it, dx) and A.rut_hang_cho(store, lot, it) is True
    lot, it = fresh(store, lot, it)
    assert it["q"] is None and not A.khoa(it, dx)
    assert A.rut_hang_cho(store, lot, it) is False


def test_tu_choi(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path, [make_row(MACV="nhân viên")])
    assert dx["nhom"] == "tuchoi"
    dx["tuChoi"]["deNghi"] = ""
    with pytest.raises(ValueError, match="lý do và đề nghị"):
        A.dat_tu_choi(store, lot, it, dx, True, 120)
    dx["tuChoi"]["deNghi"] = "Nộp lại"
    A.dat_tu_choi(store, lot, it, dx, True, 120)
    lot, it = fresh(store, lot, it)
    assert it["q"]["kind"] == "tuchoi" and it["q"]["notBefore"] - it["q"]["ts"] == 120000
    A.dat_tu_choi(store, lot, it, dx, False, 120)
    lot, it = fresh(store, lot, it)
    assert it["q"] is None and it["duyet"] is None


def test_truy_thu_dien_mau(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path, [make_row(TUTHANG="08/2026", NGAY_NOP_HS="05/10/2026")])
    A.set_cell(store, lot, it, dx, 0, "TUTHANG", "10/2026")
    A.set_truy_thu(store, lot, it, dx, True, None, SETTINGS_MAC_DINH["mau_phieu_truy_thu"])
    nd = dx["truyThu"]["noiDung"]
    assert "10/2026" in nd and "08/2026" in nd and "{" not in nd and dx["truyThu"]["on"]


def test_sua_bang_excel_vong_tron(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    f = A.mo_file_de_sua(store, lot, it, dx)
    assert f.is_file() and dx["excel"]["state"] == "dangsua" and A.khoa(it, dx)
    assert "GOC_DONVI" in load_workbook(f).sheetnames
    with pytest.raises(ValueError):                                                   # đang sửa ngoài: khóa tick
        A.set_tick(store, lot, it, dx, 0, True)
    # người sửa file (giữ GHICHU, ô chữ) rồi nạp lại
    wb = load_workbook(f); ws = wb["D02"]; S = read_d02(f)
    ws.cell(S.rows[0].sr, S.col("ML")).value = "8000000"; wb.save(f)
    assert A.nap_file_sua(store, lot, it, dx, f) == []
    assert dx["excel"]["state"] == "sansang" and dx["excel"]["nRows"] == 2
    assert dx["excel"]["rows"][0]["HOTEN"] == "Nguyen Van A"
    A.set_tick(store, lot, it, dx, None, True)
    assert da_tick(dx)["all"]
    assert "Excel (người sửa)" in A.gui_hang_cho(store, lot, it, dx)
    assert read_d02(store.paths.lot_dir(LOT) / "_import" / it["file"]).rows[0].o["ML"] == "8000000"


def test_nap_file_sua_sai_ten_va_thoi_sua(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    bad = write_d02(tmp_path / "khac.xlsx", [make_row()])
    assert "cần đúng file" in A.nap_file_sua(store, lot, it, dx, bad)[0]
    A.mo_file_de_sua(store, lot, it, dx)
    A.thoi_sua_ngoai(store, lot, it, dx)
    assert dx["excel"] is None


def test_nguoi_xac_nhan_va_danh_dau(store, socai, tmp_path):
    lot, it, dx = seed(store, socai, tmp_path)
    A.nguoi_import_thu_cong(store, socai, lot, it, da_xu_ly_tnhs=True)
    lot, it = fresh(store, lot, it)
    assert it["imp"]["kq"] == "xong" and socai.hit(it) and socai.tnhs_events("123/2026")
    A.danh_dau_nguoi_lam(store, LOT, it["id"], "ktn", True)
    assert fresh(store, lot, it)[1]["nguoiLam"]["ktn"]["at"]
    A.danh_dau_nguoi_lam(store, LOT, it["id"], "ktn", False)
    assert "ktn" not in fresh(store, lot, it)[1]["nguoiLam"]
    A.mo_lai(store, LOT, it["id"]); assert fresh(store, lot, it)[1]["reopenTs"] > 0


# ---------- runner ----------
def drain(r, timeout=3):
    out, t0 = [], time.time()
    while time.time() - t0 < timeout:
        m = r.q.get(timeout=timeout)
        out.append(m)
        if m[0] == "done":
            return out
    raise AssertionError("runner không kết thúc")


def test_runner_chay_va_bo_qua_buoc_chua_cai(store, socai, cfg):
    r = Runner(store, socai, cfg)
    seen = []
    r.register("tai", lambda ctx, items: (ctx.log("làm gì đó"), seen.append(ctx.key)))
    assert r.run(["tai", "ktn"]) is True
    msgs = drain(r)
    text = "\n".join(m[1] for m in msgs if m[0] == "log")
    assert seen == ["tai"] and "XONG 3. Tải D02" in text and "BỎ QUA 4. Kiểm tra nháp" in text
    assert msgs[-1][2] is None and list(store.paths.nhatky.glob("tai_*.txt"))


def test_runner_loi_va_dung(store, socai, cfg):
    r = Runner(store, socai, cfg)
    def hong(ctx, items): raise RuntimeError("hỏng")
    def cho(ctx, items):
        for _ in range(100):
            ctx.sleep(0.05)
    r.register("tai", hong); r.register("ktn", cho)
    r.run(["tai", "ktn"]); msgs = drain(r)
    assert msgs[-1][2] == "hỏng" and not any("BẮT ĐẦU 4" in m[1] for m in msgs if m[0] == "log")   # lỗi thì dừng chuỗi
    r.run("ktn"); time.sleep(0.1)
    assert r.busy and r.run("ktn") is False                                           # đang bận
    r.stop(); msgs = drain(r)
    assert msgs[-1][2] == "stop" and not r.busy
