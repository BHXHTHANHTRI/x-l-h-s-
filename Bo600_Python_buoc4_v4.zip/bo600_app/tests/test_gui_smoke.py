"""Kiểm tra giao diện thật (cần Tkinter + màn hình). Không có màn hình thì bỏ qua:  xvfb-run -a python -m pytest -q tests"""
import time

import pytest

tk = pytest.importorskip("tkinter")
try:
    _r = tk.Tk(); _r.destroy()
except tk.TclError:
    pytest.skip("không có màn hình (chạy bằng xvfb-run)", allow_module_level=True)
pytest.importorskip("ttkbootstrap")

from bo600 import duyet_actions as A
from bo600.ui.app import App, NAV
from conftest import make_row, write_d02

LOT = "2026-10-23"


@pytest.fixture
def app(tmp_path):
    a = App(tmp_path / "Bo600")
    (tmp_path / "s").mkdir()
    data = [([make_row(MACV="nhân viên"), make_row(STT="2", HOTEN="B", ML="4000000")], "123/2026", "ABC123"),
            ([make_row(GHICHU="HS 456/2026"), make_row(STT="2", HOTEN="C", GHICHU="HS 456/2026", TUTHANG="08/2026", NGAY_NOP_HS="05/10/2026")], "456/2026", "XYZ789"),
            ([make_row(GHICHU="HS 789/2026")], "789/2026", "KLM555")]
    for r, so, dv in data:
        A.nap_d02_thu_cong(a.store, write_d02(tmp_path / "s" / f"{dv}.xlsx", r), so, dv, "10/2026", LOT)
    a.root.update()
    yield a
    a.on_close()


def pump(app, n=3):
    for _ in range(n):
        app.root.update_idletasks(); app.root.update(); time.sleep(0.05)


def test_moi_trang_mo_duoc(app):
    for key, _t in NAV:
        if key:
            app.show(key); pump(app, 1)
    app.show("tiendo")
    assert len(app.pages["tiendo"].tree.get_children()) == 3


def test_badge_va_module(app):
    app._badges()
    assert "(3)" in app.nav_btns["duyet"][0].cget("text") and "(tắt)" not in app.nav_btns["imp"][0].cget("text")
    app.cfg.save_settings({"modules": {"duyet": False}})
    app._badges()
    assert "(tắt)" in app.nav_btns["imp"][0].cget("text")


def test_duyet_phan_nhom_va_chon_tab(app):
    app.show("duyet"); d = app.pages["duyet"]; pump(app)
    assert sorted((e["it"]["sohoso"], e["tab"]) for e in d.entries) == [("123/2026", "tuchoi"), ("456/2026", "nguoi"), ("789/2026", "sach")]
    d.nb.select(1); pump(app)
    assert d.cur["it"]["sohoso"] == "789/2026" and str(d.btn["gui"].cget("state")) == "disabled"   # chưa tích đủ


def test_tich_gui_hang_cho_va_khoa(app):
    app.show("duyet"); d = app.pages["duyet"]; d.nb.select(1); pump(app)
    d._tick(None, True); pump(app)
    assert str(d.btn["gui"].cget("state")) == "normal"
    d._gui_one(); pump(app)
    lot, it = app.store.find_item(LOT, d.cur["it"]["id"])
    assert it["q"]["kind"] == "import" and (app.store.paths.lot_dir(LOT) / "_import" / it["file"]).is_file()
    assert str(d.btn["rut"].cget("state")) == "normal" and str(d.btn["tick_all"].cget("state")) == "disabled"
    assert "(1)" in app.nav_btns["imp"][0].cget("text")
    d._rut(); pump(app)
    assert app.store.find_item(LOT, it["id"])[1]["q"] is None


def test_click_o_tick_tren_bang(app):
    app.show("duyet"); d = app.pages["duyet"]; d.nb.select(1); pump(app, 5)
    bb = d.rows.bbox("0", "#1")
    if not bb:
        pytest.skip("bảng chưa hiển thị")
    d.rows.event_generate("<Button-1>", x=bb[0] + 5, y=bb[1] + 5); pump(app)
    assert d.cur["dx"]["rows"][0]["tick"] is True


def test_tu_choi_can_ly_do(app, monkeypatch):
    from tkinter import messagebox
    shown = []
    monkeypatch.setattr(messagebox, "showwarning", lambda *a, **k: shown.append(a))
    app.show("duyet"); d = app.pages["duyet"]; d.nb.select(0); pump(app)
    d.t_denghi.delete("1.0", "end"); d.tc_var.set(True); d._toggle_tc(); pump(app)
    assert shown and d.tc_var.get() is False
    d.t_denghi.insert("1.0", "Nộp lại"); d.tc_var.set(True); d._toggle_tc(); pump(app)
    assert app.store.find_item(LOT, d.cur["it"]["id"])[1]["q"]["kind"] == "tuchoi"


def test_cai_dat_luu(app, monkeypatch):
    app.show("cai"); c = app.pages["cai"]
    c.v["tu_choi_cho_giay"].set("45"); c.v["r_mlToiThieu"].set("4960000")
    c._save(); pump(app)
    assert app.cfg.settings()["tu_choi_cho_giay"] == 45 and app.cfg.rules()["mlToiThieu"] == 4960000
    c.v["delay_ms"].set("abc")
    from tkinter import messagebox
    shown = []
    monkeypatch.setattr(messagebox, "showerror", lambda *a, **k: shown.append(a))
    c._save()
    assert shown and app.cfg.settings()["tu_choi_cho_giay"] == 45


def test_buoc_chua_cai_va_buoc_da_dang_ky(app):
    seen = []
    app.runner.register("ktn", lambda ctx, items: (ctx.log("chạy ktn"), seen.append(len(items or []))))
    app.show("ktn"); pump(app)
    app.pages["ktn"].tree.selection_set(app.pages["ktn"].tree.get_children()[:2]); pump(app)
    app.pages["ktn"]._run()
    t0 = time.time()
    while app.runner.busy and time.time() - t0 < 3:
        pump(app, 1)
    pump(app, 4)
    text = app.log_text.get("1.0", "end")
    assert seen == [2] and "XONG 4. Kiểm tra nháp" in text
    app.run_step("f2")
    t0 = time.time()
    while app.runner.busy and time.time() - t0 < 3:
        pump(app, 1)
    pump(app, 4)
    assert "BỎ QUA 5. Tra cứu F2" in app.log_text.get("1.0", "end")


def test_nguoi_da_lam_buoc(app):
    p = app.pages["f2"]; app.show("f2"); pump(app)
    p.tree.selection_set(p.tree.get_children()[0]); p._nguoi_lam(True); pump(app)
    lot = app.store.get_lot(LOT)
    assert any("f2" in (i.get("nguoiLam") or {}) for i in lot["items"])
    assert "Người đã làm" in p.tree.item(p.tree.get_children()[0], "values")[2]


def test_so_cai_khoa_hien_canh_bao(app, tmp_path):
    app.socai.add({"id": "x1", "ts": 1, "he": "TST", "ok": True, "who": "may", "sohosos": ["123/2026"], "fps": []})
    app.show("socai"); pump(app)
    assert "1 lượt ghi" in app.pages["socai"].banner.get()


def test_cai_dat_trinh_duyet_va_kiem_tra_ket_noi(app):
    app.show("cai"); c = app.pages["cai"]; pump(app)
    c.v["chrome_port"].set("9391"); c._save(); pump(app)
    assert app.cfg.settings()["chrome_port"] == 9391
    app.kiem_tra_chrome()                                   # không có Chrome ở cổng này -> báo lỗi rõ ràng, không treo/sập
    t0 = time.time()
    while "Không nối được Chrome" not in app.log_text.get("1.0", "end") and time.time() - t0 < 15:
        pump(app, 2)
    assert "Không nối được Chrome ở cổng 9391" in app.log_text.get("1.0", "end")
