"""Bước 3: mở thẳng trang chi tiết bằng #hash như tiện ích (không về danh sách/TRA CỨU/bấm đúp mỗi hồ sơ)."""
from bo600.steps import tai_d02 as T


class FakePage:
    def __init__(self): self.hash = "#/ho-so-dang-thu-ly"; self.dbl = []
    def evaluate(self, js, arg=None):
        if js == "location.hash": return self.hash
        if js is T.JS_HAS_ROW: return True
        if js is T.JS_DBLCLICK:
            self.dbl.append(arg); self.hash = T.HASH_CHI_TIET + "G-1"; return None
        if js is T.JS_WAIT_DETAIL:
            no = "77/2026" if "chi-tiet" in self.hash else ""
            hid = self.hash.split("id=")[-1] if "id=" in self.hash else ""
            return {"ok": "chi-tiet" in self.hash, "no": no, "hashId": hid, "hash": self.hash}
        return None


class FakeTab:
    def __init__(self): self.page = FakePage(); self.hashes = []
    def goto_hash(self, h): self.hashes.append(h); self.page.hash = h
    def sleep(self, ms): pass
    def cho_on_dinh(self, *a, **k): return None


class Ctx:
    def __init__(self): self.logs = []
    def log(self, m): self.logs.append(m)


def test_hoc_truong_id_roi_mo_thang():
    tab, ctx = FakeTab(), Ctx()
    it = {"sohoso": "77/2026", "raw": {"hoSoXuLyId": "G-1", "soHoSo": "77/2026"}, "page": 1}
    key = T._open_detail(tab, ctx, it, None)          # lần đầu: bấm đúp, học trường id
    assert key == "hoSoXuLyId" and tab.page.dbl == ["77/2026"]
    tab.page.hash = "#/ho-so-dang-thu-ly"; tab.page.dbl.clear(); tab.hashes.clear()
    assert T._open_detail(tab, ctx, it, key) == key   # lần sau: mở thẳng bằng hash, không bấm đúp
    assert tab.hashes == [T.HASH_CHI_TIET + "G-1"] and tab.page.dbl == []


def test_mo_thang_sai_ho_so_thi_quay_lai_bam_dup():
    tab, ctx = FakeTab(), Ctx()
    orig = T._cho_chi_tiet
    calls = {"n": 0}
    def fake(tab_, so, toi_da=25.0):
        calls["n"] += 1
        return {"matched": False, "no": "99/2026", "hash": ""} if calls["n"] == 1 else orig(tab_, so, toi_da)
    T._cho_chi_tiet = fake
    ove = T._ve_danh_sach
    T._ve_danh_sach = lambda t, c, p: setattr(t.page, 'hash', T.HASH_DANG_THU_LY)
    try:
        it = {"sohoso": "77/2026", "raw": {"hoSoXuLyId": "G-1"}, "page": 1}
        T._open_detail(tab, ctx, it, "hoSoXuLyId")
    finally:
        T._cho_chi_tiet = orig; T._ve_danh_sach = ove
    assert tab.page.dbl == ["77/2026"] and any("thử bấm đúp" in m for m in ctx.logs)
