import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from openpyxl import Workbook

from bo600.config import Config, Paths
from bo600.socai import Socai
from bo600.store import Store

HEAD = ["STT", "HOTEN", "SOBHXH", "SOCMND", "NGAYSINH", "MACV", "MA_TINH", "MA_BV", "PA", "ML", "TYLE", "TUTHANG",
        "DENTHANG", "NGAY_NOP_HS", "TINHLAI", "MAVUNG", "MAVUNGSS", "DIACHI", "MAPB", "SDT", "GHICHU"]


def make_row(**kw):
    base = dict(STT="1", HOTEN="Nguyen Van A", SOBHXH="0123456789", SOCMND="001090012345", NGAYSINH="01/02/1990",
                MACV="Kế toán", MA_TINH="01", MA_BV="001", PA="TM", ML="6000000", TYLE="32", TUTHANG="10/2026",
                DENTHANG="", NGAY_NOP_HS="05/10/2026", TINHLAI="", MAVUNG="01", MAVUNGSS="", DIACHI="Hà Nội",
                MAPB="", SDT="", GHICHU="HS 123/2026")
    base.update(kw)
    return base


def write_d02(path, rows, sheet="D02", numeric_cols=()):
    wb = Workbook()
    ws = wb.active
    ws.title = sheet
    ws.append(["DANH SÁCH LAO ĐỘNG"])           # dòng tiêu đề phụ phía trên
    ws.append(HEAD)
    for r in rows:
        ws.append([_cell(r.get(h, ""), h in numeric_cols) for h in HEAD])
    ws.append(["(1)", "(2)"])                    # dòng đánh số phải bị bỏ qua
    wb.save(str(path))
    return path


def _cell(v, numeric):
    if numeric and str(v).isdigit():
        return int(v)
    return v


@pytest.fixture
def paths(tmp_path):
    return Paths(tmp_path / "Bo600").ensure()


@pytest.fixture
def store(paths):
    s = Store(paths)
    yield s
    s.close()


@pytest.fixture
def socai(store):
    return Socai(store, auto_flush=False)


@pytest.fixture
def cfg(paths):
    return Config(paths)
