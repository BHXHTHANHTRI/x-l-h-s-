"""Bước 1 trên Chromium thật + trang giả TST/TIC. Cần BO600_TEST_CHROME=<đường dẫn chrome> (xem test_browser.py)."""
import json
import os
import urllib.request
from pathlib import Path

import pytest

pytest.importorskip("playwright")
CHROME = os.environ.get("BO600_TEST_CHROME")
if not CHROME or not Path(CHROME).is_file():
    pytest.skip("đặt BO600_TEST_CHROME để chạy test trình duyệt", allow_module_level=True)

import fake_portals
from bo600.browser import BrowserSession, launch_chrome
from bo600.browser.portals import PORTALS
from bo600.runner import Runner, StepContext
from bo600.steps import donvi as D
from test_donvi import ds_xlsx

PORT = 9352
OD = {"langMs": 150, "nhipMin": 40, "nhipMax": 80, "toiDaGiay": 20, "yeuCauCu": 15000, "domKhongLangSau": 5000}


@pytest.fixture(scope="module")
def chrome(tmp_path_factory):
    args = os.environ.get("BO600_TEST_CHROME_ARGS", "--headless=shell --no-sandbox --disable-gpu --disable-dev-shm-usage").split()
    env = {"LD_LIBRARY_PATH": os.environ["BO600_TEST_CHROME_LD"]} if os.environ.get("BO600_TEST_CHROME_LD") else None
    launch_chrome(tmp_path_factory.mktemp("prof"), PORT, chrome_path=CHROME, extra_args=args, env=env)
    yield PORT
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}").new_browser_cdp_session().send("Browser.close")
    except Exception:
        pass


@pytest.fixture(scope="module")
def site():
    srv, base = fake_portals.start()
    yield srv, base
    srv.shutdown()


@pytest.fixture
def env(chrome, site, store, socai, cfg, monkeypatch):
    srv, base = site
    hostport = base.split("//")[1]
    monkeypatch.setitem(PORTALS, "tst", (f"{hostport}/tst", f"{base}/tst"))
    monkeypatch.setitem(PORTALS, "tnhs", (f"{hostport}/tnhs", f"{base}/tnhs"))
    sessions = []

    def open_session(ctx):
        s = BrowserSession(chrome, od=OD, stop_check=ctx.check_stop)
        sessions.append(s)
        return s
    import bo600.steps as S
    monkeypatch.setattr(S, "open_session", open_session)
    srv.xuat.clear()
    # dọn tab và localStorage của lần trước
    with BrowserSession(chrome, od=OD) as s:
        for p in s.pages():
            if hostport in p.url:
                p.close()
        pg = s.ctx.new_page()
        pg.goto(f"{base}/tnhs")
        pg.evaluate("localStorage.clear()")
        pg.close()
    ctx = StepContext(store, socai, cfg, Runner(store, socai, cfg), "dv")
    return type("E", (), {"base": base, "srv": srv, "ctx": ctx, "store": store, "cfg": cfg, "hostport": hostport})


def managed(env):
    with BrowserSession(PORT, od=OD) as s:
        pg = s.ctx.new_page()
        pg.goto(f"{env.base}/tnhs")
        v = json.loads(pg.evaluate("localStorage.getItem('bhxh_managed_units') || '[]'"))
        pg.close()
    return v


def test_tu_tai_tu_tst_roi_nap_vao_tic(env):
    env.cfg.save_settings({"dv_tu_xuat": True, "cq": "Chuyên quản Khoa"})
    with BrowserSession(PORT, od=OD) as s:                       # TIC đã giữ sẵn một mã cũ
        pg = s.ctx.new_page()
        pg.goto(f"{env.base}/tnhs")
        pg.evaluate("localStorage.setItem('bhxh_managed_units', JSON.stringify(['009Z']))")
        pg.close()
    D.chay_don_vi(env.ctx, None)
    assert env.srv.xuat == [(["1"], ["1"])]                      # đã chọn đúng "Danh sách đơn vị" + "Excel"
    kv = env.store.kv_get("donvi")
    f = Path(kv["file"])
    assert f.parent == env.store.paths.danhmuc and f.suffix == ".xlsx" and f.name.startswith("DsDonVi_")
    assert kv["codes"] == ["001A", "001B", "001C"]
    assert kv["tic"]["thua"] == ["009Z"] and kv["tic"]["thieu"] == [] and kv["tic"]["n_giu"] == 4
    assert managed(env) == ["009Z", "001A", "001B", "001C"]


def test_dung_file_da_chon_khong_vao_tst(env, tmp_path):
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Chuyên quản Khoa"), ("001B", "Chuyên quản Khoa"), ("001C", "Chuyên quản Khoa")])
    env.store.kv_set("donvi", {"file": str(f), "cq": "Chuyên quản Khoa"})
    env.cfg.save_settings({"cq": "Chuyên quản Khoa"})
    D.chay_don_vi(env.ctx, None)
    assert env.srv.xuat == []
    assert env.store.kv_get("donvi")["tic"]["lay_ma"] == "Thêm 3 mã"
    assert managed(env) == ["001A", "001B", "001C"]


def test_ten_chuyen_quan_sai_goi_y_ten_gan_giong(env, tmp_path):
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Chuyên quản Khoa")])
    env.store.kv_set("donvi", {"file": str(f), "cq": "Chuyên quản Khoa An"})
    env.cfg.save_settings({"cq": "Chuyên quản Khoa An"})
    with pytest.raises(D.DonViError) as e:
        D.chay_don_vi(env.ctx, None)
    assert "không có trong file" in str(e.value) and "Chuyên quản Khoa" in str(e.value)
    assert managed(env) == []                                    # không bấm "Lấy mã" khi tên sai


def test_ten_khac_hoa_thuong_va_khoang_trang_van_khop(env, tmp_path):
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Chuyên quản Khoa")])
    env.store.kv_set("donvi", {"file": str(f)})
    env.cfg.save_settings({"cq": "  chuyên  quản KHOA "})
    D.chay_don_vi(env.ctx, None)
    assert env.store.kv_get("donvi")["cq"] == "Chuyên quản Khoa"  # lưu đúng tên trong file, không phải tên gõ


def test_khong_co_tic_bao_loi_ro(env, tmp_path):
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Chuyên quản Khoa")])
    env.store.kv_set("donvi", {"file": str(f), "cq": "Chuyên quản Khoa"})
    env.cfg.save_settings({"cq": "Chuyên quản Khoa"})
    with BrowserSession(PORT, od=OD) as s:
        pg = s.ctx.new_page()
        pg.goto(f"{env.base}/tnhs?notic=1")                      # mo_cong dùng lại tab này (URL chứa /tnhs)
        with pytest.raises(D.DonViError, match="Không thấy tiện ích TIC"):
            from bo600.steps import mo_cong
            tnhs = mo_cong(s, "tnhs", "#/ho-so-cho-thu-ly")
            D.nap_vao_tic(env.ctx, tnhs, f, "Chuyên quản Khoa")
        pg.close()
