import pytest
from openpyxl import Workbook, load_workbook

from bo600.d02_io import read_d02
from bo600.exports import export_duyet_xlsx
from bo600.rules import compute_dx
from bo600.config import QUY_TAC_MAC_DINH
from bo600.store import dx_key
from bo600.tranthe import (TRAN_HEAD, TRAN_SHEET, TranThe, TranTheError, tran_dem, tran_ma, tran_parse,
                           tran_so_sanh, tran_text)
from conftest import make_row, write_d02


def tt_file(path, rows, head=TRAN_HEAD, sheet=TRAN_SHEET, extra_sheet=False):
    wb = Workbook(); ws = wb.active; ws.title = sheet
    ws.append(head)
    for r in rows:
        ws.append(r)
    if extra_sheet:
        wb.create_sheet("Khac")
    wb.save(str(path)); return path


GOOD = [[1, "01-001", "BV A", 1, "Chỉ người có hộ khẩu\nquận X"], [2, "01-002", "BV B", 0, ""], [3, "01-0AB", "BV C", "", ""]]


def test_parse_hop_le(tmp_path):
    rows = tran_parse(tt_file(tmp_path / "a.xlsx", GOOD))
    assert rows["01-001"] == {"ten": "BV A", "t": "1", "dk": "Chỉ người có hộ khẩu quận X"}   # gộp xuống dòng
    assert rows["01-0AB"]["t"] == "" and tran_dem(rows) == {"n": 3, "tran": 1, "khong": 1, "chua": 1, "dk": 1}


@pytest.mark.parametrize("kw,msg", [
    (dict(sheet="Sheet1"), "đúng 1 sheet"),
    (dict(extra_sheet=True), "đúng 1 sheet"),
    (dict(head=["STT", "Mã BV", "Tên BV", "Trạng thái", "Điều kiện đăng ký"]), "dòng tiêu đề"),
    (dict(rows=[[1, "02-001", "BV", 1, ""]]), "không đúng dạng 01-xxx"),
    (dict(rows=[["a", "01-001", "BV", 1, ""]]), "STT"),
    (dict(rows=[[1, "01-001", "", 1, ""]]), "thiếu Tên BV"),
    (dict(rows=[[1, "01-001", "BV", 2, ""]]), "chỉ được 1, 0 hoặc để trống"),
    (dict(rows=[[1, "01-001", "BV", 1, ""], [2, "01-001", "BV2", 0, ""]]), "trùng Mã BV"),
    (dict(rows=[]), "không có dòng dữ liệu"),
    (dict(rows=[[1, "01-001", "BV", 1, "", "lạ"]]), "ngoài 5 cột"),
])
def test_parse_khoa_cau_truc(tmp_path, kw, msg):
    kw = {"rows": GOOD, **kw}
    with pytest.raises(TranTheError) as e:
        tran_parse(tt_file(tmp_path / "b.xlsx", **kw))
    assert msg in str(e.value)


def test_tran_text_va_tran_ma():
    cat = {"01-001": {"ten": "A", "t": "1", "dk": "x"}, "01-002": {"ten": "B", "t": "0", "dk": ""},
           "01-003": {"ten": "C", "t": "", "dk": ""}}
    assert tran_ma("01001") == "01-001" and tran_ma("001") == "01-001" and tran_ma("") == ""
    assert tran_text("01", "001", cat) == "TRÀN THẺ, điều kiện ĐK KCB: x"
    assert tran_text("01", "01002", cat) == "chưa tràn thẻ"
    assert tran_text("01", "003", cat) == "chưa có số phân bổ"
    assert tran_text("01", "999", cat) == "không có trong danh mục tràn thẻ"
    assert tran_text("01", "001", None) == "chưa có dữ liệu"
    assert tran_text("79", "001", cat) == ""                  # tỉnh khác: để trống
    assert "thêm 1 cơ sở, bớt 1 cơ sở, đổi trạng thái tràn thẻ 1" in tran_so_sanh(
        {"01-001": {"t": "0"}, "01-009": {"t": "1"}}, {"01-001": {"t": "1"}, "01-002": {"t": "0"}})


def test_nap_thay_toan_bo_va_xuat(store, tmp_path):
    t = TranThe(store)
    f1 = tt_file(tmp_path / "a.xlsx", GOOD)
    p = t.preview(f1)
    assert "3 cơ sở KCB" in p["tom_tat"] and p["so_sanh"] == "" and t.load() is None   # xem trước chưa đổi gì
    t.apply(f1, p["rows"])
    assert (store.paths.danhmuc / "DanhMuc_TranThe.xlsx").is_file() and t.rows().keys() == p["rows"].keys()
    f2 = tt_file(tmp_path / "b.xlsx", [[1, "01-009", "BV Z", 1, ""]])
    p2 = t.preview(f2)
    assert "bớt 3 cơ sở" in p2["so_sanh"]
    t.apply(f2, p2["rows"])
    assert list(t.rows()) == ["01-009"]                                               # thay toàn bộ
    bad = tt_file(tmp_path / "c.xlsx", [[1, "xx", "BV", 1, ""]])
    with pytest.raises(TranTheError):
        t.preview(bad)
    assert list(t.rows()) == ["01-009"]                                               # file sai: giữ nguyên
    out = t.export()
    assert tran_parse(out) == t.rows()                                                # xuất ra nạp lại được


def test_export_duyet_xlsx(store, tmp_path):
    lot = store.ensure_lot("2026-10-23")
    f = write_d02(store.paths.lot_dir("2026-10-23") / "hs1.xlsx", [make_row(MACV="nhân viên", DIACHI="abc")])
    it = store.add_item("2026-10-23", sohoso="123/2026", madonvi="ABC", file="hs1.xlsx", rows=1)
    dx = compute_dx(read_d02(f), it, QUY_TAC_MAC_DINH)
    store.kv_set(dx_key("2026-10-23", it["id"]), dx)
    store.edit_item("2026-10-23", it["id"], lambda i, l: i.update(duyet={"kq": "Từ chối", "at": "x"},
                                                                  q={"kind": "tuchoi", "lyDo": "L", "deNghi": "D"}))
    out = export_duyet_xlsx(store, "2026-10-23")
    wb = load_workbook(out)
    hs = list(wb["HoSo"].values)
    assert hs[1][0] == "123/2026" and hs[1][2] == "Đề xuất từ chối" and hs[1][5] == "L" and "chung chung" in hs[1][7]
    td = [r for r in wb["ThayDoi"].values][1:]
    assert ("DIACHI", "abc", ".", "Máy - tự sửa cơ học") in {(r[3], r[4], r[5], r[6]) for r in td}
    assert export_duyet_xlsx(store, "khong-co") is None
