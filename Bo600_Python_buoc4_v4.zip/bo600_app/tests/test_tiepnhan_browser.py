"""Bước 2 trên Chromium thật + trang TNHS giả (bảng Chờ thụ lý, menu Bộ phận, hộp Tiếp nhận, nút "Tích + Tiếp nhận" của TIC).
Cần BO600_TEST_CHROME=<đường dẫn chrome> (xem test_browser.py)."""
import json
import os
from pathlib import Path

import pytest

pytest.importorskip("playwright")
CHROME = os.environ.get("BO600_TEST_CHROME")
if not CHROME or not Path(CHROME).is_file():
    pytest.skip("đặt BO600_TEST_CHROME để chạy test trình duyệt", allow_module_level=True)

import fake_portals
from bo600.browser import BrowserSession, launch_chrome
from bo600.browser.portals import PORTALS
from bo600.runner import Runner, StepContext, StopRequested
from bo600.steps import tiepnhan as T

PORT = 9353
OD = {"langMs": 150, "nhipMin": 40, "nhipMax": 80, "toiDaGiay": 20, "yeuCauCu": 15000, "domKhongLangSau": 5000}
CO_TIC = [("100/2026/1", "001A"), ("101/2026/1", "999Z"), ("102/2026/1", "001B"), ("103/2026/1", "001A"), ("104/2026/1", "999Z")]


@pytest.fixture(scope="module")
def chrome(tmp_path_factory):
    args = os.environ.get("BO600_TEST_CHROME_ARGS", "--headless=shell --no-sandbox --disable-gpu --disable-dev-shm-usage").split()
    env = {"LD_LIBRARY_PATH": os.environ["BO600_TEST_CHROME_LD"]} if os.environ.get("BO600_TEST_CHROME_LD") else None
    launch_chrome(tmp_path_factory.mktemp("prof"), PORT, chrome_path=CHROME, extra_args=args, env=env)
    yield PORT
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}").new_browser_cdp_session().send("Browser.close")
    except Exception:
        pass


@pytest.fixture(scope="module")
def site():
    srv, base = fake_portals.start()
    yield srv, base
    srv.shutdown()


def dat_tic(env, units):
    """Đặt danh sách đơn vị TIC đang giữ (localStorage của trang TNHS)."""
    with BrowserSession(PORT, od=OD) as s:
        pg = s.ctx.new_page()
        pg.goto(f"{env.base}/tnhs")
        pg.evaluate("(u) => localStorage.setItem('bhxh_managed_units', JSON.stringify(u))", units)
        pg.close()


@pytest.fixture
def env(chrome, site, store, socai, cfg, monkeypatch):
    srv, base = site
    hostport = base.split("//")[1]
    state = {"query": ""}

    def dat_cong(query=""):
        monkeypatch.setitem(PORTALS, "tnhs", (f"{hostport}/tnhs", f"{base}/tnhs{query}"))
    dat_cong()
    monkeypatch.setitem(PORTALS, "tst", (f"{hostport}/tst", f"{base}/tst"))
    import bo600.steps as S
    monkeypatch.setattr(S, "open_session", lambda ctx: BrowserSession(chrome, od=OD, stop_check=ctx.check_stop))
    cfg.save_settings({"delay_ms": 500})
    fake_portals.reset_tnhs(srv, CO_TIC)
    with BrowserSession(chrome, od=OD) as s:                         # dọn tab của lần trước
        for p in s.pages():
            if hostport in p.url:
                p.close()
    dat_tic(type("E", (), {"base": base}), ["001A", "001B"])
    ctx = StepContext(store, socai, cfg, Runner(store, socai, cfg), "tn")
    return type("E", (), {"base": base, "srv": srv, "ctx": ctx, "store": store, "socai": socai, "cfg": cfg, "hostport": hostport,
                          "dat_cong": staticmethod(dat_cong)})


def con_lai(env):
    return [r["so"] for r in env.srv.tn["rows"]]


def luot_tn(env):
    return [e for e in env.socai.idx["list"] if e.get("loai") == "tiepnhan"]


def test_tiep_nhan_het_ho_so_thuoc_don_vi_quan_ly(env):
    T.chay_tiep_nhan(env.ctx, None)
    assert con_lai(env) == ["101/2026/1", "104/2026/1"]                       # chỉ hồ sơ của đơn vị mình
    kv = env.store.kv_get("tiepnhan")
    assert (kv["total"], kv["rounds"], kv["ok"]) == (3, 1, True)
    assert sorted(kv["hoso"]) == ["100/2026/1", "102/2026/1", "103/2026/1"]
    assert len(env.srv.tn["lenh"]) == 3
    es = luot_tn(env)                                                         # sổ cái ghi từng lệnh máy bấm
    assert sorted(s for e in es for s in e["sohosos"]) == ["100/2026/1", "102/2026/1", "103/2026/1"]
    assert all(e["ok"] and e["who"] == "may" and e["bophan"] == "Thu" and e["viec"] == "Tiếp nhận (Thu)" for e in es)
    assert env.socai.tnhs_events("100/2026/1")[0]["ketqua"] == "Đã tiếp nhận"
    log = "\n".join(env.ctx.lines)
    assert "Lượt 1: tích 3 hồ sơ" in log and "Thông báo: Tiếp nhận thành công" in log and "Không còn hồ sơ thuộc danh sách đơn vị quản lý" in log
    assert "Hoàn thành" in log
    with BrowserSession(PORT, od=OD) as s:
        pg = s.find_page(env.hostport)
        assert pg.evaluate("location.hash") == "#/ho-so-dang-thu-ly"          # kết thúc ở Đang thụ lý


def test_chay_lai_khi_het_viec_khong_tiep_nhan_them(env):
    T.chay_tiep_nhan(env.ctx, None)
    n = len(env.srv.tn["lenh"])
    env.ctx.lines.clear()
    T.chay_tiep_nhan(env.ctx, None)
    assert len(env.srv.tn["lenh"]) == n and env.store.kv_get("tiepnhan")["total"] == 0
    assert "Không còn hồ sơ thuộc danh sách" in "\n".join(env.ctx.lines)


def test_nhieu_trang_trang_dau_khong_khop_thi_sang_trang_sau(env):
    env.dat_cong("?size=3")
    fake_portals.reset_tnhs(env.srv, [("1/2026/1", "999Z"), ("2/2026/1", "999Z"), ("3/2026/1", "999Z"), ("4/2026/1", "001A"),
                                      ("5/2026/1", "001A"), ("6/2026/1", "999Z"), ("7/2026/1", "001B")])
    T.chay_tiep_nhan(env.ctx, None)
    assert con_lai(env) == ["1/2026/1", "2/2026/1", "3/2026/1", "6/2026/1"]
    assert env.store.kv_get("tiepnhan")["total"] == 3
    assert "chuyển sang trang sau" in "\n".join(env.ctx.lines)


def test_dang_o_cap_so_the_tu_doi_ve_thu_roi_tiep_nhan(env):
    fake_portals.reset_tnhs(env.srv, CO_TIC, vai="cst")                      # máy chủ từ chối lệnh nếu chưa ở Thu
    T.chay_tiep_nhan(env.ctx, None)
    assert env.srv.tn["doi_vai"] == ["thu"] and env.srv.tn["vai"] == "thu"
    assert env.store.kv_get("tiepnhan")["total"] == 3 and env.store.kv_get("vaiCst") == 0
    assert 'đang ở "Bộ phận Cấp sổ-thẻ"' in "\n".join(env.ctx.lines) or "Đổi bộ phận trên TNHS" in "\n".join(env.ctx.lines)


def test_da_o_thu_thi_khong_doi_bo_phan(env):
    T.chay_tiep_nhan(env.ctx, None)
    assert env.srv.tn["doi_vai"] == []


def test_hop_nhac_den_gio_tich_duoc_tu_dong_bam_oke(env):
    env.dat_cong("?remind=1")
    T.chay_tiep_nhan(env.ctx, None)
    assert env.store.kv_get("tiepnhan")["total"] == 3
    with BrowserSession(PORT, od=OD) as s:
        pg = s.find_page(env.hostport)
        assert pg.evaluate("window.__oke || 0") >= 1 and pg.evaluate("window.__chua || 0") == 0      # chỉ bấm OKE, không bấm "CHƯA TÍCH ĐƯỢC"
        assert pg.evaluate("window.__bo600oke") is False                                               # đã tắt tự bấm khi xong


def test_khong_thay_thong_bao_thanh_cong_thi_dung(env, monkeypatch):
    monkeypatch.setattr(T, "CHO_THONG_BAO_GIAY", 2)
    env.dat_cong("?khongtoast=1")
    with pytest.raises(T.TiepNhanError, match="Không xác nhận được"):
        T.chay_tiep_nhan(env.ctx, None)
    assert env.store.kv_get("tiepnhan")["ok"] is False
    assert len(luot_tn(env)) == 3                                             # lệnh đã gửi thì sổ cái vẫn ghi đủ


def test_hoso_van_con_sau_tiep_nhan_thi_dung_tranh_lap(env):
    fake_portals.reset_tnhs(env.srv, CO_TIC, khong_xoa=True)
    with pytest.raises(T.TiepNhanError, match="vẫn còn 3 hồ sơ"):
        T.chay_tiep_nhan(env.ctx, None)
    assert len(env.srv.tn["lenh"]) == 3                                       # không lặp lượt thứ hai


def test_may_chu_bao_loi_ghi_so_cai_that_bai_va_dung(env, monkeypatch):
    monkeypatch.setattr(T, "CHO_THONG_BAO_GIAY", 2)
    fake_portals.reset_tnhs(env.srv, CO_TIC, loi="Hồ sơ đang bị khóa")
    with pytest.raises(T.TiepNhanError):
        T.chay_tiep_nhan(env.ctx, None)
    es = luot_tn(env)
    assert len(es) == 3 and not any(e["ok"] for e in es) and "Hồ sơ đang bị khóa" in es[0]["ketqua"]
    assert "Lỗi: " in "\n".join(env.ctx.lines)


def test_tic_chua_co_danh_sach_bao_chay_buoc_1(env):
    dat_tic(env, [])
    with pytest.raises(T.TiepNhanError, match="chạy bước 1"):
        T.chay_tiep_nhan(env.ctx, None)
    assert env.srv.tn["lenh"] == []


def test_danh_sach_cho_thu_ly_trong(env):
    fake_portals.reset_tnhs(env.srv, [])
    T.chay_tiep_nhan(env.ctx, None)
    assert env.store.kv_get("tiepnhan")["total"] == 0 and "Danh sách Chờ thụ lý trống" in "\n".join(env.ctx.lines)


def test_khong_co_tic_chay_rieng_loi_ro_trong_chuoi_bo_qua(env, monkeypatch):
    monkeypatch.setattr(T, "CHO_TIC_GIAY", 1)
    env.dat_cong("?notic=1")
    with pytest.raises(T.TiepNhanError, match="Không thấy tiện ích TIC"):
        T.chay_tiep_nhan(env.ctx, None)
    assert env.srv.tn["lenh"] == []
    env.ctx.chain = True
    env.ctx.lines.clear()
    T.chay_tiep_nhan(env.ctx, None)
    assert "BỎ QUA bước Tiếp nhận" in "\n".join(env.ctx.lines) and env.srv.tn["lenh"] == []


def test_bam_dung_truoc_khi_tiep_nhan(env):
    env.runner = env.ctx.runner
    env.runner.stop()                                                         # cờ Dừng bật sẵn: máy dừng ngay ở lần kiểm tra đầu
    with pytest.raises(StopRequested):
        T.chay_tiep_nhan(env.ctx, None)
    assert env.srv.tn["lenh"] == [] and env.store.kv_get("tiepnhan")["note"] == "bấm Dừng"


def test_bang_bi_che_hoac_nam_ngoai_man_hinh_van_chay(env):
    """Trên TNHS thật bảng rất cao, bị phủ/ngoài màn hình: chỉ cần bảng đã có trong trang (lỗi gặp khi chạy thật)."""
    env.dat_cong("?che=1")
    T.chay_tiep_nhan(env.ctx, None)
    assert env.store.kv_get("tiepnhan")["total"] == 3
