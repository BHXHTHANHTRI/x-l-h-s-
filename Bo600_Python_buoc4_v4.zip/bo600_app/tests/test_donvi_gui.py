"""Trang bước 1 trên giao diện thật (cần Tkinter + màn hình; xvfb-run -a python -m pytest -q tests)."""
import pytest

tk = pytest.importorskip("tkinter")
try:
    _r = tk.Tk(); _r.destroy()
except tk.TclError:
    pytest.skip("không có màn hình (chạy bằng xvfb-run)", allow_module_level=True)
pytest.importorskip("ttkbootstrap")

from bo600.ui.app import App
from test_donvi import ds_xlsx


@pytest.fixture
def app(tmp_path):
    a = App(tmp_path / "Bo600")
    a.root.update()
    yield a
    a.on_close()


def test_dv_da_dang_ky_va_luu_form(app, tmp_path):
    assert app.runner.has("dv") and app.runner.has("tn")
    app.show("dv")
    pg = app.pages["dv"]
    f = ds_xlsx(tmp_path / "ds.xlsx", [("001A", "Khoa"), ("001B", "Khoa")])
    pg.dv_file.set(str(f)); pg.dv_cq.set("Khoa")
    pg._dv_doc()
    assert "Đã đọc 2 mã" in pg.dv_msg.get()
    assert pg._dv_luu_form() is True
    assert app.cfg.settings()["cq"] == "Khoa" and app.cfg.settings()["dv_tu_xuat"] is False
    assert app.store.kv_get("donvi")["codes"] == ["001A", "001B"]            # file không đổi: giữ mã đã đọc
    pg.dv_tu_xuat.set(True)
    assert pg._dv_luu_form() and app.cfg.settings()["dv_tu_xuat"] is True


def test_dv_doi_file_xoa_ma_cu_va_hien_ket_qua_tic(app, tmp_path):
    app.show("dv")
    pg = app.pages["dv"]
    f1 = ds_xlsx(tmp_path / "a.xlsx", [("001A", "Khoa")])
    f2 = ds_xlsx(tmp_path / "b.xlsx", [("002A", "Khoa")])
    app.store.kv_set("donvi", {"file": str(f1), "cq": "Khoa", "codes": ["001A"], "at": "x",
                               "tic": {"at": "t", "cq": "Khoa", "n_giu": 2, "thua": ["009Z"], "thieu": ["002A"], "lay_ma": "Thêm 1 mã"}})
    pg.refresh()
    t = pg.dv_tic.get()
    assert "đang giữ 2 mã" in t and "Mã thừa 1" in t and "CẢNH BÁO - thiếu 1 mã" in t and "002A" in t
    pg.dv_file.set(str(f2))
    assert pg._dv_luu_form()
    assert "codes" not in app.store.kv_get("donvi") and app.store.kv_get("donvi")["tic"]["n_giu"] == 2


def test_chay_buoc_thieu_file_khong_mo_trinh_duyet(app, monkeypatch):
    """Không chọn file, từ chối tự tải -> không chạy bước."""
    from tkinter import messagebox
    monkeypatch.setattr(messagebox, "askyesno", lambda *a, **k: False)
    app.show("dv")
    pg = app.pages["dv"]
    pg.dv_file.set("")
    pg._run()
    assert not app.runner.busy


def test_tn_trang_buoc_2_hien_ket_qua_lan_chay(app):
    app.show("tn")
    pg = app.pages["tn"]
    assert "Chưa chạy lần nào" in pg.tn_msg.get()
    app.store.kv_set("tiepnhan", {"at": "24/10/2026 10:00:00", "total": 3, "rounds": 1, "ok": True, "note": "",
                                  "hoso": ["1/2026/1", "2/2026/1", "3/2026/1"]})
    pg.refresh()
    assert "3 hồ sơ" in pg.tn_msg.get() and "Hoàn thành" in pg.tn_msg.get() and "1/2026/1" in pg.tn_hoso.get()
    app.store.kv_set("tiepnhan", {"at": "x", "total": 1, "rounds": 1, "ok": False, "note": "bấm Dừng", "hoso": []})
    pg.refresh()
    assert "Dừng giữa chừng" in pg.tn_msg.get() and pg.tn_hoso.get() == ""
