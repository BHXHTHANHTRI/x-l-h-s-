"""Hai trang giả cho test bước 1-2: /tst (Danh mục đơn vị > Xuất File) và /tnhs (khung 'Đơn vị quản lý' của TIC,
menu Bộ phận, bảng Chờ thụ lý, hộp Tiếp nhận hồ sơ, nút 'Tích + Tiếp nhận' của TIC).
Chỉ bắt chước cấu trúc DOM mà handler dùng (id, thuộc tính, chữ), không phải bản sao của hệ thống thật."""
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from urllib.parse import parse_qs, urlparse

from openpyxl import Workbook

HEAD = ["STT", "Mã ĐV", "Tên đơn vị", "a", "b", "c", "d", "e", "Chuyên quản"]
DATA = {"Chuyên quản Khoa": ["001A", "001B", "001C"], "Chuyên quản Lan Anh": ["777X"]}


def xlsx_bytes(data=DATA) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.append(["DANH SÁCH ĐƠN VỊ"])
    ws.append(HEAD)
    n = 0
    for cq, codes in data.items():
        for c in codes:
            n += 1
            ws.append([n, c, "Đơn vị " + c, "", "", "", "", "", cq])
    b = BytesIO()
    wb.save(b)
    return b.getvalue()


TST = """<!doctype html><meta charset=utf-8><title>TST</title>
<button ui-sref="dmDonVi.export({})" id="xf">Xuất File</button>
<div class="modal" id="m" style="display:none;position:fixed;top:40px;left:40px;background:#fff;padding:10px;border:1px solid #888">
 <h4>Xuất Báo cáo</h4>
 <div><input type="radio" name="typeReport"> Báo cáo tổng hợp <input type="radio" name="typeReport"> Danh sách đơn vị</div>
 <div><input type="radio" name="typeFile"> Word <input type="radio" name="typeFile"> Excel</div>
 <button ng-click="export()" id="ex">Xuất File</button></div>
<a id="dl" download style="display:none"></a>
<script>
 document.getElementById('xf').addEventListener('click', () => { document.getElementById('m').style.display = 'block'; });
 document.getElementById('ex').addEventListener('click', () => {
   const idx = (n) => [...document.querySelectorAll('input[name=' + n + ']')].findIndex((x) => x.checked);
   const a = document.getElementById('dl'); a.href = '/dsdv.xlsx?r=' + idx('typeReport') + '&f=' + idx('typeFile'); a.click();
 });
</script>"""

TNHS = """<!doctype html><meta charset=utf-8><title>TNHS</title>
<div id="top"><a ng-click="ctrl.openMenu($mdMenu, $event)" id="role" href="javascript:void 0">Bộ phận Quản lý thu</a>
 <div id="rmenu" style="display:none"><a ng-click="clickDefaultPhongban(112)" data-to="thu" href="javascript:void 0">Bộ phận Quản lý thu</a>
 <a ng-click="clickDefaultPhongban(109)" data-to="cst" href="javascript:void 0">Bộ phận Cấp sổ-thẻ</a></div></div>
<md-table-container><table class="alternate"><tbody id="tb"></tbody></table>
 <md-table-pagination><button ng-click="$pagination.next()" aria-label="Next" id="nx">›</button></md-table-pagination></md-table-container>
<script>if (new URLSearchParams(location.search).get('che')) document.addEventListener('DOMContentLoaded', () => {
 const d = document.createElement('div'); d.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:1;background:rgba(0,0,0,.01)';
 const t = document.querySelector('md-table-container'); t.style.cssText = 'display:block;margin-top:3000px'; document.body.appendChild(d); });</script>
<div id="msg"></div><div id="toast-container"></div>
<md-dialog id="dlg" aria-label="Tiếp nhận hồ sơ" style="display:none;position:fixed;top:60px;left:60px;background:#fff;border:1px solid #888;padding:8px">
 <h4>Tiếp nhận hồ sơ</h4><md-progress-linear id="pl" style="display:none;width:200px;height:6px;background:#39f"></md-progress-linear>
 <table><tbody id="dtb"></tbody></table><button ng-click="capnhattiepnhanhosochothuly()" id="ghi">GHI NHẬN</button></md-dialog>
<div id="app"></div>
<script>
 const Q = new URLSearchParams(location.search);
 const SIZE = Number(Q.get('size') || 100);
 let ST = { vai: 'thu', rows: [] }, PG = 0, TICKED = [];
 const $$ = (i) => document.getElementById(i);
 const trang = () => ST.rows.slice(PG * SIZE, PG * SIZE + SIZE);
 function render() {
   $$('role').textContent = ST.vai === 'thu' ? 'Bộ phận Quản lý thu' : 'Bộ phận Cấp sổ-thẻ';
   $$('tb').innerHTML = trang().map((r, i) => '<tr><td>' + (i + 1) + '</td><td>' + r.so + '</td><td>Đơn vị ' + r.madv + '</td></tr>').join('');
   $$('nx').disabled = (PG + 1) * SIZE >= ST.rows.length;
 }
 async function nap() { ST = await (await fetch('/api/tn/state')).json(); if (PG * SIZE >= ST.rows.length) PG = 0; render(); }
 const toast = (t) => { const d = document.createElement('div'); d.className = 'toast-message'; d.textContent = t; $$('toast-container').appendChild(d); };
 $$('role').onclick = () => { $$('rmenu').style.display = 'block'; };
 document.querySelectorAll('#rmenu a').forEach((a) => a.addEventListener('click', async () => {
   await fetch('/api/tn/vai?to=' + a.dataset.to, { method: 'POST' }); location.reload(); }));
 $$('nx').onclick = () => { PG++; render(); };
 if (Q.get('remind')) setTimeout(() => {
   const o = document.createElement('div'); o.id = '__bhxh_remind_overlay';
   o.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:9999';
   o.innerHTML = '<button id="oke">OKE, ĐỂ TÔI TÍCH!</button><button id="chua">CHƯA TÍCH ĐƯỢC</button>';
   document.body.appendChild(o); $$('oke').onclick = () => { window.__oke = (window.__oke || 0) + 1; o.remove(); };
   $$('chua').onclick = () => { window.__chua = (window.__chua || 0) + 1; o.remove(); };
 }, 600);
 nap();
 $$('ghi').onclick = async () => {
   const kq = [];
   for (const so of TICKED) {
     const r = await fetch('/gateway/api/GetValues', { method: 'POST', body: JSON.stringify({ hanhdong: '1', sohoso: so, dmphongbanguiid: '112', currenttrangthaixuly: '1' }) });
     kq.push(await r.json());
   }
   if (kq.every((x) => x.code === 0) && !Q.get('khongtoast')) toast('Tiếp nhận thành công');
   else if (!kq.every((x) => x.code === 0)) toast('Lỗi: ' + kq.map((x) => x.msg).join(','));
   setTimeout(async () => { $$('dlg').style.display = 'none'; await nap(); }, 300);
 };
 const DATA = __DATA__;
 if (!location.search.includes('notic')) document.getElementById('app').innerHTML = `
  <button id="__chkGreen">TIC</button>
  <div id="menu" style="display:none"><button id="__chkDV">Đơn vị quản lý</button></div>
  <div id="__bhxh_panel" style="display:none;padding:8px;border:1px solid #888">
   <input type="file" id="__bhxh_file_input" style="display:none">
   <input id="__bhxh_cq_input" autocomplete="off">
   <div id="__bhxh_cq_suggestions" style="display:none"></div>
   <div id="__bhxh_cq_count_hint"></div>
   <button id="__bhxh_cq_import_btn">Lấy mã theo chuyên quản</button>
   <div id="__bhxh_import_status"></div>
   <button id="__bhxh_tick_accept_btn">Tích + Tiếp nhận</button>
   <div id="__bhxh_tick_result"></div></div>`;
 const $ = (i) => document.getElementById(i);
 if ($('__chkGreen')) {
  const st = $('__bhxh_import_status'), inp = $('__bhxh_cq_input'), sug = $('__bhxh_cq_suggestions');
  $('__chkGreen').onclick = () => { $('menu').style.display = 'block'; };
  $('__chkDV').onclick = () => { $('__bhxh_panel').style.display = 'block'; };
  $('__bhxh_file_input').addEventListener('change', () => { setTimeout(() => { st.textContent = 'Đọc xong ' + Object.keys(DATA).length + ' chuyên quản'; }, 300); });
  const hien = () => {
    const q = inp.value.trim().toLowerCase();
    const ds = Object.keys(DATA).filter((k) => !q || k.toLowerCase().includes(q));
    sug.innerHTML = ds.map((k) => '<div class="__bhxh_sug_item" data-val="' + k + '">' + k + '</div>').join('');
    sug.style.display = 'block';
    $('__bhxh_cq_count_hint').textContent = (q && !DATA[inp.value.trim()]) ? 'Không tìm thấy chuyên quản' : '';
    sug.querySelectorAll('.__bhxh_sug_item').forEach((e) => e.addEventListener('mousedown', () => { inp.value = e.getAttribute('data-val'); sug.style.display = 'none'; hien2(); }));
  };
  const hien2 = () => { $('__bhxh_cq_count_hint').textContent = DATA[inp.value.trim()] ? DATA[inp.value.trim()].length + ' mã' : 'Không tìm thấy chuyên quản'; };
  inp.addEventListener('input', hien);
  $('__bhxh_tick_accept_btn').onclick = () => {
    const res = $('__bhxh_tick_result');
    let cur = []; try { cur = JSON.parse(localStorage.getItem('bhxh_managed_units') || '[]'); } catch (e) {}
    if (!cur.length) { res.textContent = 'Chưa có danh sách đơn vị quản lý'; return; }
    TICKED = trang().filter((r) => cur.includes(r.madv)).map((r) => r.so);
    if (!TICKED.length) { res.textContent = 'Không khớp hồ sơ nào trong trang'; return; }
    res.textContent = 'Đã tích ' + TICKED.length + ' hồ sơ';
    $$('dtb').innerHTML = ''; $$('pl').style.display = 'block'; $$('dlg').style.display = 'block';
    setTimeout(() => { $$('dtb').innerHTML = TICKED.map((so, i) => '<tr><td>' + (i + 1) + '</td><td>' + so + '</td></tr>').join(''); $$('pl').style.display = 'none'; }, 700);
  };
  $('__bhxh_cq_import_btn').onclick = () => {
    const codes = DATA[inp.value.trim()];
    if (!codes) { st.textContent = 'Không tìm thấy chuyên quản'; return; }
    let cur = []; try { cur = JSON.parse(localStorage.getItem('bhxh_managed_units') || '[]'); } catch (e) {}
    const moi = codes.filter((c) => !cur.includes(c));
    localStorage.setItem('bhxh_managed_units', JSON.stringify(cur.concat(moi)));
    localStorage.setItem('bhxh_last_cq_name', inp.value.trim());
    st.textContent = 'Thêm ' + moi.length + ' mã';
  };
 }
</script>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8", headers=None):
        b = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        import json
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/tst":
            return self._send(200, TST)
        if u.path == "/tnhs":
            return self._send(200, TNHS.replace("__DATA__", json.dumps(DATA, ensure_ascii=False)))
        if u.path == "/api/tn/state":
            tn = self.server.tn
            return self._send(200, json.dumps({"vai": tn["vai"], "rows": tn["rows"]}), "application/json")
        if u.path == "/dsdv.xlsx":
            dung = q.get("r") == ["1"] and q.get("f") == ["1"]       # chỉ đúng khi chọn "Danh sách đơn vị" + "Excel"
            self.server.xuat.append((q.get("r"), q.get("f")))
            body = xlsx_bytes(DATA if dung else {"SAI": ["000X"]})
            return self._send(200, body, "application/octet-stream", {"Content-Disposition": 'attachment; filename="DanhSachDonVi.xlsx"'})
        self._send(404, "")


    def do_POST(self):
        import json
        u = urlparse(self.path)
        q = parse_qs(u.query)
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n).decode("utf-8") if n else ""
        tn = self.server.tn
        if u.path == "/api/tn/vai":
            tn["vai"] = (q.get("to") or ["thu"])[0]
            tn["doi_vai"].append(tn["vai"])
            return self._send(200, "{}", "application/json")
        if u.path == "/gateway/api/GetValues":
            tn["lenh"].append(body)
            d = json.loads(body or "{}")
            if tn["vai"] != "thu":
                out = {"code": 1, "msg": "Sai bộ phận"}
            elif tn["loi"]:
                out = {"code": 1, "msg": tn["loi"]}
            else:
                out = {"code": 0, "msg": "Tiếp nhận thành công"}
                if not tn["khong_xoa"]:
                    tn["rows"] = [r for r in tn["rows"] if r["so"] != d.get("sohoso")]
            return self._send(200, json.dumps(out), "application/json")
        self._send(404, "")


def reset_tnhs(srv, rows=(), vai="thu", **kw):
    """Đặt lại trạng thái TNHS giả. rows: [(số hồ sơ, mã đơn vị)]. kw: khong_xoa (hồ sơ không biến mất sau GHI NHẬN), loi (máy chủ báo lỗi)."""
    srv.tn = {"vai": vai, "rows": [{"so": a, "madv": b} for a, b in rows], "lenh": [], "doi_vai": [], "khong_xoa": False, "loi": ""}
    srv.tn.update(kw)


def start():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    reset_tnhs(srv)
    srv.xuat = []
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}"
