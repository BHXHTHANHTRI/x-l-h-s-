import json

import pytest

from bo600.config import Config, Paths, QUY_TAC_MAC_DINH, SETTINGS_MAC_DINH
from bo600.model import f2_xong, ktn_xong, the_xong
from bo600.socai import Socai, SocaiLocked, tnhs_loai
from bo600.store import Store, dx_key, item_keys
from bo600.sukien import SuKien, row_key_sets


def luu(id_, so, ok=True, fps=None, ts=1000):
    return {"id": id_, "ts": ts, "at": "x", "he": "TST", "viec": "Lưu import", "loai": "luu", "ok": ok,
            "who": "may", "sohosos": [so], "fps": fps or []}


# ---------- kho ----------
def test_lot_item_crud_va_edit(store):
    lot = store.ensure_lot("2026-10-23")
    assert lot["items"] == [] and store.paths.res_dir("2026-10-23").is_dir()
    it = store.add_item("2026-10-23", sohoso="123/2026", madonvi="ABC")
    assert store.find_item("2026-10-23", it["id"])[1]["sohoso"] == "123/2026"
    assert store.edit_item("2026-10-23", it["id"], lambda i, l: i.update(rows=5)) is True
    assert store.find_item("2026-10-23", it["id"])[1]["rows"] == 5
    assert store.edit_item("2026-10-23", it["id"], lambda i, l: (i.update(rows=9), False)[1]) is False
    assert store.find_item("2026-10-23", it["id"])[1]["rows"] == 5          # False = hủy, không ghi
    assert store.edit_item("2026-10-23", "khong-co", lambda i, l: None) is False
    assert len(store.all_items()) == 1
    lot = store.get_lot("2026-10-23"); lot["status"] = "closed"; store.save_lot(lot)
    assert store.all_items() == []                                          # lô đóng không còn "mở"


def test_kv_va_purge(store):
    store.kv_set("dx:a:b", {"x": 1})
    assert store.kv_get("dx:a:b") == {"x": 1} and store.kv_get("nope", 7) == 7
    store.purge_item_data("a", "b")
    assert store.kv_get("dx:a:b") is None
    assert item_keys("a", "b")[3] == dx_key("a", "b")


def test_du_lieu_con_sau_khi_mo_lai(paths):
    s = Store(paths); s.ensure_lot("L1"); s.add_item("L1", sohoso="1"); s.close()
    s2 = Store(paths)
    assert s2.get_lot("L1")["items"][0]["sohoso"] == "1"
    s2.close()


def test_trang_thai_buoc():
    assert ktn_xong({"ktn": {"status": "Đạt - lưu được"}}) and ktn_xong({"nguoiLam": {"ktn": {"ai": 1}}})
    assert not ktn_xong({"ktn": {"status": "Lỗi chạy"}})
    assert f2_xong({"f2": {"status": "Xong"}}) and f2_xong({"tc": {"status": "Xong"}}) and not f2_xong({})
    assert not the_xong({"f2": {"status": "Xong"}, "the": {"status": "Lỗi"}, "tc": {"status": "Xong"}})


# ---------- sổ cái ----------
def test_socai_chi_them_va_truy_van(socai):
    assert socai.add(luu("a", "123/2026", fps=["fp1"]))["added"] is True
    assert socai.add(luu("a", "123/2026"))["added"] is False                # trùng id: không thêm lần hai
    socai.add(luu("b", "456/2026", ok=False))
    assert socai.hit({"sohoso": "123/2026"}) and socai.hit({"sohoso": "456/2026"}) is None   # lượt lỗi không tính là đã Lưu
    assert "456/2026" in socai.idx["luuAll"]                                # nhưng vẫn lưu để báo lỗi
    assert socai.has_fingerprint("fp1") and not socai.has_fingerprint("zz")
    assert socai.idx["count"] == 2


def test_socai_tnhs_phan_loai(socai):
    e = {"id": "t1", "ts": 1, "he": "TNHS", "viec": "XỬ LÝ (Cấp sổ-thẻ)", "sohosos": ["9/2026"], "ok": True}
    socai.add(e)
    assert socai.tnhs_events("9/2026")[0]["loai"] == "xuly" and socai.tnhs_events("9/2026")[0]["bophan"] == "Cấp sổ-thẻ"
    assert tnhs_loai({"viec": "Phiếu hướng dẫn"})["loai"] == "phieu"
    assert tnhs_loai({"viec": "gì đó"})["loai"] == "khac"


def test_socai_sao_luu_nguyen_tu(socai, paths):
    socai.add(luu("a", "1/2026"))
    r = socai.flush()
    f = paths.socai / f"socai_{socai.meta()['id']}.json"
    doc = json.loads(f.read_text(encoding="utf-8"))
    assert r["count"] == 1 and doc["kind"] == "socai" and doc["app"] == "Bo600" and doc["entries"][0]["id"] == "a"
    assert not list(paths.socai.glob("*.tmp"))
    assert socai.flush() is None                                            # không có gì mới: bỏ qua


def test_socai_khoa_khi_cai_lai_va_khoi_phuc(paths, tmp_path):
    # Máy cũ có sổ cái
    s1 = Store(paths); a = Socai(s1, auto_flush=False)
    a.add(luu("a", "123/2026", fps=["fp1"])); a.flush(); old_id = a.meta()["id"]; s1.close()
    # "Cài lại": CSDL mới (mất dữ liệu) nhưng thư mục _socai vẫn còn file cũ
    (paths.app / "bo600.sqlite").unlink()
    for ext in ("-wal", "-shm"):
        (paths.app / f"bo600.sqlite{ext}").unlink(missing_ok=True)
    s2 = Store(paths); b = Socai(s2, auto_flush=False)
    assert b.meta()["id"] != old_id and b.state["locked"] and b.state["old"] == [old_id]
    with pytest.raises(SocaiLocked):
        b.assert_ready()
    assert b.hit({"sohoso": "123/2026"}) is None                            # chưa khôi phục: chưa biết hồ sơ đã Lưu
    r = b.restore_file(paths.socai / f"socai_{old_id}.json")
    assert r["added"] == 1 and not b.state["locked"] and old_id in b.meta()["restoredFrom"]
    b.assert_ready()
    assert b.hit({"sohoso": "123/2026"}) and b.has_fingerprint("fp1")
    assert b.restore_file(paths.socai / f"socai_{old_id}.json")["added"] == 0   # khôi phục lại không nhân đôi
    s2.close()


def test_socai_restore_file_sai(socai):
    with pytest.raises(ValueError):
        socai.restore({"kind": "khac"})


def test_socai_xac_nhan(socai):
    it = {"sohoso": "77/2026", "madonvi": "ABC"}
    socai.xac_nhan(it, "luu")
    socai.xac_nhan(it, "xlThu", "3")
    socai.xac_nhan(it, "xlSt")
    assert socai.hit(it)[0]["nguon"] == "xacnhan"
    ev = socai.tnhs_events("77/2026")
    assert [(e["bophan"], e["danhgia"]) for e in ev] == [("Thu", "3"), ("Cấp sổ-thẻ", "1")] or \
           sorted((e["bophan"], e["danhgia"]) for e in ev) == [("Cấp sổ-thẻ", "1"), ("Thu", "3")]
    with pytest.raises(ValueError):
        socai.xac_nhan(it, "bay")


def test_socai_tsv(socai):
    socai.add(luu("a", "1/2026"))
    t = socai.tsv()
    assert t.startswith("\ufeffLuc\tThoi_diem_ms") and "\r\n" in t and "1/2026" in t


# ---------- sự kiện ----------
def test_events_of_khoa_manh_va_yeu(store):
    sk = SuKien(store)
    it = {"id": "i", "rk": [{"stt": "1", "ma": "0123", "cccd": "0010"}, {"stt": "2", "ma": "999", "cccd": ""}],
          "rkx": [{"stt": "2", "ma": [], "cccd": [], "maHo": [], "weak": {"ma": ["555"], "cmnd": [], "ho": []}}]}
    store.save_lot({"id": "L", "items": [it]})
    sk.add({"id": "e1", "ts": 10, "loai": "tim", "keys": {"ma": ["0123"]}})
    sk.add({"id": "e2", "ts": 5, "loai": "tim", "keys": {"cccd": ["0010"], "ma": ["999"]}})
    sk.add({"id": "e3", "ts": 7, "loai": "tim", "keys": {"ma": ["555"]}})                      # khóa yếu
    sk.add({"id": "e4", "ts": 8, "loai": "dd_tim", "who": "may", "keysFrom": "ketqua", "keys": {"ma": ["0123"]}})
    out = sk.events_of(it)
    assert [(x["ev"]["id"], x["stts"]) for x in out] == [("e2", ["1", "2"]), ("e3", ["2"]), ("e1", ["1"])]
    sk.add({"id": "e5", "ts": 20, "loai": "tim", "keys": {"ma": ["0123"]}})
    it["reopenTs"] = 15
    assert [x["ev"]["id"] for x in sk.events_of(it)] == ["e5"]                                 # mốc "Mở lại"


def test_khoa_yeu_khong_gan_nham_nguoi_khac(store):
    a = {"id": "a", "rk": [{"stt": "1", "ma": "555"}], "rkx": []}
    b = {"id": "b", "rk": [], "rkx": [{"stt": "1", "weak": {"ma": ["555"]}}]}
    store.save_lot({"id": "L", "items": [a, b]})
    sk = SuKien(store)
    sk.add({"id": "e", "ts": 1, "keys": {"ma": ["555"]}})
    assert len(sk.events_of(a)) == 1 and sk.events_of(b) == []     # 555 là khóa mạnh của hồ sơ a nên b chỉ có khóa yếu


def test_row_key_sets_bo_khoang_trang():
    assert row_key_sets({"rk": [{"stt": 1, "ma": " 01 23 ", "cccd": ""}]}) == {1: {"ma:0123"}}


# ---------- cấu hình ----------
def test_config_mac_dinh_va_ghi_de(cfg):
    assert cfg.rules() == QUY_TAC_MAC_DINH
    assert cfg.settings()["lo_xu_ly_toi_da"] == 20 and cfg.settings()["tnhs_tu_dong"] is False
    cfg.save_rules({"mlToiThieu": "4960000", "macvTuChoi": ["thợ"], "nhom": {"ml": "tuchoi"},
                    "mau": {"ml": {"lyDo": "mới"}}})
    r = cfg.rules()
    assert r["mlToiThieu"] == 4960000 and r["macvTuChoi"] == ["thợ"] and r["nhom"]["ml"] == "tuchoi"
    assert r["mau"]["ml"]["lyDo"] == "mới" and r["mau"]["ml"]["deNghi"].startswith("Đề nghị đơn vị điều chỉnh")
    assert QUY_TAC_MAC_DINH["mlToiThieu"] == 5310000                      # không làm hỏng giá trị mặc định


def test_config_settings_hop_nhat_va_module_import_can_duyet(cfg):
    cfg.save_settings({"lo_xu_ly_toi_da": 10, "delay_ms": 100, "rac": 1, "modules": {"duyet": False}})
    s = cfg.settings()
    assert s["lo_xu_ly_toi_da"] == 10 and s["delay_ms"] == 500 and "rac" not in s
    assert s["modules"]["import"] is True and cfg.module_on("import") is False   # import cần bật cùng duyet
    assert SETTINGS_MAC_DINH["lo_xu_ly_toi_da"] == 20
