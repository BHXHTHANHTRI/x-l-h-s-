from openpyxl import load_workbook

from bo600.config import COT_CHU
from bo600.d02_io import GOC_SHEET, D02Error, build_import, read_d02, validate_edited, codes_of_cq
from conftest import make_row, write_d02
import pytest


def test_read_d02_giu_so_0_dau_va_bo_dong_danh_so(tmp_path):
    f = write_d02(tmp_path / "a.xlsx", [make_row(), make_row(STT="2", HOTEN="Tran B", SOBHXH="0000111222")])
    S = read_d02(f)
    assert len(S.rows) == 2                         # dòng "(1)" bị bỏ
    assert S.rows[0].o["SOBHXH"] == "0123456789"
    assert S.rows[1].o["SOBHXH"] == "0000111222"
    assert S.rows[0].sr == 3 and S.rows[1].sr == 4  # tiêu đề phụ ở dòng 1, HOTEN ở dòng 2
    assert S.col("HOTEN") == 2


def test_read_d02_khong_co_hoten(tmp_path):
    from openpyxl import Workbook
    wb = Workbook(); wb.active.title = "D02"; wb.active.append(["A", "B"]); wb.active.append(["1", "2"])
    p = tmp_path / "x.xlsx"; wb.save(p)
    with pytest.raises(D02Error):
        read_d02(p)


def test_build_import_ghi_chu_va_sheet_goc(tmp_path):
    src = write_d02(tmp_path / "src.xlsx", [make_row(MAVUNG="02", DIACHI="abc")])
    S = read_d02(src)
    r = S.rows[0]
    chot = dict(r.o); chot.update(MAVUNG="01", DIACHI=".", MAPB="", SDT="0912345678", STT="999")
    dst = build_import(src, tmp_path / "out" / "imp.xlsx", [{"sr": r.sr, "goc": r.o, "chot": chot}], with_goc=True)
    wb = load_workbook(dst)
    assert wb.sheetnames == ["D02", GOC_SHEET]
    T = read_d02(load_workbook(dst), data_only=True) if False else read_d02(dst)
    assert T.rows[0].o["MAVUNG"] == "01" and T.rows[0].o["DIACHI"] == "."
    assert T.rows[0].o["SDT"] == "0912345678"
    assert T.rows[0].o["STT"] == "1"                # cột khóa không bị ghi
    assert wb["D02"].cell(r.sr, S.col("SDT")).data_type == "s"
    g = wb[GOC_SHEET]
    assert g.cell(r.sr, S.col("MAVUNG")).value == "02"   # sheet gốc giữ nguyên bản đầu


def _goc(S):
    return [{"goc": r.o} for r in S.rows]


def test_validate_edited_sai_ten(tmp_path):
    src = write_d02(tmp_path / "a.xlsx", [make_row()])
    S = read_d02(src)
    res = validate_edited(src, {"file": "khac.xlsx", "sohoso": "123/2026"}, _goc(S))
    assert res.errors and "cần đúng file" in res.errors[0]


def test_validate_edited_o_so_bi_excel_doi(tmp_path):
    src = write_d02(tmp_path / "a.xlsx", [make_row()])
    S = read_d02(src)
    bad = write_d02(tmp_path / "b" / "a.xlsx" if (tmp_path / "b").mkdir() is None else None,
                    [make_row()], numeric_cols=("SOBHXH",))
    res = validate_edited(bad, {"file": "x/a.xlsx", "sohoso": "123/2026"}, _goc(S))
    assert any("cột SOBHXH" in e and "SỐ/NGÀY" in e for e in res.errors)


def test_validate_edited_hop_le_ghi_ban_chuan_hoa(tmp_path):
    src = write_d02(tmp_path / "a.xlsx", [make_row(), make_row(STT="2", HOTEN="B", GHICHU="HS 123/2026")])
    S = read_d02(src)
    out = tmp_path / "ok.xlsx"
    res = validate_edited(src, {"file": "d/a.xlsx", "sohoso": "123/2026"}, _goc(S), out_path=out)
    assert res.errors == [] and res.n_rows == 2 and out.exists()


def test_validate_edited_thieu_dong_va_ghichu(tmp_path):
    full = write_d02(tmp_path / "full.xlsx", [make_row(), make_row(STT="2", HOTEN="B")])
    S = read_d02(full)
    (tmp_path / "e").mkdir()
    part = write_d02(tmp_path / "e" / "full.xlsx", [make_row(GHICHU="khác")])
    res = validate_edited(part, {"file": "full.xlsx", "sohoso": "123/2026"}, _goc(S))
    joined = "\n".join(res.errors)
    assert "GHICHU không có" in joined and "ít hơn bản gốc" in joined and "Thiếu dòng STT gốc: 2" in joined


def test_cot_chu_co_cot_quan_trong():
    assert {"SOBHXH", "SOCMND", "TUTHANG", "NGAYSINH"} <= set(COT_CHU)


def test_codes_of_cq(tmp_path):
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active
    ws.append(["STT", "Mã ĐV", "Tên", "", "", "", "", "", "Chuyên quản"])
    ws.append([1, "'ab123", "A", "", "", "", "", "", "Nguyễn Văn X"])
    ws.append([2, "cd456", "B", "", "", "", "", "", "Người khác"])
    p = tmp_path / "dv.xlsx"; wb.save(p)
    assert codes_of_cq(p, "Nguyễn Văn X") == {"AB123"}


def test_ten_file_d02_theo_tien_ich():
    from bo600.util import ten_file_d02
    it = {"madonvi": "ABC", "kykekhai": "03/2026", "short": "77"}
    # tên gốc đã có NN_YYYY: giữ nguyên, thêm __số hồ sơ, giữ đuôi
    assert ten_file_d02("0123ABC03_2026 (1).xlsx", it) == ("0123ABC03_2026__77", ".xlsx")
    assert ten_file_d02("X01_2026.xlsx.xlsx", it) == ("X01_2026__77", ".xlsx")
    # tên gốc không có NN_YYYY: dùng fallbackBase = mã ĐV + MM_YYYY (không có dấu _ giữa)
    assert ten_file_d02("PS_TBB.xlsx", it) == ("ABC03_2026__77", ".xlsx")
    assert ten_file_d02("", {**it, "kykekhai": ""}) == ("ABC_ky__77", ".xlsx")
