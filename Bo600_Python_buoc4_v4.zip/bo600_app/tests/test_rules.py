from datetime import datetime

from bo600.config import QUY_TAC_MAC_DINH
from bo600.d02_io import read_d02
from bo600.rules import compute_dx, da_giai, dat_o, mau_tu_choi, nhom_tinh, tab_of, issues_all
from conftest import make_row, write_d02

TODAY = datetime(2026, 10, 23)
IT = {"id": "i1", "sohoso": "123/2026", "madonvi": "ABC123", "rows": 1}


def dx_of(tmp_path, rows, ktn=None, tc=None, socai=None, it=None, old=None):
    S = read_d02(write_d02(tmp_path / "t.xlsx", rows))
    return compute_dx(S, it or {**IT, "rows": len(rows)}, QUY_TAC_MAC_DINH, socai, ktn, tc, old, TODAY)


def ks(dx):
    return [i["k"] for i in issues_all(dx)]


def test_sach_khong_co_van_de(tmp_path):
    dx = dx_of(tmp_path, [make_row()])
    assert dx["nhom"] == "sach" and ks(dx) == []


def test_tu_sua_co_hoc(tmp_path):
    dx = dx_of(tmp_path, [make_row(DENTHANG="12/2026", MAVUNG="02", MAVUNGSS="K1 Hà Nội", DIACHI="abc", MAPB="X1")])
    r = dx["rows"][0]
    assert r["chot"]["DENTHANG"] == "" and r["chot"]["MAVUNG"] == "01"
    assert r["chot"]["MAVUNGSS"] == "Hà Nội"
    assert r["chot"]["DIACHI"] == "." and r["chot"]["MAPB"] == ""
    assert all(r["dx"][c] == "co" for c in ("DENTHANG", "MAVUNG", "MAVUNGSS", "DIACHI", "MAPB"))
    assert r["goc"]["DIACHI"] == "abc"              # bản gốc giữ nguyên
    assert dx["nhom"] == "sach"                     # sửa cơ học không đổi nhóm


def test_macv_chung_chung_la_tu_choi(tmp_path):
    dx = dx_of(tmp_path, [make_row(MACV="Nhân viên.")])
    assert "macv" in ks(dx) and dx["nhom"] == "tuchoi"
    assert "chung chung" in issues_all(dx)[0]["txt"]
    assert "Chức danh nghề" in dx["tuChoi"]["lyDo"]


def test_macv_trong_va_ky_tu_la(tmp_path):
    assert "macv" in ks(dx_of(tmp_path, [make_row(MACV="")]))
    assert "ký tự lạ" in issues_all(dx_of(tmp_path, [make_row(MACV="Kế toán #@!")]))[0]["txt"]
    assert ks(dx_of(tmp_path, [make_row(MACV="Kỹ sư (xây dựng) - A&B")])) == []     # dấu câu hợp lệ


def test_ma_so_va_cmnd(tmp_path):
    assert ks(dx_of(tmp_path, [make_row(SOBHXH="", SOCMND="")])) == ["khongMa"]
    dx = dx_of(tmp_path, [make_row(SOBHXH="", SOCMND="123456789")])
    assert ks(dx) == ["cmnd9KhongMa"] and dx["nhom"] == "tuchoi"
    assert ks(dx_of(tmp_path, [make_row(SOBHXH="0123456789", SOCMND="123456789")])) == ["cmnd9"]


def test_ml_ty_le_la_nguoi_xem(tmp_path):
    dx = dx_of(tmp_path, [make_row(ML="4000000", TYLE="30")])
    assert ks(dx) == ["ml", "tyle"] and dx["nhom"] == "nguoi"
    assert "dưới 5.310.000" in issues_all(dx)[0]["txt"]
    assert ks(dx_of(tmp_path, [make_row(ML="15")])) == []            # ML < 20 không bị tính


def test_truy_thu_va_tinh_lai(tmp_path):
    dx = dx_of(tmp_path, [make_row(TUTHANG="08/2026", NGAY_NOP_HS="05/10/2026")])
    r = dx["rows"][0]
    assert ks(dx) == ["truyThu"] and dx["nhom"] == "nguoi"
    assert r["chot"]["TINHLAI"] == "x" and r["dx"]["TINHLAI"] == "co"
    # báo tăng đúng tháng nộp: không truy thu, không tính lãi
    assert ks(dx_of(tmp_path, [make_row(TUTHANG="09/2026", NGAY_NOP_HS="05/10/2026")])) == []


def test_tuthang_thang_hien_tai_xoa_tinh_lai(tmp_path):
    dx = dx_of(tmp_path, [make_row(TUTHANG="10/2026", TINHLAI="x")])
    r = dx["rows"][0]
    assert r["chot"]["TINHLAI"] == "" and r["dx"]["TINHLAI"] == "co"


def test_khong_tang_khong_tinh_lai_khong_truy_thu(tmp_path):
    dx = dx_of(tmp_path, [make_row(PA="GI", TUTHANG="06/2026", NGAY_NOP_HS="05/10/2026")])
    assert ks(dx) == [] and dx["rows"][0]["chot"]["TINHLAI"] == ""


def test_khoi_cd_chu_ho(tmp_path):
    it = {**IT, "ktn": {"donVi": {"khoi": "CD"}}}
    dx = dx_of(tmp_path, [make_row(TYLE="32")], it=it)
    assert "cdChuHo" in ks(dx) and dx["nhom"] == "tuchoi"
    it2 = {**IT, "madonvi": "0123456789CDA01"}
    assert "cdChuHo" in ks(dx_of(tmp_path, [make_row()], it=it2))


def test_de_xuat_theo_tra_cuu_la_nhom_tracuu(tmp_path):
    tc = [{"De_xuat_SOBHXH": "9999999999", "De_xuat_MA_BV": "01-002", "A_ho_ten": "Nguyen Van A"}]
    dx = dx_of(tmp_path, [make_row(SOBHXH="")], tc=tc)
    r = dx["rows"][0]
    assert r["chot"]["SOBHXH"] == "9999999999" and r["dx"]["SOBHXH"] == "tc"
    assert r["chot"]["MA_BV"] == "002" and r["chot"]["MA_TINH"] == "01"
    assert r["tra"]["MA_BV"] == "01-002"
    assert dx["nhom"] == "tracuu" and ks(dx) == []


def test_ten_theo_f2_khac_ten_d02(tmp_path):
    tc = [{"A_ho_ten": "Nguyễn Văn A"}]
    dx = dx_of(tmp_path, [make_row()], tc=tc)
    assert dx["rows"][0]["chot"]["HOTEN"] == "Nguyễn Văn A" and dx["rows"][0]["tra"]["HOTEN_F2"] == "Nguyễn Văn A"


def test_dinh_danh_va_hai_nguoi(tmp_path):
    dx = dx_of(tmp_path, [make_row()], tc=[{"Can_tra_dinh_danh": "Cần tra định danh trên HGĐ"}])
    assert ks(dx) == ["dinhDanh"] and dx["nhom"] == "dinhdanh"
    dx2 = dx_of(tmp_path, [make_row()], tc=[{"Ket_luan_ma": "Mã số và CCCD là 2 người - người xem quyết"}])
    assert ks(dx2) == ["haiNguoi"] and dx2["nhom"] == "dinhdanh"
    assert "chot" and dx2["rows"][0]["chot"]["HOTEN"] == "Nguyen Van A"   # 2 người: không tự đổi tên


def test_uu_tien_nhom_tuchoi_hon_dinhdanh_hon_nguoi(tmp_path):
    dx = dx_of(tmp_path, [make_row(MACV="lái xe", ML="1000000")], tc=[{"Can_tra_dinh_danh": "x"}])
    assert dx["nhom"] == "tuchoi"
    dx = dx_of(tmp_path, [make_row(ML="1000000")], tc=[{"Can_tra_dinh_danh": "x"}])
    assert dx["nhom"] == "dinhdanh"


def test_loi_do_va_da_giai(tmp_path):
    ktn = [{"mau": "Đỏ", "loi": "Lỗi vùng lương", "fp": ""}]
    dx = dx_of(tmp_path, [make_row(MAVUNG="02")], ktn=ktn)       # MAVUNG tự sửa -> lỗi đã có cách sửa
    assert ks(dx) == []
    dx = dx_of(tmp_path, [make_row()], ktn=[{"mau": "Đỏ", "loi": "Lỗi lạ chưa biết"}])
    assert ks(dx) == ["loiDo"] and dx["nhom"] == "nguoi"
    assert da_giai("Lỗi định danh HGĐ; CCCD sai", {"De_xuat_SOBHXH": "1"}, {}) is True
    assert da_giai("", {}, {}) is False
    assert da_giai("Điện thoại trùng", {}, {"SDT": "co"}) is True


def test_so_cai_trung_dong_da_luu(tmp_path):
    class FakeSocai:
        def has_fingerprint(self, fp): return fp == "FP1"
    dx = dx_of(tmp_path, [make_row()], ktn=[{"mau": "", "fp": "FP1"}], socai=FakeSocai())
    assert ks(dx) == ["soCai"]


def test_so_dong_khac_luc_tai(tmp_path):
    dx = dx_of(tmp_path, [make_row()], it={**IT, "rows": 3})
    assert dx["hsIssues"][0]["k"] == "loiDo" and "khác số dòng lúc tải" in dx["hsIssues"][0]["txt"]


def test_giu_o_nguoi_da_sua_khi_tinh_lai(tmp_path):
    first = dx_of(tmp_path, [make_row(ML="4000000")])
    dat_o(first["rows"][0], "ML", "6000000", "nguoi")
    first["truyThu"] = {"on": True, "noiDung": "phiếu"}
    again = dx_of(tmp_path, [make_row(ML="4000000")], old=first)
    r = again["rows"][0]
    assert r["chot"]["ML"] == "6000000" and r["tay"]["ML"] is True
    # như extension: vấn đề tính trên giá trị GỐC (vẫn hiện để người xem lại), ô người sửa chỉ được giữ ở "chot"
    assert ks(again) == ["ml"] and again["truyThu"]["noiDung"] == "phiếu"


def test_dat_o_ve_goc_thi_bo_dau_vet(tmp_path):
    dx = dx_of(tmp_path, [make_row(DIACHI="abc")])
    r = dx["rows"][0]
    assert r["dx"]["DIACHI"] == "co"
    dat_o(r, "DIACHI", "abc", "nguoi")
    assert "DIACHI" not in r["dx"] and "DIACHI" not in r["tay"]


def test_nguoi_sua_tinh_lai_x_bi_ep_xoa(tmp_path):
    from bo600.rules import ep_tinh_lai
    dx = dx_of(tmp_path, [make_row(TUTHANG="10/2026")])
    r = dx["rows"][0]
    dat_o(r, "TINHLAI", "x", "nguoi")
    assert ep_tinh_lai(r, dx["head"], TODAY) is True and r["chot"]["TINHLAI"] == ""


def test_mau_tu_choi_gop_theo_quy_tac_va_sap_tuchoi_truoc(tmp_path):
    dx = dx_of(tmp_path, [make_row(MACV="công nhân", ML="1000000")])
    m = mau_tu_choi(dx, QUY_TAC_MAC_DINH)
    lines = m["lyDo"].split("\n")
    assert lines[0].startswith("Chức danh nghề") and lines[1].startswith("Mức lương")


def test_bo_tu_choi_chuyen_sang_nguoi(tmp_path):
    dx = dx_of(tmp_path, [make_row(MACV="công nhân")])
    assert nhom_tinh(dx, QUY_TAC_MAC_DINH, True) == "nguoi"


def test_tab_of():
    dx = {"nhom": "tuchoi", "boTuChoi": False}
    assert tab_of({"q": {"kind": "tuchoi"}}, dx) == "tuchoi"
    assert tab_of({}, {"nhom": "tuchoi", "boTuChoi": True}) == "nguoi"
    assert tab_of({"imp": {"kq": "loi"}}, dx) == "loisau"
    assert tab_of({"imp": {"kq": "loi"}, "q": {"kind": "import"}}, dx) == "tuchoi"
