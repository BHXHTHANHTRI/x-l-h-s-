"""Chạy Bộ 600:  python run_app.py [--data-dir D:\\Bo600]"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", help="thư mục dữ liệu (mặc định: Downloads\\Bo600)")
    ap.add_argument("--theme", default="flatly")
    a = ap.parse_args()
    try:                                    # chữ nét trên màn hình độ phân giải cao (Windows)
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:                       # noqa: BLE001 - không phải Windows
        pass
    from bo600.ui.app import App
    App(a.data_dir, a.theme).mainloop()


if __name__ == "__main__":
    main()
