"""Chạy thử bộ quy tắc duyệt trên MỘT file D02 thật (chưa cần trình duyệt, chưa ghi gì vào dữ liệu).

    python thu_duyet.py D02_hoso.xlsx                 # in nhóm + vấn đề từng dòng
    python thu_duyet.py D02_hoso.xlsx --ghi ra.xlsx   # ghi thêm file import đã chốt (giá trị máy tự sửa), kèm sheet GOC_DONVI

Chưa có kết quả kiểm tra nháp/tra cứu nên chưa thấy các vấn đề: lỗi đỏ TST, trùng sổ cái, định danh, đề xuất theo tra cứu.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from bo600.config import NHOM_TEN, QUY_TAC_MAC_DINH
from bo600.d02_io import build_import, read_d02
from bo600.rules import compute_dx, issues_all

ap = argparse.ArgumentParser()
ap.add_argument("file")
ap.add_argument("--ghi", help="đường dẫn file import đầu ra")
a = ap.parse_args()

S = read_d02(a.file)
dx = compute_dx(S, {"sohoso": "", "madonvi": "", "rows": ""}, QUY_TAC_MAC_DINH)
print(f"File: {a.file}\nSố dòng dữ liệu: {len(S.rows)}")
print(f"NHÓM ĐỀ XUẤT: {NHOM_TEN[dx['nhom']]}\n")
for r in dx["rows"]:
    sua = [f"{c}: '{r['goc'].get(c, '')}' -> '{v}'" for c, v in r["chot"].items() if v != r["goc"].get(c, "")]
    if r["issues"] or sua:
        print(f"Dòng STT {r['stt']} - {r['goc'].get('HOTEN')}")
        for i in r["issues"]:
            print(f"   VẤN ĐỀ [{i['k']}]: {i['txt']}")
        for s in sua:
            print(f"   TỰ SỬA  {s}")
if not issues_all(dx):
    print("Không có vấn đề nào.")
if dx["tuChoi"]["lyDo"]:
    print("\nLý do soạn sẵn:\n" + dx["tuChoi"]["lyDo"] + "\nĐề nghị soạn sẵn:\n" + dx["tuChoi"]["deNghi"])
if a.ghi:
    build_import(a.file, a.ghi, dx["rows"], with_goc=True)
    print(f"\nĐã ghi file import: {a.ghi}")
