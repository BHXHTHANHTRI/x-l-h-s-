# Bộ 600 - bản Python (app riêng)

Đã xong: tầng A (dữ liệu, sổ cái, Excel, quy tắc duyệt) và tầng D (giao diện Tkinter/ttkbootstrap).
Tầng B (điều khiển Chrome) đã xong và có test. Tầng C hiện cài **bước 1 (Đơn vị quản lý)**, **bước 2 (Tiếp nhận)** và **bước 3 (Tải D02)**;
bước 4 (Kiểm tra nháp) đã được tích hợp vào Python app; các bước 5, 6, 8, 9 và trang Định danh (sau) chưa được cài đặt.

    pip install -r requirements.txt
    python run_app.py                      # mở app  (tùy chọn: --data-dir D:\Bo600)
    python thu_duyet.py D02_hoso.xlsx      # thử quy tắc duyệt trên 1 file D02, không mở giao diện
    python -m pytest -q tests              # test logic; thêm test giao diện nếu có màn hình, test trình duyệt nếu đặt BO600_TEST_CHROME
                                           # (Linux không màn hình: xvfb-run -a python -m pytest -q tests)

## Bước 0: làm thử kết nối trình duyệt (làm ngay trên máy có đăng nhập TST/TNHS)

    python spike_cdp.py

Mở một Chrome riêng (hồ sơ riêng ở `Downloads\Bo600\_chrome_profile`), bạn đăng nhập TST/TNHS một lần, rồi script chỉ ĐỌC:
nối được không, trang có nhận ra điều khiển (`navigator.webdriver`) / bẫy `debugger` chống F12 không, nghe được các phản hồi
mạng không, đọc được JSON không. Kết quả lưu vào `spike_report.txt` (chỉ có đường dẫn API, mã trạng thái, tên trường; không có
họ tên, mã số, nội dung). Nếu có FAIL/WARN: gửi file đó lại.
Trong app: **Cài đặt → Trình duyệt → Mở Chrome điều khiển được / Kiểm tra kết nối**.

Lưu ý: Chrome từ bản 136 không cho bật cổng gỡ lỗi trên hồ sơ mặc định, nên TIC và phiên đăng nhập phải cài lại trong hồ sơ riêng này.

## Lớp điều khiển trình duyệt (tầng B) - `bo600/browser/`

| File | Việc | Port từ |
|---|---|---|
| `chrome.py` | tìm/mở Chrome với cổng gỡ lỗi, hồ sơ riêng, tách khỏi app | - |
| `jsrt.py` | mã chạy trong trang: lớp "đang tải", bị che, khóa, MutationObserver, tìm phần tử | `content.js` (vis, dangTai, biChe, khoa) |
| `net.py` | đếm yêu cầu đang chờ, lưu/nghe phản hồi, chặn lệnh (vd. POST `/api/importTbb/import`) | `page_hook.js` |
| `tab.py` | cổng ổn định `cho_on_dinh/bam/dien`, `cho_th`, `san_sang`, `goto_hash`, tải về/tải lên | `content.js` (onDinh, bam, dien, choTH, sanSang, hetTai) |
| `session.py` | nối CDP, tab theo vai (tst/tnhs/hgd); đóng phiên KHÔNG đóng Chrome | `background.js` (quản lý tab) |

Dùng trong một bước: `with open_session(ctx) as br: tst = br.tab("tst", "tst.bhxh.gov.vn")` (`bo600/steps/__init__.py`).
Cổng ổn định giữ nguyên luật: màn hình đang tải / còn yêu cầu chờ / giao diện chưa lặng / dữ liệu chưa nạp / phần tử chưa hiện, khóa,
bị che, đang di chuyển -> chờ; nghỉ 0,8-1,5 giây; quá `toiDaGiay` thì ném `GateTimeout` ("[HT] ... dừng lượt"), không bấm mò, không tự thử lại.
Test tầng B chạy trên Chromium thật + trang SPA giả lập (`tests/fake_site.py`): đặt `BO600_TEST_CHROME=<đường dẫn chrome>`.

## Dùng thử khi chưa có bước Tải D02 tự động

Trang **Tiến độ → Nạp D02 thủ công…** chọn file D02 (.xlsx), xác nhận số hồ sơ / mã đơn vị. Hồ sơ hiện ở
**7. Duyệt**: sửa ô (bấm đúp), tích "Duyệt" từng dòng, **Gửi hàng chờ** (ghi file import vào `<ngày>\_import\`),
hoặc **Duyệt từ chối**. Sửa bằng Excel: **Mở Excel để sửa** → lưu → **Nạp file đã sửa…**.

## Bước 1 - Đơn vị quản lý (`bo600/steps/donvi.py`)

Trang bước 1: chọn file Danh mục đơn vị (hoặc tick **Tự tải file từ TST**), nhập tên chuyên quản, bấm **▶ Chạy bước này**.
Máy làm đúng như extension: (tùy chọn) TST > Danh mục đơn vị > Xuất File > "Danh sách đơn vị" + Excel (lưu vào `_danhmuc\DsDonVi_<ngày>`),
rồi trên TNHS mở khung "Đơn vị quản lý" của TIC, nạp file, chọn đúng tên chuyên quản trong khung gợi ý, bấm "Lấy mã theo chuyên quản".
Sau đó đối chiếu với file: **mã thừa** (TIC giữ, file không có; chỉ báo, không xóa) và **mã thiếu** (file có, TIC chưa giữ; CẢNH BÁO đỏ).
Kết quả hiện ngay dưới nút trên trang bước 1. Nút "Đọc mã đơn vị" vẫn dùng để xem trước số mã trong file, không cần trình duyệt.
Cần: Chrome điều khiển được đã đăng nhập TST/TNHS và đã cài TIC (không có TIC thì báo lỗi rõ, không làm gì thêm).
File TST lưu đuôi `.xls`: thường là file `.xlsx` thật đặt nhầm đuôi - máy tự chép sang `DsDonVi_<ngày>.xlsx` cạnh file gốc để đối chiếu mã (file gốc giữ nguyên). `.xls` cũ thật (OLE): cần `pip install xlrd` (TIC vẫn nạp được file gốc). Lỗi tên chuyên quản: báo tên gần giống, không bấm "Lấy mã".

## Bước 2 - Tiếp nhận (`bo600/steps/tiepnhan.py`)

Bấm **▶ Chạy bước này** ở trang bước 2 (hoặc **Chạy cả chuỗi (2→9)** ở trang Tiến độ). Máy làm đúng như extension:
1. Tab TNHS đang ở Cấp sổ-thẻ thì đổi về **Bộ phận Quản lý thu** bằng menu "Bộ phận ..." (`steps/tnhs_vai.py`), rồi mở *Hồ sơ chờ thụ lý*, 100 dòng/trang.
2. Mở khung "Đơn vị quản lý" của TIC, bấm **Tích + Tiếp nhận**: TIC tích các dòng thuộc danh sách đơn vị (kết quả bước 1) và mở hộp "Tiếp nhận hồ sơ".
3. Đợi hộp nạp xong, đọc các số hồ sơ trong hộp, bấm **GHI NHẬN**, chờ thông báo "Tiếp nhận thành công".
4. Đợi trang lặng, kiểm tra các hồ sơ vừa tiếp nhận không còn trong bảng; lặp đến hết (trang này hết thì sang trang sau, tối đa 40 lượt).
5. Xong thì chuyển sang *Hồ sơ đang thụ lý*. Kết quả (số hồ sơ, số lượt, hoàn thành/dừng) hiện ngay trên trang bước 2.

Máy **dừng lượt, không tự thử lại** khi: GHI NHẬN xong mà 15 giây không thấy "Tiếp nhận thành công"; hồ sơ vừa tiếp nhận vẫn còn trong danh sách (tránh lặp);
TIC báo "Chưa có danh sách" (chạy bước 1 trước); trang không ổn định quá hạn. Hộp nhắc "ĐẾN GIỜ TÍCH HỒ SƠ" của TIC được máy tự đóng bằng "OKE, ĐỂ TÔI TÍCH!"
(không bao giờ bấm "CHƯA TÍCH ĐƯỢC"). Mỗi lệnh tiếp nhận máy bấm được ghi vào **sổ cái** (`bo600/tnhs_socai.py`, loại `tiepnhan`, người làm = Máy).
Không có TIC: chạy riêng thì báo lỗi rõ; trong "Chạy cả chuỗi" bước 2 tự được bỏ qua (tiếp nhận tay, các bước sau chạy với hồ sơ đã ở Đang thụ lý).
Lần chạy thật đầu tiên: ngồi xem tab TNHS. Trong lúc chạy KHÔNG thao tác trên tab đó (đổi bộ phận là đổi cho cả phiên đăng nhập).

## Bước 3 - Tải D02 (`bo600/steps/tai_d02.py`)

- Mở TNHS ở **Đang thụ lý**, bảo đảm đang ở **Bộ phận Quản lý thu**, đặt 100 dòng/trang và luôn bấm **TRA CỨU** trước khi đọc.
- Chỉ tự nạp hồ sơ mới khi đọc được object dữ liệu của các dòng; yêu cầu thủ tục 600, loại hồ sơ điện tử và chưa có trong dữ liệu theo dõi. Nếu danh sách đang bị lọc hoặc không đọc được dữ liệu đầy đủ, bước dừng an toàn thay vì đoán từ chữ trên bảng.
- Mở đúng hồ sơ bằng bấm đúp, kiểm tra số hồ sơ trên chi tiết, chọn **Mẫu TST → Xuất mẫu TST**, lưu file vào thư mục ngày tải và kiểm tra sơ bộ cấu trúc D02/số dòng.
- Trạng thái hồ sơ được lưu vào SQLite ngay cả khi tải lỗi; không tự thử lại hồ sơ lỗi trong cùng lượt. Lần chạy tiếp theo hồ sơ đã được ghi nhận sẽ không bị tạo trùng.
- **Cần kiểm thử thực tế trên Chrome đã đăng nhập TNHS** trước khi chạy nhiều hồ sơ: cấu trúc trang TNHS có thể thay đổi theo phiên bản. Lần đầu nên chạy với 1–2 hồ sơ và quan sát màn hình; không thao tác tay trên tab TNHS trong lúc chạy.

## Cắm bước thao tác vào (tầng B/C)

Mỗi bước là một hàm chạy nền, đăng ký vào `Runner`; giao diện không đổi:

    def tai_d02(ctx, items):          # items = các hồ sơ đang chọn, hoặc None = tự chọn
        ctx.log("...")                # ra khung nhật ký + file _nhatky
        ctx.check_stop()              # gọi giữa các hồ sơ: bấm Dừng thì ném StopRequested
        ctx.sleep(1.2)                # ngủ nhưng thoát ngay khi bấm Dừng
    app.runner.register("tai", tai_d02)    # khóa: dv tn tai ktn f2 the imp tnhs

Chuỗi mặc định (nút "Chạy cả chuỗi"): tn → tai → ktn → f2 → the → imp → tnhs. Bước 7 do người duyệt.

## Bản đồ port

| File Python        | Tác vụ | Port từ (extension)                                           |
|--------------------|--------|---------------------------------------------------------------|
| `bo600/config.py`  | A5     | `config.js`, `core.js` (getRules, getSettings)                |
| `bo600/model.py`   | A1     | `core.js` (ktnXong, f2Xong, theXong, hằng trạng thái)         |
| `bo600/store.py`   | A1     | `core.js` (lô/hồ sơ), `chrome.storage.local` -> SQLite        |
| `bo600/socai.py`   | A2     | `core.js` (refreshSocai, socaiXacNhan), `background.js` (socai*) |
| `bo600/sukien.py`  | A2     | `core.js` (refreshSk, rowKeySets, eventsOf)                   |
| `bo600/d02_io.py`  | A3     | `m7_duyet.js` (readD02Wb, buildB64, napExcel), `core.js` (codesOfCq) |
| `bo600/tranthe.py` | A3     | `m4b_tranthe.js`                                              |
| `bo600/exports.py` | A3     | `m7_duyet.js` (exportDuyetXlsx)                               |
| `bo600/rules.py`   | A4     | `m7_duyet.js` (computeDx, daGiai, nhomTinh, mauTuChoi, tabOf, datO, epTinhLai) |
| `bo600/util.py`    | -      | các hàm ngày/số/tên trong `core.js`, `m7_duyet.js`            |
| `bo600/steps/donvi.py` | C | `m1_tiepnhan.js` (runDonVi), `content.js` (tst_export_dsdv, tnhs_load_dsdv, openExt5Panel) |
| `bo600/steps/tiepnhan.py` | C | `m1_tiepnhan.js` (runTiepNhan), `content.js` (tnhs_set_pagesize, tnhs_tick_accept_round, tnhs_next_page) |
| `bo600/steps/tnhs_vai.py` | C | `core.js` (vaiHienTai, doiVai, damBaoThu), `cs_m9.js` (tnhs9_role_get/switch) - dùng chung bước 2, 3, 9 |
| `bo600/tnhs_socai.py` | C | `content.js` (onTnhsAct, parseLoose, deepGetCI), `page_hook.js` (nghe lệnh TNHS) |
| `bo600/duyet_actions.py` | D | `m7_duyet.js` (guiHangCho, datTuChoi, rutHangCho, khoa, sửa bằng Excel), nạp D02 thủ công |
| `bo600/runner.py`  | D      | khung chạy nền + hàng đợi tin (thay service worker)           |
| `bo600/ui/`        | D      | `dashboard.html`, `ui.js`: app, page_tiendo, page_step (bước 1-6, 8, 9), page_duyet, page_socai, page_caidat |

## Khác với extension (cố ý)

- Dữ liệu ở SQLite `Downloads\Bo600\_app\bo600.sqlite` thay cho `chrome.storage`. File D02, `_nhatky`, `_socai`, `_danhmuc` giữ nguyên bố cục.
- Chỉ hỗ trợ bố cục lô mới (`<ngày>\_ketqua`); bỏ lô cũ `_Lnn` / `goc\`.
- `tnhs_tu_dong` mặc định **False** (đúng HUONG-DAN; `config.js` hiện để true).
- Số dòng Excel là 1-based thật (`sr`); báo lỗi danh mục tràn thẻ dùng số dòng thật trên sheet.
- Ghi sao lưu sổ cái nguyên tử (ghi file tạm rồi đổi tên).

## Giữ nguyên hành vi cần biết

- `compute_dx` tính vấn đề trên giá trị **gốc**; ô người đã sửa chỉ được giữ ở `chot`, vấn đề vẫn hiện để người xem lại.
- Sổ cái chỉ thêm; sổ mới + còn `socai_<mã khác>.json` chưa khôi phục => `assert_ready()` chặn import thật.

## Chưa làm

`GIU_HO_SO_XONG_NGAY` (dọn dữ liệu hồ sơ xong), tầng C các bước 3, 4, 5, 6, 8, 9 (thao tác trên TST/TNHS), trang "Định danh (sau)".
Giao diện: ô trong bảng Duyệt không tô màu riêng từng ô (chỉ tô cả dòng; cột "Thay đổi" ghi ô nào do máy/người/tra cứu sửa);
"Tạm dừng/Tiếp tục" mới có Dừng.


## Bước 4 - Kiểm tra nháp TST (`bo600/steps/kiemtra_nhap.py`)

- Tự chọn hồ sơ trạng thái **Đã tải** còn thiếu kết quả kiểm tra nháp hoặc lần kiểm tra trước bị lỗi.
- Mở màn Import TST (ML/HS theo hồ sơ), nạp file D02 đã tải, đối chiếu mã đơn vị, chọn sheet D02 rồi chạy **Đọc → Kiểm tra**.
- Xử lý các hộp thoại đã biết: Cv2745 chọn **Bỏ qua**, cảnh báo không khớp định danh chọn **Không**; hộp thoại lạ thì dừng và ghi lỗi.
- Đọc số dòng, dòng đỏ/vàng và kết quả; lưu trạng thái vào SQLite để lần sau không kiểm tra lại hồ sơ đã có kết quả, trừ hồ sơ có lỗi chạy.
- **Không bấm Lưu**: nút Lưu bị khóa bằng lớp giao diện và POST `/api/importTbb/import` bị chặn trong suốt lượt kiểm tra.
- Cần Chrome điều khiển được đã đăng nhập TST. Nên kiểm thử trước với 1 hồ sơ và quan sát trang TST; không thao tác tay trên tab Import trong lúc chạy. Chưa thể kiểm thử trực tiếp trên tài khoản/nghiệp vụ TST từ môi trường phát triển này.
